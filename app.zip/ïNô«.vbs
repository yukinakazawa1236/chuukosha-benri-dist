' Starts the system without a black window. (Logic is in lib\launcher.mjs)
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
node = "node"
If fso.FileExists(dir & "\runtime\node.exe") Then node = """" & dir & "\runtime\node.exe"""
rc = sh.Run("cmd /c " & node & " lib\launcher.mjs", 0, True)
If rc = 9009 Then
  MsgBox "Node.js was not found on this PC. Install the LTS version from https://nodejs.org/ and try again.", 48, "ESCO Drive"
End If
