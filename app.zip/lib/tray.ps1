﻿# 通知領域（時計の横）のアイコン。右クリックで「画面を開く」「終了」。システムが止まったら、自分も消える。
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\ESCODriveTray', [ref]$created)
if (-not $created) { exit }

$base = 'http://127.0.0.1:3847'
$icon = New-Object System.Windows.Forms.NotifyIcon
$iconFile = Join-Path (Split-Path -Parent $PSScriptRoot) 'public\icon.ico'
if (Test-Path $iconFile) { $icon.Icon = New-Object System.Drawing.Icon($iconFile) } else { $icon.Icon = [System.Drawing.SystemIcons]::Application }
$icon.Text = 'ESCO Drive'
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$openItem = $menu.Items.Add('画面を開く')
$quitItem = $menu.Items.Add('終了')
$icon.ContextMenuStrip = $menu
$icon.Visible = $true

$openItem.add_Click({ Start-Process "$base/" })
$icon.add_DoubleClick({ Start-Process "$base/" })
$quitItem.add_Click({
  try { Invoke-WebRequest -Uri "$base/api/quit" -Method Post -Headers @{ 'X-UD-Ext' = '1' } -UseBasicParsing -TimeoutSec 5 | Out-Null } catch {}
  $icon.Visible = $false
  [System.Windows.Forms.Application]::Exit()
})

$misses = 0
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 5000
$timer.add_Tick({
  try { Invoke-WebRequest -Uri "$base/api/ping" -UseBasicParsing -TimeoutSec 3 | Out-Null; $script:misses = 0 }
  catch { $script:misses++ }
  if ($script:misses -ge 2) { $icon.Visible = $false; [System.Windows.Forms.Application]::Exit() }
})
$timer.Start()

[System.Windows.Forms.Application]::Run()
$icon.Dispose()
