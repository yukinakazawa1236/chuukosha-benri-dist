@echo off
cd /d "%~dp0"

set "NODE=node"
if exist "%~dp0runtime\node.exe" set "NODE=%~dp0runtime\node.exe"

if /i "%NODE%"=="node" (
  where node >nul 2>&1
  if errorlevel 1 (
    echo.
    echo [ACTION NEEDED] Node.js was not found on this PC.
    echo   1. Download the LTS version from https://nodejs.org/ and install it.
    echo   2. Then double-click this file again.
    echo.
    echo If an AI assistant is setting this up, give it the file SETUP_FOR_AI.md in this folder.
    pause
    exit /b 1
  )
)

"%NODE%" lib\updater.mjs

if not exist "node_modules\xlsx\package.json" (
  echo Installing required parts. First time only, this takes a minute...
  call npm install --no-audit --no-fund
)

"%NODE%" lib\setup-check.mjs --boot
if errorlevel 2 (
  start "" http://127.0.0.1:3847/
  exit /b 0
)
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)

start "ESCO Drive" "%NODE%" server.mjs
timeout /t 1 >nul
start "" http://127.0.0.1:3847/
