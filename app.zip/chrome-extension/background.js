// ESCO Drive USS連携
// システム(127.0.0.1:3847)から「このUSSの相場検索ページを取ってきて」という依頼を受け取り、
// ログイン済みのUSSタブの中で取得して返す。相場検索(/jp/market/)以外は取得しない。

const SERVER = "http://127.0.0.1:3847";
const USS_ORIGIN = "https://ssl.cis6200.jp";
// 読んでよいのは、相場検索（market）と、下見検索（prelim）の検索・一覧・選択肢のページだけ。入札・セリ・ライブ・車の詳細は読まない。
const ALLOWED_PATH = /^\/cis\/[A-Za-z0-9_-]+\/jp\/(market\/[A-Za-z0-9_/.-]+\.aspx|prelim\/model\/(modelSch|modelTxt)\.aspx|prelim\/model\/option\/(brandOption|modelOption|resultOption)\.aspx)(\?[A-Za-z0-9_=&%.+-]*)?$/;
const HEADERS = { "X-UD-Ext": "1" };

let running = false;

chrome.runtime.onInstalled.addListener(start);
chrome.runtime.onStartup.addListener(start);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "poll") loop();
});
loop();

function start() {
  chrome.alarms.create("poll", { periodInMinutes: 0.5 });
  loop();
}

async function loop() {
  if (running) return;
  running = true;
  try {
    for (;;) {
      const job = await nextJob();
      if (job) await handle(job);
    }
  } catch {
    // システムが起動していない。次のアラームでやり直す。
  } finally {
    running = false;
  }
}

async function nextJob() {
  const response = await fetch(`${SERVER}/api/ext/poll?wait=20`, { headers: HEADERS });
  if (!response.ok) throw new Error("poll failed");
  return (await response.json()).job;
}

async function handle(job) {
  let reply;
  try {
    if (!ALLOWED_PATH.test(job.path)) throw new Error("相場検索のページ以外は取得しません。");
    const tabId = await ussTab(job.path);
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: fetchInPage,
      args: [job.path, job.method, job.form],
    });
    reply = { id: job.id, ...result };
  } catch (error) {
    reply = { id: job.id, error: String(error && error.message ? error.message : error) };
  }
  await fetch(`${SERVER}/api/ext/result`, {
    method: "POST",
    headers: { ...HEADERS, "Content-Type": "application/json" },
    body: JSON.stringify(reply),
  });
}

async function ussTab(path) {
  const tabs = await chrome.tabs.query({ url: `${USS_ORIGIN}/*` });
  const ready = tabs.find((tab) => tab.status === "complete") || tabs[0];
  if (ready) return ready.id;
  const home = `${USS_ORIGIN}${path.match(/^\/cis\/[^/]+\//)[0]}`;
  const tab = await chrome.tabs.create({ url: home, active: false });
  await waitComplete(tab.id);
  return tab.id;
}

function waitComplete(tabId) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("USSのページを開けませんでした。USBでログインできているか確認してください。"));
    }, 30000);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// USSのタブの中で実行される。ログイン情報はそのページのものをそのまま使う。
async function fetchInPage(path, method, form) {
  const init = { method, credentials: "include" };
  if (method === "POST") {
    init.headers = { "Content-Type": "application/x-www-form-urlencoded" };
    init.body = new URLSearchParams(form || {}).toString();
  }
  const response = await fetch(path, init);
  const buffer = await response.arrayBuffer();
  const header = (response.headers.get("content-type") || "").match(/charset=([\w-]+)/i);
  const label = header ? header[1] : document.characterSet || "utf-8";
  let text;
  try {
    text = new TextDecoder(label).decode(buffer);
  } catch {
    text = new TextDecoder("utf-8").decode(buffer);
  }
  return { status: response.status, url: response.url, text };
}
