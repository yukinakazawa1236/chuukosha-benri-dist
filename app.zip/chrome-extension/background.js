// ESCO Drive USS連携
// システム(127.0.0.1:3847)から「このUSSの相場検索ページを取ってきて」という依頼を受け取り、
// ログイン済みのUSSタブの中で取得して返す。相場検索(/jp/market/)以外は取得しない。

const SERVER = "http://127.0.0.1:3847";
const USS_ORIGIN = "https://ssl.cis6200.jp";
// 読んでよいのは、相場検索（market）と、下見検索（prelim）の検索・一覧・選択肢のページだけ。入札・セリ・ライブ・車の詳細は読まない。
const ALLOWED_PATH = /^\/cis\/[A-Za-z0-9_-]+\/jp\/(market\/[A-Za-z0-9_/.-]+\.aspx|prelim\/model\/(modelSch|modelTxt)\.aspx|prelim\/model\/option\/(brandOption|modelOption|resultOption)\.aspx)(\?[A-Za-z0-9_=&%.+-]*)?$/;
// 自分の版も、システムに伝える（システムが、同梱の版と比べて、古いときに、画面で知らせるため）
const HEADERS = { "X-UD-Ext": "1", "X-UD-Ext-Version": chrome.runtime.getManifest().version };

let running = false;

chrome.runtime.onInstalled.addListener(start);
chrome.runtime.onStartup.addListener(start);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "poll") loop();
});
loop();

function start() {
  chrome.alarms.create("poll", { periodInMinutes: 0.5 });
  loop();
}

async function loop() {
  if (running) return;
  running = true;
  try {
    for (;;) {
      const job = await nextJob();
      if (job) await handle(job);
    }
  } catch {
    // システムが起動していない。次のアラームでやり直す。
  } finally {
    running = false;
  }
}

async function nextJob() {
  const response = await fetch(`${SERVER}/api/ext/poll?wait=20`, { headers: HEADERS });
  if (!response.ok) throw new Error("poll failed");
  return (await response.json()).job;
}

async function handle(job) {
  let reply;
  try {
    if (!ALLOWED_PATH.test(job.path)) throw new Error("相場検索のページ以外は取得しません。");
    // まず、タブを使わずに、拡張機能から直接読む（画面には何も出ない）。だめなら、USSのタブの中で読む。
    let direct = null;
    try { direct = await fetchDirect(job); } catch { direct = null; }
    if (direct) {
      reply = { id: job.id, ...direct, via: "direct" };
    } else {
      const tabId = await ussTab(job.path, job.passive);
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        func: fetchInPage,
        args: [job.path, job.method, job.form],
      });
      reply = { id: job.id, ...result, via: "tab" };
    }
  } catch (error) {
    reply = { id: job.id, error: String(error && error.message ? error.message : error) };
  }
  await fetch(`${SERVER}/api/ext/result`, {
    method: "POST",
    headers: { ...HEADERS, "Content-Type": "application/json" },
    body: JSON.stringify(reply),
  });
}

async function ussTab(path, passive = false) {
  const tabs = await chrome.tabs.query({ url: `${USS_ORIGIN}/*` });
  const ready = tabs.find((tab) => tab.status === "complete") || tabs[0];
  if (ready) return ready.id;
  // 状態の確認だけの依頼では、USSのタブを新しく開かない（勝手にログイン画面が出ないように）
  if (passive) throw new Error("NO_USS_TAB");
  const home = `${USS_ORIGIN}${path.match(/^\/cis\/[^/]+\//)[0]}`;
  const tab = await chrome.tabs.create({ url: home, active: false });
  await waitComplete(tab.id);
  return tab.id;
}

function waitComplete(tabId) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("USSのページを開けませんでした。USBでログインできているか確認してください。"));
    }, 30000);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// 拡張機能から直接読む。ログイン済みのCookieを使う（タブは要らない）。
// 失敗（通信エラー・400番台以上）のときは null を返し、タブ経由の読み取りに切り替える。
async function fetchDirect(job) {
  const init = { method: job.method, credentials: "include", redirect: "follow" };
  if (job.method === "POST") {
    init.headers = { "Content-Type": "application/x-www-form-urlencoded" };
    init.body = new URLSearchParams(job.form || {}).toString();
  }
  const response = await fetch(USS_ORIGIN + job.path, init);
  if (response.status >= 400) return null;
  const buffer = await response.arrayBuffer();
  const header = (response.headers.get("content-type") || "").match(/charset=([\w-]+)/i);
  let label = header ? header[1] : "";
  if (!label) {
    const head = new TextDecoder("latin1").decode(buffer.slice(0, 2048));
    const meta = head.match(/charset=["']?([\w-]+)/i);
    label = meta ? meta[1] : "utf-8";
  }
  let text;
  try { text = new TextDecoder(label).decode(buffer); } catch { text = new TextDecoder("utf-8").decode(buffer); }
  return { status: response.status, url: response.url, text };
}

// USSのタブの中で実行される。ログイン情報はそのページのものをそのまま使う。
async function fetchInPage(path, method, form) {
  const init = { method, credentials: "include" };
  if (method === "POST") {
    init.headers = { "Content-Type": "application/x-www-form-urlencoded" };
    init.body = new URLSearchParams(form || {}).toString();
  }
  const response = await fetch(path, init);
  const buffer = await response.arrayBuffer();
  const header = (response.headers.get("content-type") || "").match(/charset=([\w-]+)/i);
  const label = header ? header[1] : document.characterSet || "utf-8";
  let text;
  try {
    text = new TextDecoder(label).decode(buffer);
  } catch {
    text = new TextDecoder("utf-8").decode(buffer);
  }
  return { status: response.status, url: response.url, text };
}

// 「USSで開く」のリンク（…/market/bidno/bidnoSch.aspx#ud=TK-15910-3211）をChromeで開いたとき、
// USSは、検索の条件をアドレスに付けて直接開くと「405」を返す。そこで、条件は「#」の後ろに付けて（USSには送られない）、
// 出品番号検索のページ（普通に開ける）が開いたら、その中のフォームに入れて送信し、その1台を表示する。
// 相場検索の、出品番号での検索（見るだけ）だけ。入札・セリ・ライブには触れない。
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== "complete" || !tab.url) return;
  let url;
  try { url = new URL(tab.url); } catch { return; }
  if (url.origin !== USS_ORIGIN) return;
  if (!/^\/cis\/[A-Za-z0-9_-]+\/jp\/market\/bidno\/bidnoSch\.aspx$/.test(url.pathname)) return;
  const match = url.hash.match(/^#ud=([A-Za-z]{2})-(\d{1,5})-(\d{1,6})$/);
  if (!match) return;
  const fields = { Uss: match[1].toUpperCase(), Tieup: "", AuctionCount: match[2], BidNoFrom: match[3], BidNoTo: match[3], IsIncludeEV: "1", IsIncludeFC: "1" };
  const thumbPath = url.pathname.replace("bidnoSch.aspx", "bidnoThumb.aspx");
  pendingOpen.set(tabId, { at: Date.now(), code: `${fields.Uss}-${fields.AuctionCount}-${fields.BidNoFrom}` });
  chrome.scripting.executeScript({ target: { tabId }, func: submitVehicleForm, args: [thumbPath, fields] }).catch(() => {});
});

// USSのタブの中で実行される。会場・回・出品番号だけを入れた、新しいフォームを送信する。
// （出品番号検索のページのフォームそのものは、ページの状態（__VIEWSTATE）を含むため、別のページに送ると、エラーになる）
function submitVehicleForm(action, fields) {
  const form = document.createElement("form");
  form.method = "post";
  form.action = action;
  for (const [name, value] of Object.entries(fields)) {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = name;
    input.value = value;
    form.appendChild(input);
  }
  document.body.appendChild(form);
  history.replaceState(null, "", location.pathname); // 戻るで、同じ操作を繰り返さないように、印を消す
  form.submit();
}

// 「USSで開く」の結果の確認用：送信したあとに開いたページの、題名と先頭の文字を、システムに知らせる（原因を調べるため）。
// 送るのは、システム（127.0.0.1）だけ。ページの内容は、先頭の300文字まで。
const pendingOpen = new Map();
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  const pending = pendingOpen.get(tabId);
  if (!pending || info.status !== "complete" || !tab.url) return;
  if (Date.now() - pending.at > 60000) { pendingOpen.delete(tabId); return; }
  if (/bidnoSch\.aspx/.test(tab.url)) return; // まだ、送信前のページ
  pendingOpen.delete(tabId);
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({ title: document.title, text: (document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim().slice(0, 300) }),
    });
    await fetch(`${SERVER}/api/ext/report`, {
      method: "POST",
      headers: { ...HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ code: pending.code, url: tab.url.replace(/\/cis\/[^/]+\//, "/cis/***/").split("?")[0], title: result.title, text: result.text, version: chrome.runtime.getManifest().version }),
    });
  } catch { /* システムが起動していないときなどは、何もしない */ }
});
