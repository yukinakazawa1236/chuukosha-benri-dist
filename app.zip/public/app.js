// ESCO Drive 画面
// タブ：仕入れ車種の選定 / 取得 / 落札データ / 設定
const view = document.getElementById("view");
const tabs = [...document.querySelectorAll("nav button")];
const TAB_ALIAS = { gap: "profit", today: "profit", import: "collect" };
let state = null;
let upcomingData = null;
let tab = pickTab(new URLSearchParams(location.search).get("tab"));
let filterCar = "";
let showCond = false;
let lotQuery = "";
let lotModel = "";
let lotOffset = 0;
let pickQuery = "";
let pickedExpanded = false;
let showUnselected = false;
let showView = false;
let showCrit = false;
let browseCountry = "";
let browseMaker = "";
let browseQuery = "";
let carsCache = null;
let reading = false;
// 「取得」を押した直後の、エラーの文（車種が選ばれていない、など）。次に押すまで、消さずに出しておく
let collectNotice = "";
let autoRunNotice = "";
let autoRunTimer = null;
let autoRunWasRunning = false;
let upcomingNotice = "";
let stopReading = false;
let paint = 0;

// 「表示する車種」（取得済みのデータから選ぶ）。何も選んでいなければ、取得済みのすべて。
// 取得タブの「取得する車種」とは別の設定。
function selectedModelCodes() {
  const picked = state.settings.viewCars || [];
  if (!picked.length) return new Set((state.modelChoices || []).map((choice) => choice.modelCode));
  const wanted = new Set(picked.map((key) => normText(key.replace("	", "|"))));
  return new Set((state.modelChoices || []).filter((choice) => wanted.has(normText(`${choice.maker}|${choice.name}`))).map((choice) => choice.modelCode));
}

// 取得済みのデータにある車種（メーカー＋車名ごと、台数つき）
function collectedCars() {
  const map = new Map();
  for (const choice of state.modelChoices || []) {
    if (!choice.name) continue;
    const key = `${choice.maker}	${choice.name}`;
    const row = map.get(key) || { key, maker: choice.maker, name: choice.name, count: 0 };
    row.count += choice.count || 0;
    map.set(key, row);
  }
  return [...map.values()].sort((a, b) => b.count - a.count);
}

function viewCarsHtml() {
  const cars = collectedCars();
  const picked = new Set(state.settings.viewCars || []);
  const totalOf = (list) => list.reduce((sum, car) => sum + car.count, 0).toLocaleString();
  const summary = picked.size ? `${picked.size}車種に絞っています・落札データ ${totalOf(cars.filter((car) => picked.has(car.key)))}件` : `取得済みのすべて・落札データ ${totalOf(cars)}件`;
  return `<details class="card fold" id="view-box" ${showView ? "open" : ""}><summary>表示する車種（${summary}）</summary>
    <p class="muted">取得済みのデータの中から、この画面に出す車種を選びます。車種名の横の数字は、その車種の落札データの件数です。取得する車種（「取得」タブ）とは、別の設定です。何も選ばなければ、取得済みのすべてを出します。</p>
    <div class="chips">${cars.length ? cars.map((car) => `<button type="button" class="chip${picked.has(car.key) ? " on" : ""}" data-view-car="${escapeAttr(car.key)}">${escapeHtml(car.maker + " " + car.name)} <b>${car.count}</b></button>`).join("") : "<span class='muted'>取得済みのデータがありません。「取得」タブで取得してください。</span>"}</div>
    ${picked.size ? `<p class="row"><button type="button" class="text" id="view-clear">絞りをやめて、すべて出す</button></p>` : ""}
  </details>`;
}

async function saveViewCars(keys) {
  state.settings.viewCars = keys;
  showView = true;
  renderProfit();
  await postJson("/api/settings", { viewCars: keys.join("|") });
}

function bindViewCars() {
  document.getElementById("view-box")?.addEventListener("toggle", (event) => { showView = event.target.open; });
  view.querySelectorAll("[data-view-car]").forEach((button) => button.addEventListener("click", () => {
    const key = button.dataset.viewCar;
    const now = state.settings.viewCars || [];
    saveViewCars(now.includes(key) ? now.filter((item) => item !== key) : [...now, key]);
  }));
  document.getElementById("view-clear")?.addEventListener("click", () => saveViewCars([]));
}

function unselectedNotice(hidden, unit) {
  if (showUnselected) return `<p class="muted notice-line">表示する車種に選んでいない車種も、表示しています。<button type="button" class="text" data-toggle-unselected>表示する車種だけにする</button></p>`;
  return hidden ? `<p class="muted notice-line">表示する車種に選んでいない車種のデータが、ほかに ${hidden}${unit}あります（非表示にしています）。<button type="button" class="text" data-toggle-unselected>表示する</button></p>` : "";
}

function bindUnselected(rerender) {
  view.querySelectorAll("[data-toggle-unselected]").forEach((button) => button.addEventListener("click", () => { showUnselected = !showUnselected; rerender(); }));
}

function pickTab(name) {
  const next = TAB_ALIAS[name] || name;
  return ["home", "profit", "upcoming", "collect", "lots", "settings"].includes(next) ? next : "home";
}

tabs.forEach((button) => button.addEventListener("click", () => show(button.dataset.tab)));

const bookmarklet = "javascript:" + encodeURIComponent(`(()=>{if(location.host!=="ssl.cis6200.jp"){alert("USBキーでUSSにログインしたページで押してください");return}const tables=[...document.querySelectorAll("table")];let best=null;for(const table of tables){const rows=[...table.rows].map(r=>[...r.cells].map(c=>c.innerText.replace(/\\s+/g," ").trim()));const header=rows.findIndex(r=>r.some(c=>/出品番号|落札|型式/.test(c)));if(header>=0&&(!best||rows.length>best.rows.length))best={rows,header}}if(!best){alert("結果の表が見つかりません。相場検索の一覧を開いてから押してください");return}const heads=best.rows[best.header];const items=best.rows.slice(best.header+1).filter(r=>r.join("").trim()).map(r=>{const o={};heads.forEach((h,i)=>{if(h)o[h]=r[i]||""});return o});const payload=JSON.stringify({pageUrl:location.href.split("#")[0],items});location.href="http://127.0.0.1:3847/receive#"+encodeURIComponent(payload)})()`).replace(/%20/g, " ");

load().then(refreshTotalsOnOpen);

// サイドバーに、いま動いている版を出す。更新できていないとき（新しい版がある・更新済みだが再起動していない）は、色と文で知らせる。
function versionNewer(a, b) {
  const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i += 1) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}
async function refreshVersion() {
  const el = document.getElementById("ver");
  if (!el) return;
  try {
    const v = await getJson("/api/version");
    let note = "", cls = "", tip = "";
    if (v.onDisk && v.onDisk !== v.running) { note = `更新済み（${v.onDisk}）。再起動すると反映されます`; cls = "warn"; tip = "新しい版は入っていますが、動いているのは前の版です。「システムを終了」のあと、デスクトップのアイコンから起動し直してください。"; }
    else if (v.latest && versionNewer(v.latest, v.running)) { note = `新しい版 ${v.latest} があります`; cls = "warn"; tip = "「システムを終了」のあと、デスクトップのアイコンから起動し直すと、自動で更新します。"; }
    else if (v.latest) note = "最新です";
    else note = "更新の確認はできませんでした";
    el.className = "ver " + cls;
    el.title = tip;
    el.innerHTML = `<b>バージョン ${escapeHtml(v.running)}</b><span>${escapeHtml(note)}</span>`;
  } catch { /* つながらないときは、表示しない */ }
}
refreshVersion();
setInterval(refreshVersion, 30 * 60 * 1000);


// システムを開いたときに、出品予定の「出品の総数」だけを最新にする（つながっているときだけ。軽い）
async function refreshTotalsOnOpen() {
  try {
    const result = await postJson("/api/upcoming/totals", {});
    if (!result.updated) return;
    await refreshUpcoming();
    if (tab === "upcoming") await renderUpcoming();
  } catch { /* つながっていなくても、他の表示は続ける */ }
}

async function load() {
  state = await getJson("/api/bootstrap");
  await refreshUpcoming();
  show(tab);
}

function show(next) {
  tab = pickTab(next);
  clearTimeout(collectTimer);
  tabs.forEach((button) => button.classList.toggle("active", button.dataset.tab === tab));
  updateChrome();
  const crumb = document.getElementById("crumb");
  if (crumb) crumb.textContent = { home: "ダッシュボード", profit: "仕入れ車種の選定", upcoming: "入札車の選定", collect: "取得", lots: "落札データ", settings: "設定" }[tab];
  if (tab === "home") renderHome();
  if (tab === "profit") renderProfit();
  if (tab === "upcoming") renderUpcoming();
  if (tab === "collect") renderCollect();
  if (tab === "lots") renderLots();
  if (tab === "settings") renderSettings();
  window.scrollTo(0, 0);
}

// ====================================================================
// 仕入れ候補の条件
// ====================================================================

// 小売相場の案内。古い（読んでから7日超）・未取得のグループは、差額を出せないので、候補に含められない。
// 「最新の情報を読み直す」は、いつでも押せる（1週間待たずに、最新を見たいとき）。
function staleBannerHtml(items, waiting) {
  if (!items.length) return "";
  const lost = waiting.filter((cluster) => cluster.retailEstimateYen === null);
  const dateOf = (cluster) => String(cluster.carsensor.fetchedAt || cluster.goonet.fetchedAt || "").slice(0, 10);
  const oldest = (lost.length ? lost : items).map(dateOf).filter(Boolean).sort()[0];
  const text = lost.length
    ? `<b>小売相場が古い・未取得のため、${lost.length}件を候補に含められていません。</b>（読んでから7日を過ぎると、古いとみなします${oldest ? `。いちばん古いのは ${escapeHtml(oldest)}` : ""}）`
    : waiting.length
      ? `小売相場の読み取り待ち：${waiting.length}件（読んでから7日を過ぎたもの）`
      : `小売相場は、すべて7日以内に読んだものです${oldest ? `（いちばん古い読み取り：${escapeHtml(oldest)}）` : ""}。`;
  return `<section class="card ${waiting.length ? "notice " : ""}stale-bar">
    <div class="row between"><div>${text}</div>
      <div>${waiting.length ? `<button id="read" type="button" class="small">古いものを読む</button> ` : ""}<button id="read-all" type="button" class="small secondary">最新の情報を読み直す</button> <button id="stop" type="button" class="small secondary" hidden>キャンセル</button></div></div>
    <progress id="read-bar" max="1" value="0" hidden></progress>
    <div id="progress" class="muted"></div>
  </section>`;
}

function renderProfit() {
  const settings = state.settings;
  const threshold = settings.gapThresholdYen;
  const chosenCodes = selectedModelCodes();
  const everything = state.clusters;
  const inChosen = showUnselected ? everything : everything.filter((cluster) => chosenCodes.has(cluster.modelCode));
  const hiddenCount = everything.length - inChosen.length;
  const all = inChosen.filter((cluster) => cluster.inBand);
  const bandHidden = inChosen.length - all.length;
  const carNames = [...new Set(all.map((cluster) => cluster.carName).filter(Boolean))];
  if (filterCar && !carNames.includes(filterCar)) filterCar = "";
  const list = filterCar ? all.filter((cluster) => cluster.carName === filterCar) : all;
  const notable = byConfidenceThenGap(list.filter((cluster) => cluster.notable));
  const smaller = byConfidenceThenGap(list.filter((cluster) => cluster.gapYen !== null && !cluster.notable));
  const needsRead = (site) => ["missing", "stale"].includes(site.status);
  const waiting = list.filter((cluster) => needsRead(cluster.carsensor) || needsRead(cluster.goonet));
  const today = state.today;

  const next = today.auctions.length ? `
    <section class="card notice">
      <div class="row between">
        <div>${today.auctions.map((auction) => `<b>USS${escapeHtml(auction.name)}</b> ${escapeHtml(auction.date)}（${auction.days === 1 ? "前日" : "前々日"}）`).join("　／　")}</div>
      </div>
    </section>` : "";

  const chips = carNames.length > 1 ? `
    <div class="chips filter">
      <button type="button" class="chip${filterCar ? "" : " on"}" data-filter="">すべて</button>
      ${carNames.map((name) => `<button type="button" class="chip${filterCar === name ? " on" : ""}" data-filter="${escapeAttr(name)}">${escapeHtml(name)}</button>`).join("")}
    </div>` : "";

  view.innerHTML = `
    ${next}
    ${criteriaHtml()}
    ${staleBannerHtml(list, waiting)}
    <section class="hero">
      <div class="hero-main ${notable.length ? "good" : ""}">
        <b>${notable.length}</b><span>件が、仕入れ候補の条件に合っています</span>
      </div>
      <div class="hero-side">
        <div>仕入れ候補の条件：差額 <b>${man(threshold)}</b> 以上、かつ 仕入の <b>${settings.gapRatePct}%</b> 以上${settings.costMinYen != null || settings.costMaxYen != null ? `　／　仕入れ値 ${settings.costMinYen != null ? man(settings.costMinYen) : "下限なし"}〜${settings.costMaxYen != null ? man(settings.costMaxYen) : "上限なし"}` : ""}</div>
        <div>落札データ <b>${state.lotCount.toLocaleString()}台</b>${state.latestAuctionDate ? `（最新の開催 ${escapeHtml(state.latestAuctionDate)}）` : ""}</div>
        <div class="muted">最終取得 ${escapeHtml(stamp(state.lastImportedAt))}</div>
      </div>
    </section>
    ${viewCarsHtml()}
    ${unselectedNotice(hiddenCount, "件")}
    ${bandHidden ? `<p class="muted notice-line">仕入れ値の金額帯の外のものが ${bandHidden}件あります（非表示・小売相場も読みません）。金額帯は、上の「仕入れ候補の条件」で変えられます。</p>` : ""}
    ${chips}
    ${notable.length ? `<p class="row"><button id="csv-profit" type="button" class="secondary">この一覧をCSVで保存</button></p>` : ""}
    ${notable.length ? `<div class="deals">${notable.map(dealCard).join("")}</div>` : `<section class="card empty">${all.length ? "いま、仕入れ候補の条件に合うものはありません。" :state.lotCount ? "選んでいる車種の落札データが、ありません。上の「表示する車種」を見直してください。" : (state.settings.collectCars || []).length ? "落札データが、まだありません。「取得」タブで、USSから取得してください。" : "車種が選ばれていません。「取得」タブで、取得する車種を選んでください。"}</section>`}
    ${smaller.length ? `<details class="card fold"><summary>仕入れ候補の条件に届かないもの（${smaller.length}件）</summary>${clusterTable(smaller)}</details>` : ""}
    ${all.length ? `<details class="card fold" ${showCond ? "open" : ""} id="cond-box"><summary>比べる条件を変える（${filterCar ? escapeHtml(filterCar) : "全車種"}）</summary>
      <p class="muted">${escapeHtml(searchSummary(activeSettings()))}</p>
      ${conditionFields(activeSettings())}
      <p class="row"><button id="save-cond" type="button">この条件を保存</button></p>
    </details>` : ""}`;

  bindUnselected(renderProfit);
  bindViewCars();
  bindCriteria();
  view.querySelectorAll("[data-fix]").forEach((button) => button.addEventListener("click", () => openFixer(button.dataset.fix)));
  document.getElementById("csv-profit")?.addEventListener("click", () => downloadCsv("仕入れ車種の選定", ["車種・条件", "仕入(税込・円)", "小売の見積り(円)", "差額(円)", "差額率(%)", "USS落札の中央値(万円)", "信頼度"], notable.map((cluster) => [cluster.label.replace(/　/g, " "), cluster.costYen, cluster.retailEstimateYen, cluster.gapYen, cluster.gapRate, cluster.hammerMedianMan, { high: "高", mid: "中", low: "低" }[cluster.confidence] || ""])));
  document.getElementById("read")?.addEventListener("click", () => readMarkets(list, waiting.length));
  document.getElementById("read-all")?.addEventListener("click", () => readMarkets(list, list.length, true));
  document.getElementById("stop")?.addEventListener("click", () => { stopReading = true; });
  document.getElementById("save-cond")?.addEventListener("click", saveConditions);
  document.getElementById("cond-box")?.addEventListener("toggle", (event) => { showCond = event.target.open; });
  view.querySelectorAll("[data-filter]").forEach((button) => button.addEventListener("click", () => { filterCar = button.dataset.filter; renderProfit(); }));
}

function dealCard(cluster) {
  const parts = cluster.label.split("　");
  const structured = parts.length === 7;
  const title = structured ? parts[0] : cluster.label;
  const tags = structured ? parts.slice(1, 5).filter((part) => !/不問|不明/.test(part)) : [];
  const when = structured ? `${parts[5]}・${parts[6]}` : "";
  return `<article class="deal">
    <header>
      <div class="deal-title"><b>${escapeHtml(title)}</b><span class="muted">${escapeHtml(when)}</span></div>
      <div class="deal-gap"><small>差額・粗利の目安（仕入の${cluster.gapRate}%）</small>+${man(cluster.gapYen)}</div>
    </header>
    <div class="tags">${tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join("")}${confidenceBadge(cluster)}</div>
    <div class="figures">
      <div><span>仕入（税込の目安）</span><b>${man(cluster.costYen)}</b></div>
      <div><span>小売の見積り</span><b>${cluster.retailEstimateYen === null ? "—" : man(cluster.retailEstimateYen)}</b>${basisBadge(cluster)}</div>
      <div><span>USS落札の中央（税別）</span><b>${cluster.hammerMedianMan}万円</b></div>
    </div>
    <div class="links">${siteLink("カーセンサー", cluster.carsensor)}${siteLink("グーネット", cluster.goonet)}</div>
    <div class="fixrow"><button type="button" class="small secondary" data-fix="${escapeAttr(cluster.key)}">グレードの対応づけを直す</button><span class="muted">${escapeHtml(kindLabel(cluster))}</span></div>
    <div class="fixer" data-fixer="${escapeAttr(cluster.key)}" hidden></div>
    <details class="more"><summary>くわしく（比較した範囲・計算に使った落札）</summary>
      <p class="muted">仕入の内訳（税込）：落札 ${man(cluster.costBreakdown.hammerYen)} ＋ 手数料 ${man(cluster.costBreakdown.feeYen)} ＋ 陸送 ${man(cluster.costBreakdown.transportYen)} ＋ その他 ${man(cluster.costBreakdown.otherYen)} ＝ ${man(cluster.costYen)}<br>小売の見積り：${escapeHtml(cluster.retailPickLabel)}（${cluster.retailSource === "goonet" ? "グーネット・参考" : "カーセンサー"}、${cluster.retailCount}台から）</p>
      <p class="muted">${escapeHtml(cluster.compareLabel)}。評価点${state.settings.minScore}以上 ${cluster.compCount}台。</p>
      ${cluster.matchNote ? `<p class="muted">${escapeHtml(cluster.matchNote)}</p>` : ""}
      <p class="muted">${siteStatus(cluster.carsensor)}<br>${siteStatus(cluster.goonet)}</p>
      <p class="row"><button type="button" class="small" data-comps="${escapeAttr(cluster.key)}">中央値の計算に使った ${cluster.compCount}台を、一覧で見る</button></p>
      <div class="comps-box" data-comps-box="${escapeAttr(cluster.key)}" hidden></div>
    </details>
  </article>`;
}

// マウスを当てると、すぐに出る吹き出し（data-tip）。改行は \n。
function kindLabel(cluster) {
  if (!cluster.csGradeName) return "グレード：対応づけなし";
  const kind = { exact: "完全一致", fuzzy: "あいまい一致（要確認）", manual: "確認済み" }[cluster.csGradeKind] || "";
  return `対応先：${cluster.csGradeName}（${kind}）`;
}

// グレードの対応づけを、人が選び直す。保存すると、以後ずっと自動で使われ、このグレードの小売相場は読み直される。
async function openFixer(clusterKey) {
  const cluster = state.clusters.find((item) => item.key === clusterKey);
  const box = view.querySelector(`[data-fixer="${CSS.escape(clusterKey)}"]`);
  if (!cluster || !box) return;
  if (!box.hidden) { box.hidden = true; return; }
  box.hidden = false;
  box.innerHTML = "<span class='muted'>カーセンサーのグレード一覧を読んでいます…</span>";
  const data = await getJson(`/api/cs-grades?carc=${encodeURIComponent(cluster.carsensorId)}&year=${cluster.year}`);
  const grades = data.grades || [];
  const render = (query) => {
    const needle = normText(query);
    const shown = grades.filter((grade) => !needle || normText(grade.name).includes(needle)).slice(0, 200);
    box.querySelector("select").innerHTML = shown.map((grade) => `<option value="${escapeAttr(grade.code)}" data-name="${escapeAttr(grade.name)}" ${grade.code === cluster.csGradeCode ? "selected" : ""}>${escapeHtml(grade.name)}${grade.inGeneration ? "" : "（別の世代）"}</option>`).join("") || "<option disabled>該当なし</option>";
  };
  box.innerHTML = `
    <p class="muted">USSのグレード：<b>${escapeHtml(cluster.ussGradeKey)}</b>　／　いまの対応先：<b>${escapeHtml(cluster.csGradeName || "なし")}</b></p>
    <input type="search" placeholder="カーセンサーのグレードを絞る（例：AMG、アバン）" autocomplete="off">
    <select size="7"></select>
    <div class="row">
      <button type="button" class="small" data-act="save">この対応先にする</button>
      <button type="button" class="small secondary" data-act="none">対応なしにする</button>
      <button type="button" class="small secondary" data-act="reset">自動に戻す</button>
      <button type="button" class="small secondary" data-act="close">閉じる</button>
    </div>
    <p class="muted">保存すると、同じ車種・同じUSSグレードのすべてに使われます。小売相場は、読み直します。</p>`;
  render("");
  box.querySelector("input").addEventListener("input", (event) => render(event.target.value));
  const send = async (payload) => {
    await postJson("/api/grade-override", { carc: cluster.carsensorId, ussGrade: cluster.ussGradeKey, ...payload });
    box.innerHTML = "<span class='muted'>保存しました。小売相場を読み直しています…</span>";
    await load();
    await readMarkets(state.clusters.filter((item) => item.carsensorId === cluster.carsensorId));
  };
  box.querySelector('[data-act="save"]').onclick = () => {
    const option = box.querySelector("select").selectedOptions[0];
    if (!option || option.disabled) return;
    send({ code: option.value, name: option.dataset.name });
  };
  box.querySelector('[data-act="none"]').onclick = () => send({ code: "", name: "" });
  box.querySelector('[data-act="reset"]').onclick = () => send({ code: null });
  box.querySelector('[data-act="close"]').onclick = () => { box.hidden = true; };
}

// ---- 押せる吹き出し：マウスを当てると出る／クリックで固定／固定中はリンクを押せる ----

const popStore = new Map();
let popSeq = 0;
let popPinned = null; // 固定中の札
let popHideTimer = 0;

function popAttr(html) {
  const id = String(++popSeq);
  popStore.set(id, html);
  return `data-pop="${id}"`;
}

function popBox() {
  let box = document.getElementById("popover");
  if (!box) {
    box = document.createElement("div");
    box.id = "popover";
    box.hidden = true;
    box.addEventListener("mouseenter", () => clearTimeout(popHideTimer));
    box.addEventListener("mouseleave", () => { if (!popPinned) hidePop(); });
    document.body.appendChild(box);
  }
  return box;
}

function showPop(trigger) {
  clearTimeout(popHideTimer);
  const box = popBox();
  box.innerHTML = popStore.get(trigger.dataset.pop) || "";
  box.classList.toggle("pinned", popPinned === trigger);
  box.hidden = false;
  const rect = trigger.getBoundingClientRect();
  const width = Math.min(380, window.innerWidth - 16);
  box.style.width = width + "px";
  let left = Math.min(Math.max(8, rect.left), window.innerWidth - width - 8);
  box.style.left = left + window.scrollX + "px";
  box.style.top = rect.bottom + window.scrollY + 6 + "px";
  const height = box.offsetHeight;
  if (rect.bottom + 6 + height > window.innerHeight && rect.top - 6 - height > 0) box.style.top = rect.top + window.scrollY - 6 - height + "px";
}

function hidePop() {
  const box = document.getElementById("popover");
  if (box) box.hidden = true;
}

document.addEventListener("mouseover", (event) => {
  const trigger = event.target.closest?.("[data-pop]");
  if (trigger && !popPinned) showPop(trigger);
});
document.addEventListener("mouseout", (event) => {
  const trigger = event.target.closest?.("[data-pop]");
  if (trigger && !popPinned) popHideTimer = setTimeout(hidePop, 200);
});
document.addEventListener("click", (event) => {
  const trigger = event.target.closest?.("[data-pop]");
  if (trigger) {
    // 札を押すと、固定／固定の解除
    if (popPinned === trigger) { popPinned = null; hidePop(); }
    else { popPinned = trigger; showPop(trigger); }
    return;
  }
  if (popPinned && !event.target.closest("#popover")) { popPinned = null; hidePop(); } // 外を押したら閉じる（吹き出しの中のリンクは、そのまま開く）
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && popPinned) { popPinned = null; hidePop(); }
});

function sourceRow(title, amount, note, url, linkText) {
  return `<div class="pop-row"><div><b>${escapeHtml(title)}</b><span class="amt">${amount}</span></div><div class="muted">${escapeHtml(note)}</div>${url ? `<a class="pop-link" href="${escapeAttr(url)}" target="_blank" rel="noopener">${escapeHtml(linkText)} ↗</a>` : ""}</div>`;
}

// 中央値の元になった落札車を、1台ずつ（落札額と、そのUSSのページへのリンク付き）
function lotList(lots, medianMan) {
  if (!lots || !lots.length) return "";
  // 落札額の安い順に並べる。真ん中の車が、中央値（台数が偶数なら、真ん中の2台の平均）。
  const sorted = lots.slice().sort((a, b) => a.hammerMan - b.hammerMan);
  const n = sorted.length;
  const mids = new Set(n % 2 ? [Math.floor(n / 2)] : [n / 2 - 1, n / 2]);
  return `<div class="muted pop-order">落札額の安い順（真ん中が、中央値）${n % 2 ? "" : "　※偶数なので、真ん中の2台の平均"}</div>
  <ul class="pop-lots">${sorted.map((lot, index) => `<li${mids.has(index) ? ' class="mid"' : ""}>
    <span class="lot-info">${escapeHtml(lot.auctionDate.slice(5).replace("-", "/"))} ${escapeHtml(lot.year)}年 ${km(lot.mileageKm)} 評価${lot.score ?? "—"} ${escapeHtml(lot.color)}${mids.has(index) ? ' <b class="mid-tag">◀ 中央値</b>' : ""}</span>
    <span class="lot-price">${lot.hammerMan}万円</span>
    <a class="pop-link" href="${escapeAttr(ussVehicleUrl(lot.ussCode))}" target="_blank" rel="noopener" data-uss="${escapeAttr(lot.ussCode)}">開く↗</a>
  </li>`).join("")}</ul>`;
}

// 信頼度の吹き出しの中身。cluster（仕入れ候補の条件）と、出品予定の1台、どちらの形でも使える。
function confidencePop(info) {
  const label = { high: "高", mid: "中", low: "低" }[info.confidence];
  const reasons = info.confidenceReasons || [];
  const parts = [
    `<div class="pop-title">信頼度 ${label}</div>`,
    reasons.length ? `<ul class="pop-reasons">${reasons.map((reason) => `<li>${escapeHtml(reason)}</li>`).join("")}</ul>` : `<div class="muted">弱点は見つかりませんでした</div>`,
    `<div class="muted pop-rule">分け方：弱点が 0個＝高、1個＝中、2個以上＝低<br>弱点：中央値の元になったUSS落札が5台未満／小売が8台未満／小売がグレード未指定</div>`,
    `<hr>`,
    `<div class="pop-row"><div><b>USS（落札）</b><span class="amt">中央値 ${info.medianMan}万円（税別）</span></div><div class="muted">中央値の元になった落札 ${info.compCount ?? info.ownCount}台${(info.compLots || []).length < (info.compCount ?? 0) ? `（新しい順に ${info.compLots.length}台を表示）` : ""}</div>${lotList(info.compLots, info.medianMan)}</div>`,
    sourceRow("カーセンサー", info.retailEstimateYen == null ? "—" : `見積り ${man(info.retailEstimateYen)}`, `${info.retailPickLabel || ""}${info.csLowYen ? `／最安 ${man(info.csLowYen)}` : ""}／${info.csCount}台${info.retailSource === "goonet" ? "（読めなかったため、グーネットを参考）" : ""}`, info.carsensorUrl, "カーセンサーの検索を開く"),
  ];
  if (info.clusterKey) parts.splice(5, 0, `<div class="pop-row"><button type="button" class="small" data-comps-modal="${escapeAttr(info.clusterKey)}">計算に使った${info.compCount ?? info.ownCount}台を、一覧の窓で見る</button></div>`);
  if (info.gooMedianYen != null) parts.push(sourceRow("グーネット（参考）", `中央値 ${man(info.gooMedianYen)}`, `${info.gooCount}台（グレードでは絞れません）`, info.goonetUrl, "グーネットの検索を開く"));
  parts.push(`<div class="muted pop-hint">クリックで固定。固定中は、リンクを押せます。</div>`);
  return parts.join("");
}

function confidenceBadge(cluster) {
  const label = { high: "信頼度 高", mid: "信頼度 中", low: "信頼度 低" }[cluster.confidence];
  if (!label) return "";
  const info = {
    confidence: cluster.confidence, confidenceReasons: cluster.confidenceReasons, clusterKey: cluster.key,
    medianMan: cluster.hammerMedianMan, ownCount: cluster.ownCount, compCount: cluster.compCount, compLots: cluster.compLots, exampleCode: cluster.examples[0]?.ussCode || "",
    retailEstimateYen: cluster.retailEstimateYen, retailPickLabel: cluster.retailPickLabel, retailSource: cluster.retailSource,
    csLowYen: cluster.carsensor.lowYen, csCount: cluster.carsensor.sampleCount || 0, carsensorUrl: cluster.carsensor.searchUrl,
    gooMedianYen: cluster.goonet.medianYen ?? null, gooCount: cluster.goonet.sampleCount || 0, goonetUrl: cluster.goonet.searchUrl,
  };
  return `<span class="conf ${cluster.confidence} pop" tabindex="0" ${popAttr(confidencePop(info))}>${label}</span>`;
}

function basisBadge(cluster) {
  if (cluster.retailSource === "goonet") return `<em class="basis warn tip" tabindex="0" data-tip="カーセンサーで読めなかったため、&#10;グーネットの参考値を使っています。">グーネット参考</em>`;
  if (cluster.retailBasis === "grade") return `<em class="basis ok tip" tabindex="0" data-tip="${escapeAttr(`小売の見積りは、カーセンサーの\n「${cluster.csGradeName}」だけで比べています。\n（グレード違いの車は混ざっていません）`)}">グレード指定</em>`;
  return `<em class="basis warn tip" tabindex="0" data-tip="${escapeAttr("グレードを指定せずに探した相場です。\n上位グレードも混ざるので、\n差額は大きめに出ます。")}">グレード未指定</em>`;
}

function clusterTable(clusters) {
  // USSの欄は、中央値の計算に使った落札の一覧を、行の下に開く（くわしくの一覧と同じもの）
  return `<div class="scroll"><table><thead><tr><th>条件</th><th>仕入</th><th>差額（粗利の目安）</th><th>参考ページ</th><th>USS</th></tr></thead><tbody>${clusters.map((cluster) => `<tr>
    <td>${escapeHtml(cluster.label.replace(/　/g, " "))}</td>
    <td>${man(cluster.costYen)}</td>
    <td>${man(cluster.gapYen)}（${cluster.gapRate}%）</td>
    <td class="links">${siteLink("カーセンサー", cluster.carsensor)}${siteLink("グーネット", cluster.goonet)}</td>
    <td><button type="button" class="small" data-comps="${escapeAttr(cluster.key)}">${cluster.compCount}台の一覧</button></td>
  </tr><tr class="comps-row" hidden><td colspan="5"><div class="comps-box" data-comps-box="${escapeAttr(cluster.key)}" hidden></div></td></tr>`).join("")}</tbody></table></div>`;
}

async function readMarkets(list, count = list.length, force = false) {
  if (reading) return;
  reading = true;
  stopReading = false;
  const progress = document.getElementById("progress");
  const stop = document.getElementById("stop");
  const read = document.getElementById("read");
  const readAll = document.getElementById("read-all");
  const bar = document.getElementById("read-bar");
  if (stop) stop.hidden = false;
  if (read) read.disabled = true;
  if (readAll) readAll.disabled = true;
  const codes = [...new Set(list.map((cluster) => cluster.modelCode))];
  let total = count; // 読む件数（わかる範囲で。読みながら、正しい数に直す）
  let finished = 0;
  let idle = 0;
  etaReset();
  if (bar) { bar.hidden = false; bar.max = Math.max(total, 1); bar.value = 0; }
  while (!stopReading) {
    if (progress) progress.textContent = `小売相場を読んでいます（${finished}/${total}件）${etaText("read", total - finished)}　確認画面が出たら止まります。`;
    const result = await postJson("/api/market/run", { limit: 1, modelCodes: codes.join(","), force, start: force && finished === 0 && idle === 0 });
    if (result.blocked) { if (progress) progress.textContent = result.message; break; }
    if (result.started === false) { if (progress) progress.textContent = "ほかの読み取りが動いています。終わってから、もう一度押してください。"; break; }
    finished += result.finished || 0;
    total = Math.max(total, finished + (result.remaining || 0));
    if (bar) { bar.max = Math.max(total, 1); bar.value = finished; }
    idle = result.finished ? 0 : idle + 1;
    if (!result.remaining || idle >= 3) break;
  }
  etaReset();
  reading = false;
  if (!stopReading && finished) toast(`小売相場を読みました（${finished}件）`);
  await load();
}

function activeSettings() {
  if (filterCar) return { ...state.settings, ...(state.settings.carConditions?.[filterCar] || {}) };
  return state.settings;
}

function conditionFields(settings) {
  return `
    <div class="row">
      <label>年式から<input id="year-from" type="number" value="${settings.yearFrom ?? ""}" placeholder="下限なし"></label>
      <label>年式まで<input id="year-to" type="number" value="${settings.yearTo ?? ""}" placeholder="上限なし"></label>
      <label>年式を前後（年）<input id="year-window" type="number" min="0" value="${settings.yearWindow}"></label>
    </div>
    <div class="row">
      <label>走行から（万km）<input id="mileage-from" type="number" min="0" step="0.1" value="${manInput(settings.mileageFromKm)}" placeholder="下限なし"></label>
      <label>走行まで（万km）<input id="mileage-to" type="number" min="0" step="0.1" value="${manInput(settings.mileageToKm)}" placeholder="上限なし"></label>
      <label>走行をまとめる幅（万km）<input id="band" type="number" min="0.1" step="0.1" value="${settings.bandKm / 10000}"></label>
      <label>走行を前後に広げる（万km）<input id="mileage-window" type="number" min="0" step="0.1" value="${settings.mileageWindowKm / 10000}"></label>
    </div>
    <div class="row">
      <label>評価点の下限<input id="score" type="number" step="0.5" value="${settings.minScore}"></label>
      <label>まとまりの最少台数<input id="samples" type="number" value="${settings.minSamples}"></label>
    </div>
    <div class="checks inline">
      <label><input id="match-grade" type="checkbox" ${settings.matchGrade ? "checked" : ""}>グレードを揃える</label>
      <label><input id="match-color" type="checkbox" ${settings.matchColor ? "checked" : ""}>色を揃える</label>
      <label><input id="match-equipment" type="checkbox" ${settings.matchEquipment ? "checked" : ""}>ナビ・アルミホイールを揃える（純正・社外は区別できません）</label>
      <label><input id="match-sr-leather" type="checkbox" ${settings.matchSunroofLeather ? "checked" : ""}>サンルーフ・革も揃える</label>
      <label><input id="match-drive" type="checkbox" ${settings.matchDrive ? "checked" : ""}>駆動を揃える</label>
    </div>
    <p class="muted">空欄の年式・走行は、その車種の落札データにある範囲を使います。エアコン、アルミ、パワステ、パワーウィンドウは分けません。</p>`;
}

async function saveConditions() {
  showCond = true;
  const body = {
    minScore: document.getElementById("score").value,
    minSamples: document.getElementById("samples").value,
    yearWindow: document.getElementById("year-window").value,
    yearFrom: document.getElementById("year-from").value.trim(),
    yearTo: document.getElementById("year-to").value.trim(),
    mileageFromKm: manToKm("mileage-from"),
    mileageToKm: manToKm("mileage-to"),
    bandKm: manToKm("band"),
    mileageWindowKm: manToKm("mileage-window"),
    matchGrade: document.getElementById("match-grade").checked ? "1" : "0",
    matchColor: document.getElementById("match-color").checked ? "1" : "0",
    matchEquipment: document.getElementById("match-equipment").checked ? "1" : "0",
    matchSunroofLeather: document.getElementById("match-sr-leather").checked ? "1" : "0",
    matchDrive: document.getElementById("match-drive").checked ? "1" : "0",
  };
  await postJson("/api/settings", filterCar ? { ...body, carName: filterCar } : body);
  await load();
}

// ====================================================================
// 出品予定（下見検索）：次回の出品車と、上限落札額
// ====================================================================

let upcomingTimer = null;

async function renderUpcoming() {
  clearTimeout(upcomingTimer);
  const token = ++paint;
  const data = await getJson("/api/upcoming");
  if (token !== paint) return;
  const items = data.items || [];
  const chosen = selectedModelCodes();
  const visible = showUnselected ? items : items.filter((item) => chosen.has(item.modelCode));
  const picks = visible.filter((item) => item.verdict === "ok" || item.verdict === "cheap")
    .sort((a, b) => (a.verdict === b.verdict ? b.marginMan - a.marginMan : a.verdict === "ok" ? -1 : 1));
  const ng = visible.filter((item) => item.verdict === "ng");
  const none = visible.filter((item) => item.verdict === "none");
  const why = {};
  for (const item of none) why[item.reason] = (why[item.reason] || 0) + 1;
  const dates = [...new Set(visible.map((item) => item.auctionDate))].map((date) => date.slice(5).replace("-", "/"));
  const venues = [...new Set(visible.map((item) => item.venue))].join("・");
  const fetched = visible[0]?.fetchedAt;
  const running = data.job.running || data.auto.running;

  view.innerHTML = `
    ${viewerNotice()}
    ${criteriaHtml()}
    ${staleBannerHtml(profitSummary().all, profitSummary().waiting)}
    <section class="card">
      <div class="row between">
        <h2>次回の出品予定${venues ? `：${escapeHtml(venues)} ${escapeHtml(dates.join("・"))}` : ""}</h2>
        <span class="pill ${data.bridge.connected ? "ok" : "off"}">${data.bridge.connected ? "つながっています" : "つながっていません"}</span>
      </div>
      <p class="muted">USSの下見検索を、<b>見るだけ</b>で読みます（入札・セリ・ライブには触れません）。</p>
      ${upcomingStatusHtml(items)}
      <div class="up-how"><b>このボタンで取得するもの</b>
        <ul>
          <li>対象：<b>${escapeHtml(upTargetText())}</b>（「取得」タブで選んだ会場・車種です。変更は、「取得」タブで行います）</li>
          <li>内容：その会場の、次回の開催の<b>出品予定</b>（出品番号・年式・走行・評価・スタート金額など）を、USSの下見検索から読みます。</li>
          <li>そのあと：過去の落札相場・小売相場と比べて、<b>上限落札額</b>と、◎○の判定を出します。</li>
        </ul></div>
      <div class="row">
        <button id="up-run" type="button" class="primary" ${running || state.viewerOnly ? "disabled" : ""}>出品予定を取得して、入札車を選ぶ</button>
        <button id="up-cancel" type="button" class="secondary" ${data.job.running ? "" : "hidden"}>キャンセル</button>
        ${picks.length ? `<button id="up-csv" type="button" class="secondary">候補をCSVで保存</button>` : ""}
        <span class="muted">${fetched ? `最終取得 ${escapeHtml(stamp(fetched))}` : "まだ取得していません"}</span>
      </div>
      <progress id="up-bar" max="1" value="0" hidden></progress>
      <p id="up-progress" class="${upcomingNotice ? "warn err-msg" : "muted"}">${escapeHtml(upcomingNotice || data.auto.message || "")}</p>
    </section>

    ${visible.length ? `
    <section class="hero">
      <div class="hero-main ${picks.length ? "good" : ""}"><b>${picks.length}</b><span>台が、候補です</span></div>
      <div class="hero-side">
        <div>出品予定 <b>${visible.length}台</b>のうち　◎ <b>${picks.filter((p) => p.verdict === "ok").length}</b>台　○ <b>${picks.filter((p) => p.verdict === "cheap").length}</b>台　×（上限が低すぎる）${ng.length}台　判定できず ${none.length}台</div>
        <div class="muted">◎ 過去の落札の中央値で買っても、仕入れ候補の条件を満たす（入札してよい）　／　○ 中央値より安く買えれば、条件を満たす（上限が、過去の最安の落札より低いものは、×）</div>
        <div class="muted">上限は、小売の見積りから、目標の利益と諸経費を引いた、落札額（税別）の目安です。</div>
      </div>
    </section>

    ${picks.length ? `<div class="scroll"><table class="pick-table"><thead><tr><th></th><th>予想時刻</th><th>No.</th><th>車</th><th>年式・走行・色</th><th>評価</th><th>スタート</th><th>上限落札額</th><th>想定利益<br><span class="muted">（上限で落札）</span></th><th>過去の中央値</th><th>信頼度</th></tr></thead><tbody>
      ${picks.map(upcomingRow).join("")}</tbody></table></div>` : `<section class="card empty">候補になる出品車は、ありませんでした。</section>`}

    <details class="card fold"><summary>判定できなかった車（${none.length}台）と、その理由</summary>
      <ul class="plain">${Object.entries(why).sort((a, b) => b[1] - a[1]).map(([reason, count]) => `<li>${escapeHtml(reason)}：${count}台</li>`).join("")}</ul>
      <p class="muted">「同じ型式・グレードの落札が少ない」ものが多いときは、落札データが足りません。取得期間を長くするか、会場を増やすと、判定できる車が増えます。</p>
    </details>
    ${ng.length ? `<details class="card fold"><summary>上限が低すぎて、落札が難しい車（${ng.length}台）</summary><div class="scroll"><table class="pick-table"><tbody>${ng.slice(0, 80).map((item) => `<tr><td>${escapeHtml(item.auctionTime || "")}</td><td>No.${escapeHtml(item.lotNo)}</td><td>${escapeHtml(item.modelName)} ${escapeHtml(item.grade)}</td><td>${item.year}年 ${km(item.mileageKm)}</td><td>スタート ${item.startMan ?? "—"}万</td><td>上限 ${item.hammerMaxMan}万</td><td>過去の最安 ${item.lowMan ?? "—"}万／中央値 ${item.medianMan}万</td><td class="muted">${escapeHtml(item.reason || "")}${item.approx ? ` <span class="warn">※注：${item.approxKind === "color" ? "色違いの相場を代用" : item.approxKind === "grade" ? "グレード・色違いの相場を代用" : "近い条件の相場を代用"}</span>` : ""}</td></tr>`).join("")}</tbody></table></div></details>` : ""}` : `<section class="card empty">${data.bridge.connected ? "「出品予定を取得して、入札車を選ぶ」を押してください。" : "USBキーでUSSにログインしたChromeを開いてください。"}</section>`}

    ${data.lastAuto ? `<details class="card fold"><summary>自動取得の、最後の結果</summary><pre class="note">${escapeHtml(data.lastAuto.body)}</pre></details>` : ""}`;

  bindCriteria();
  document.getElementById("read")?.addEventListener("click", () => readMarkets(profitSummary().waiting));
  document.getElementById("read-all")?.addEventListener("click", () => { const all = profitSummary().all; readMarkets(all, all.length, true); });
  document.getElementById("stop")?.addEventListener("click", () => { stopReading = true; });
  document.getElementById("up-run")?.addEventListener("click", async () => {
    if (!data.bridge.connected) { showUsbError("up-progress", true, "bridge"); return; }
    const response = await fetch("/api/upcoming/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    const result = await response.json();
    upcomingNotice = "";
    if (result.error) upcomingNotice = result.error;
    watchUpcoming();
  });
  document.getElementById("up-cancel")?.addEventListener("click", async (event) => {
    event.target.disabled = true;
    await postJson("/api/upcoming/cancel", {});
    watchUpcoming();
  });
  document.getElementById("up-csv")?.addEventListener("click", () => downloadCsv("入札車の選定", ["判定", "予想時刻", "出品番号", "車名", "型式", "グレード", "年式", "走行(km)", "色", "装備", "評価", "スタート(万円)", "上限落札額(万円)", "想定利益(円)", "過去の中央値(万円)", "信頼度"],
    picks.map((item) => [item.verdict === "ok" ? "◎" : "○", item.auctionTime, item.lotNo, item.modelName, item.modelCode, item.grade, item.year, item.mileageKm, item.color, item.equipment, item.score ?? item.scoreRaw, item.startMan, item.hammerMaxMan, item.profitAtMax ? item.profitAtMax.profitYen : "", item.medianMan, { high: "高", mid: "中", low: "低" }[item.confidence] || ""])));
  if (!running && /ログイン/.test(data.job.error || "")) checkUssLogin("up-progress");
  if (running) watchUpcoming();
}

function upcomingRow(item) {
  // ◎／○の吹き出し（押せる吹き出し。表の枠で切れない）
  const markPop = [
    `<div class="pop-title">${item.verdict === "ok" ? "◎ 過去の落札の中央値で買っても、条件を満たす（入札してよい）" : "○ 中央値より安く買えれば、条件を満たす"}</div>`,
    `<div class="pop-row"><div><b>上限落札額</b><span class="amt">${item.hammerMaxMan}万円</span></div><div class="muted">過去の中央値 ${item.medianMan}万円（上限が ${item.marginMan >= 0 ? "+" : ""}${item.marginMan}万円）</div></div>`,
    item.profitAtMax ? `<div class="pop-row"><div><b>想定利益（上限で落札）</b><span class="amt">${item.profitAtMax.profitYen >= 0 ? "+" : ""}${man(item.profitAtMax.profitYen)}</span></div><div class="muted">仕入 ${man(item.profitAtMax.costYen)}（諸経費込）／仕入の${item.profitAtMax.rate}%</div></div>` : "",
    `<div class="pop-row"><div><b>小売の見積り</b><span class="amt">${man(item.retailEstimateYen)}</span></div><div class="muted">${escapeHtml(item.retailPickLabel || "")}</div></div>`,
    item.csGradeName ? `<div class="muted">カーセンサーのグレード：${escapeHtml(item.csGradeName)}</div>` : "",
    item.approx ? `<div class="warn">※注：${escapeHtml(item.approx)}</div><div class="muted">代用した条件：${escapeHtml(item.matchedLabel)}</div>` : "",
  ].filter(Boolean).join("");
  const conf = { high: "高", mid: "中", low: "低" }[item.confidence] || "";
  // 出品予定の車：落札・小売の金額に加えて、スタート金額と上限落札額も、吹き出しに入れる
  const confPop = confidencePop({ ...item, ownCount: item.ownCount, exampleCode: item.exampleCode })
    .replace(`<hr>`, `<hr><div class="pop-row"><div><b>この出品車</b><span class="amt">上限 ${item.hammerMaxMan}万円</span></div><div class="muted">スタート ${item.startMan == null ? "—" : item.startMan + "万円"}／過去の中央値 ${item.medianMan}万円（税別の落札額）</div></div>`);
  return `<tr class="${item.verdict}">
    <td><span class="mark pop" tabindex="0" ${popAttr(markPop)}>${item.verdict === "ok" ? "◎" : "○"}</span></td>
    <td class="nowrap">${escapeHtml(item.auctionTime || "")}</td>
    <td class="nowrap">${escapeHtml(item.lotNo)}</td>
    <td><b>${escapeHtml(item.modelName)}</b> ${escapeHtml(item.grade)}<br><span class="muted">${escapeHtml(item.modelCode)}${item.approx ? `　<span class="warn">※注：${item.approxKind === "color" ? "色違いの相場を代用" : item.approxKind === "grade" ? "グレード・色違いの相場を代用" : "近い条件の相場を代用"}</span>` : ""}</span></td>
    <td class="nowrap">${item.year}年・${km(item.mileageKm)}<br><span class="muted">${escapeHtml(item.color)}　${escapeHtml(item.equipment)}</span></td>
    <td>${item.score ?? escapeHtml(item.scoreRaw)}</td>
    <td class="nowrap">${item.startMan == null ? "—" : item.startMan + "万"}</td>
    <td class="nowrap maxbid">${item.hammerMaxMan}万円</td>
    <td class="nowrap profit ${item.profitAtMax && item.profitAtMax.profitYen < 0 ? "neg" : ""}">${item.profitAtMax ? `<b>${item.profitAtMax.profitYen >= 0 ? "+" : ""}${(item.profitAtMax.profitYen / 10000).toFixed(1)}万円</b><br><span class="muted">仕入の${item.profitAtMax.rate}%</span>` : "—"}</td>
    <td class="nowrap">${item.medianMan}万円<br><span class="muted">${item.marginMan >= 0 ? "上限が +" + item.marginMan : "上限が " + item.marginMan}万</span></td>
    <td><span class="conf ${item.confidence} pop" tabindex="0" ${popAttr(confPop)}>${conf}</span></td>
  </tr>`;
}

async function watchUpcoming() {
  clearTimeout(upcomingTimer);
  const progress = document.getElementById("up-progress");
  const bar = document.getElementById("up-bar");
  const button = document.getElementById("up-run");
  const cancel = document.getElementById("up-cancel");
  if (!progress) return;
  let data;
  try { data = await getJson("/api/upcoming"); } catch { return; }
  const job = data.job;
  const running = job.running || data.auto.running;
  if (button) button.disabled = running || state.viewerOnly;
  if (cancel) { cancel.hidden = !job.running; if (!job.running) cancel.disabled = false; }
  if (bar) { bar.hidden = !running; bar.max = Math.max(job.total, 1); bar.value = job.done; }
  progress.textContent = running
    ? (data.auto.running ? `${data.auto.step}…　` : "") + (job.running ? `出品予定を取得中（${job.done}/${job.total}・残り ${Math.max(job.total - job.done, 0)}件）${etaText("upcoming", job.total - job.done)}　${job.message}` : "")
    : (etaReset(), upcomingNotice || job.error || data.auto.message || (job.message || ""));
  progress.className = upcomingNotice && !running ? "warn err-msg" : "muted";
  if (running) { upcomingNotice = ""; upcomingTimer = setTimeout(watchUpcoming, 3000); }
  else if (tab === "upcoming") await renderUpcoming();
}

// ====================================================================
// 取得
// ====================================================================

function renderCollect() {
  const settings = state.settings;
  const targets = new Set(settings.targetVenues);
  const collect = (state.today && state.today.collect) || { enabled: false };
  const saved = new URLSearchParams(location.search).get("saved");
  view.innerHTML = `
    ${viewerNotice()}
    <div class="g2c wide-left">
      <div>
        <section class="pn step">
          <div class="t"><i class="stepno">1</i>会場<span>1〜2か所がおすすめです</span></div>
          <div class="chips" id="venue-chips">${state.venues.map((venue) => `<label class="chip check${targets.has(venue.code) ? " on" : ""}"><input type="checkbox" data-target-venue value="${escapeAttr(venue.code)}" ${targets.has(venue.code) ? "checked" : ""}>${escapeHtml(venue.name)}</label>`).join("")}</div>
        </section>

        <section class="pn step">
          <div class="t"><i class="stepno">2</i>取得する車種<span>USSから持ってくる車種です。表示する車種は「仕入れ車種の選定」で別に選べます</span></div>
          <div id="picked" class="chips"></div>
          <div class="row">
            <input id="car-search" class="grow" placeholder="車名やメーカーで探す（例：プリウス、トヨタ）" value="${escapeAttr(pickQuery)}" autocomplete="off">
          </div>
          <div id="car-results" class="chips results"></div>
          <details class="more" id="browse"><summary>一覧から選ぶ（国 → メーカー → 車名）</summary>
            <div id="browse-body"></div>
          </details>
        </section>

        <section class="pn step">
          <div class="t"><i class="stepno">3</i>取得する</div>
          <div class="row run-row">
            <label>期間<select id="collect-term"><option value="1">直近1回の開催</option><option value="4">直近4回</option><option value="8">直近8回</option><option value="12">直近12回（最大）</option></select></label>
            <button id="collect-run" type="button" class="primary big">USSから落札データを取得して、小売相場を読む</button>
            <button id="collect-cancel" type="button" class="secondary" hidden>キャンセル</button>
          </div>
          <p class="flow"><b>この順番で進みます：</b><span id="flow-1"><i>①</i>USSから落札データを取得</span><em>→</em><span id="flow-2"><i>②</i>取得した車の小売相場（カーセンサー・グーネット）を調べる</span></p>
          <p class="row"><label class="inline"><input id="collect-force" type="checkbox"> すべて取り直す（保存済みの分も、もう一度取得する）</label></p>
          <p class="muted">ふだんは、チェックなしで構いません。すでに取得した開催回は取り直さず、新しい回だけを取るので、速く終わります。取得の詳細条件を変えたときは、自動で全部取り直します。</p>
          <progress id="collect-bar" max="1" value="0" hidden></progress>
          <p id="collect-progress" class="${collectNotice ? "warn err-msg" : "muted"}">${collectNotice ? escapeHtml(collectNotice) : saved ? escapeHtml(saved) + "台を取り込みました。" : ""}</p>
          <p class="muted">相場検索の画面だけを読みます。セリ・ライブ・入札には触れません。取得は、USBキーでUSSにログインしたChromeを開いたまま行ってください。</p>
        </section>

        <details class="pn fold" id="filter-box">
          <summary>取得の詳細条件（USSの「さらに詳細条件を指定する」と同じ）　<span class="muted">今の条件：${escapeHtml(state.filtersSummary)}</span></summary>
          ${filterPanelHtml(settings.collectFilters)}
        </details>
      </div>

      <div>
        <section class="pn">
          <div class="t">USSとの接続<span id="bridge-pill" class="pill off">確認中…</span></div>
          <p id="bridge-state" class="muted"></p>
          <p class="muted">最終取得 ${escapeHtml(stamp(state.lastImportedAt))}（落札データ ${state.lotCount.toLocaleString()}台）</p>
        </section>

        <details class="pn fold" id="setup-box">
          <summary id="setup-summary">このPCの準備を確認しています…</summary>
          <div id="setup-body"></div>
        </details>

        <details class="pn fold">
          <summary>自動で取得する（開催の前に自動で取得）　<span class="muted">${settings.autoCollect ? "オン" : "オフ"}</span></summary>
          <p class="row"><label class="inline"><input id="auto" type="checkbox" ${settings.autoCollect ? "checked" : ""}> 自動で取得する</label>
            <label>開催の何日前<input id="days-before" type="number" min="0" max="14" value="${settings.collectDaysBefore}"></label>
            <label>取得する期間<select id="auto-term">${[[1, "直近1回の開催"], [4, "直近4回"], [8, "直近8回"], [12, "直近12回（最大）"]].map(([n, label]) => `<option value="${n}" ${settings.autoCollectTerm === n ? "selected" : ""}>${label}</option>`).join("")}</select></label>
            <button id="save-auto" type="button" class="secondary">保存</button></p>
          <p class="rule"><b>自動で取得する会場</b>（手動の「取得する会場」とは、別です）</p>
          <div class="chips" id="auto-venues">${(state.venues || []).map((venue) => `<button type="button" class="chip${(settings.autoVenues || []).includes(venue.code) ? " on" : ""}" data-auto-venue="${escapeAttr(venue.code)}">${escapeHtml(venue.name)}</button>`).join("")}</div>
          <p class="rule"><b>自動で取得する車種</b>（手動の「取得する車種」とは、別です）</p>
          <div id="auto-cars" class="chips"></div>
          <input id="auto-car-search" class="grow" placeholder="ここで、車名やメーカーで探して、追加します（例：プリウス、トヨタ）">
          <div id="auto-car-results" class="chips"></div>
          <p class="muted">手動の「取得する車種」の札の <b>☆自動</b> からも、追加できます。</p>
          <details class="pn fold" id="auto-filter-box">
            <summary>自動取得の詳細条件（手動の取得の詳細条件とは、別）　<span class="muted">今の条件：${escapeHtml(state.autoFiltersSummary || "条件なし")}</span></summary>
            ${filterPanelHtml(settings.autoFilters, "-auto", true)}
          </details>
          <details class="pn fold" id="auto-rules-box">
            <summary>車種ごとの条件（ルール）　<span class="muted" id="auto-rules-count">${(settings.autoRules || []).length}件</span></summary>
            <p class="muted">同じ条件を、まとめて、いくつもの車種に付けたいときに使います。下の順に、入れます。<br>
              ① <b>対象の種類</b>を選ぶ（区分・メーカー・車名に含む言葉・車種）<br>
              ② <b>対象</b>を入れる（メーカーなら「BMW」、車名に含む言葉なら「プリウス」。「全部」と、書く必要はありません）<br>
              ③ <b>条件</b>を入れる（入れた項目だけが、効きます）</p>
            <p class="muted">例：種類「メーカー」・対象「BMW」・走行「まで10」→ BMWの車は、すべて、走行10万kmまでを取る。／ 種類「車名に含む言葉」・対象「プリウス」・年式「から2018」→ プリウス、プリウスα、プリウスPHVを、すべて、2018年以降だけ取る。<br>入れた項目は、上の「自動取得の詳細条件」に、上書きされます。<b>せまい指定が優先</b>されます。（車種 ＞ 車名に含む言葉 ＞ メーカー ＞ 区分 ＞ 自動取得の詳細条件）</p>
            <div id="auto-rules-list"></div>
            <div class="rule-form">
              <div class="row">
                <label>対象の種類<select id="rule-kind"><option value="class">区分</option><option value="maker">メーカー</option><option value="word">車名に含む言葉</option><option value="car">車種</option></select></label>
                <label id="rule-target-label">対象<span id="rule-target-box"></span></label>
              </div>
              <div class="row">
                <label>年式から<input type="number" id="rule-yearFrom" placeholder="例：2018"></label><label>まで<input type="number" id="rule-yearTo"></label>
                <label>走行（万km）から<input type="number" step="0.5" id="rule-mileageFromK"></label><label>まで<input type="number" step="0.5" id="rule-mileageToK" placeholder="例：10"></label>
              </div>
              <div class="row">
                <label>落札額（万円）から<input type="number" id="rule-priceFromSen"></label><label>まで<input type="number" id="rule-priceToSen" placeholder="例：150"></label>
                <label>評価点<select id="rule-scores"><option value="">指定なし</option><option value="4up">4以上</option></select></label>
              </div>
              <p class="row"><button type="button" id="rule-save">ルールを追加</button><button type="button" class="secondary" id="rule-cancel" hidden>編集をやめる</button><span id="rule-msg" class="muted"></span></p>
            </div>
          </details>
          <p class="row"><button id="auto-run" type="button" class="primary">今すぐ実行する</button><button id="auto-cancel" type="button" class="secondary" hidden>キャンセル</button></p>
          <p id="auto-run-progress" class="muted"></p>
          <p class="muted">初回の設定のときや、情報を最新にしたいときに、押せます。<b>自動取得と同じ流れ</b>を、いま、1回、行います（日付や、上の「自動で取得する」のオン・オフに関係なく、動きます）。上の「取得する期間」で、①落札データを取得 → ②小売相場を読む → ③次回の出品予定を取得 → ④入札車の候補を計算して、通知します。初回は、「直近12回」にしておくと、相場の元になる落札データが、まとめて入ります。対象は、この欄の「自動で取得する会場」と「自動で取得する車種」です（手動の取得とは、別です）。USBキーでUSSにログインしたChromeが必要です。10〜30分かかります。</p>
          <p class="muted">オンにすると、この欄で選んだ会場の開催の○日前（会場の開催曜日は、設定で決めます）に、システムが自動で、① 落札相場の取得（上で選んだ回数分。回数が多いほど時間がかかります）→ ② 小売相場の更新 → ③ 次回の出品予定の取得 → ④ 入札車の候補と上限落札額の計算 を行い、通知します。結果は「入札車の選定」タブでも見られます。</p>
          <p class="muted">PCが起動していて、USBキーでUSSにログインしたChromeが開いている日だけ動きます。つながっていないときは、その旨を通知します。入札・セリ・ライブには触れません。</p>
        </details>

        <details class="pn fold">
          <summary>小売相場を、毎週自動で読み直す　<span class="muted">${settings.autoRead ? `オン（毎週${"日月火水木金土"[settings.autoReadWeekday]}曜 ${settings.autoReadHour}:00）` : "オフ"}</span></summary>
          <p class="row"><label class="inline"><input id="auto-read" type="checkbox" ${settings.autoRead ? "checked" : ""}> 毎週、自動で読み直す</label>
            <label>曜日<select id="auto-read-day">${[...Array(7).keys()].map((n) => `<option value="${n}" ${settings.autoReadWeekday === n ? "selected" : ""}>${"日月火水木金土"[n]}曜</option>`).join("")}</select></label>
            <label>時刻<select id="auto-read-hour">${[...Array(24).keys()].map((n) => `<option value="${n}" ${settings.autoReadHour === n ? "selected" : ""}>${n}:00</option>`).join("")}</select></label>
            <button id="save-auto-read" type="button" class="secondary">保存</button></p>
          <p class="muted">前回の読み直し：${settings.autoReadLast ? escapeHtml(stamp(settings.autoReadLast)) : "まだありません（オンにした直後は、すぐには動かず、次の予定の時刻から始めます）"}</p>
          <p class="muted">「表示する車種」の小売相場（カーセンサー・グーネット）を、古さに関係なく、すべて読み直します。USBキーもChromeも要りません（公開ページを読むだけです）。件数にもよりますが、50件で10分前後かかります。</p>
          <p class="muted">その時刻に、PCが起動していて、このシステムが動いている必要があります。動けなかったときは、次に起動したときに読み直します。サイトの確認画面が出たときは、止まって通知します。小売相場は、読んでから7日を過ぎると「古い」とみなし、古いものは候補に含めません。</p>
        </details>

        <details class="pn fold">
          <summary>Excel・ブックマークから取り込む</summary>
          <h3>Excelから</h3>
          <input id="file" type="file" accept=".xlsx">
          <p id="import-msg" class="muted"></p>
          <h3>USSで開いている一覧から</h3>
          <p class="muted">下のボタンをブックマークバーへドラッグし、USSの相場検索の一覧を開いて押します。今見えている1ページだけを渡します。</p>
          <p><a class="linkbtn bookmark" href="${bookmarklet}">USSの結果を取り込む</a></p>
        </details>
      </div>
    </div>`;

  if (state.viewerOnly) for (const id of ["collect-run", "collect-force", "collect-term", "save-auto", "auto-run", "auto", "days-before", "auto-term", "save-auto-read", "auto-read", "auto-read-day", "auto-read-hour"]) { const el = document.getElementById(id); if (el) el.disabled = true; }
  paintPicked();
  paintResults();
  watchCollect();
  loadSetup(false);
  bindFilterPanel();
  bindFilterPanel("auto-filter-box", "autoFilters", "autoFiltersSummary", "-auto");

  document.getElementById("car-search").addEventListener("input", (event) => { pickQuery = event.target.value; paintResults(); });
  paintBrowse();
  view.querySelectorAll("[data-target-venue]").forEach((box) => box.addEventListener("change", async () => {
    box.closest(".chip").classList.toggle("on", box.checked);
    const codes = [...view.querySelectorAll("[data-target-venue]:checked")].map((item) => item.value);
    state.settings.targetVenues = codes;
    await postJson("/api/settings", { targetVenues: codes.join(",") });
  }));
  document.getElementById("collect-run").onclick = async () => {
    const progress = document.getElementById("collect-progress");
    collectNotice = "";
    document.querySelectorAll(".usb-err").forEach((el) => el.remove());
    const response = await fetch("/api/collect/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ term: Number(document.getElementById("collect-term").value), force: document.getElementById("collect-force").checked }) });
    const result = await response.json();
    if (result.error) { if (/つながっていません/.test(result.error)) showUsbError("collect-progress", true, "bridge"); else if (/ログイン/.test(result.error)) showUsbError("collect-progress", true, "login"); else collectNotice = result.error; }
    watchCollect();
  };
  document.getElementById("collect-cancel").onclick = async (event) => {
    event.target.disabled = true;
    await postJson("/api/collect/cancel", {});
    watchCollect();
  };
  paintAutoCars();
  bindAutoRules();
  document.getElementById("auto-car-search")?.addEventListener("input", paintAutoResults);
  view.querySelectorAll("[data-auto-venue]").forEach((button) => button.addEventListener("click", async () => {
    const codes = new Set(state.settings.autoVenues || []);
    if (codes.has(button.dataset.autoVenue)) codes.delete(button.dataset.autoVenue); else codes.add(button.dataset.autoVenue);
    state.settings.autoVenues = [...codes];
    button.classList.toggle("on", codes.has(button.dataset.autoVenue));
    await postJson("/api/settings", { autoVenues: [...codes].join(",") });
  }));
  document.getElementById("auto-run").onclick = async () => {
    autoRunNotice = "";
    const response = await fetch("/api/auto/run", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ term: Number(document.getElementById("auto-term").value) }) });
    const result = await response.json();
    if (result.error) autoRunNotice = result.error;
    watchAutoRun();
  };
  document.getElementById("auto-cancel").onclick = async (event) => {
    event.target.disabled = true;
    await postJson("/api/auto/cancel", {});
    watchAutoRun();
  };
  watchAutoRun();
  document.getElementById("save-auto").onclick = async () => {
    await postJson("/api/settings", {
      autoCollect: document.getElementById("auto").checked ? "1" : "0",
      collectDaysBefore: document.getElementById("days-before").value,
      autoCollectTerm: document.getElementById("auto-term").value,
    });
    await load();
  };
  document.getElementById("save-auto-read").onclick = async () => {
    await postJson("/api/settings", {
      autoRead: document.getElementById("auto-read").checked ? "1" : "0",
      autoReadWeekday: document.getElementById("auto-read-day").value,
      autoReadHour: document.getElementById("auto-read-hour").value,
    });
    await load();
  };
  document.getElementById("file").onchange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const msg = document.getElementById("import-msg");
    msg.textContent = "取り込んでいます。";
    const spin = document.createElement("progress"); // 長さが分からないので、動き続けるバー
    msg.after(spin);
    const response = await fetch("/api/import/excel", {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream", "X-Filename": encodeURIComponent(file.name) },
      body: await file.arrayBuffer(),
    });
    const data = await response.json();
    spin.remove();
    msg.textContent = data.error || `${data.message} 保存 ${data.saved}台。`;
    await load();
  };
}

// ---- 取得の詳細条件（USSの「さらに詳細条件を指定する」と同じ項目） ----

// p：欄を2つ（手動用・自動用）置くための、ボタンの印（手動用は空、自動用は "-auto"）。auto：自動取得用の欄か
function filterPanelHtml(f, p = "", auto = false) {
  const opts = state.filterOptions;
  const tri = (name, value) => `<select data-f="equip.${name}"><option value="" ${value === "" ? "selected" : ""}>指定なし</option><option value="1" ${value === "1" ? "selected" : ""}>あり</option><option value="0" ${value === "0" ? "selected" : ""}>なし</option></select>`;
  const val = (v) => (v === null || v === undefined ? "" : v);
  return `
    <p class="muted">${auto ? "ここで指定した条件は、<b>自動取得（開催の前の自動・「今すぐ実行する」）</b>に付きます。手動の取得の条件とは、別です。" : "ここで指定した条件は、「取得」と「出品予定の取得」に付きます。"}USSの検索画面と、同じ意味です。<b>絞るほど、取れるデータは減る</b>ので、必要なときだけ指定してください（相場は、取得済みのデータ全体で計算します）。</p>
    <div class="filter-grid">
      <div class="filter-block"><h3>年式・走行</h3>
        <div class="row"><label>年式（西暦）から<input type="number" data-f="yearFrom" value="${val(f.yearFrom)}"></label><label>まで<input type="number" data-f="yearTo" value="${val(f.yearTo)}"></label></div>
        <div class="row"><label>走行（万km）から<input type="number" step="0.5" data-f="mileageFromK" data-scale="10" value="${f.mileageFromK == null ? "" : f.mileageFromK / 10}"></label><label>まで<input type="number" step="0.5" data-f="mileageToK" data-scale="10" value="${f.mileageToK == null ? "" : f.mileageToK / 10}"></label></div>
        <div class="checks inline"><label><input type="checkbox" data-f="excludeTamper" ${f.excludeTamper ? "checked" : ""}>メーター改ざんを除く</label><label><input type="checkbox" data-f="excludeExchange" ${f.excludeExchange ? "checked" : ""}>メーター交換を除く</label><label><input type="checkbox" data-f="excludeUnknown" ${f.excludeUnknown ? "checked" : ""}>走行不明を除く</label></div>
        <div class="row"><label>排気量（cc）から<input type="number" data-f="displacementFrom" value="${val(f.displacementFrom)}"></label><label>まで<input type="number" data-f="displacementTo" value="${val(f.displacementTo)}"></label></div>
      </div>
      <div class="filter-block"><h3>評価点</h3>
        <div class="checks inline">${opts.scores.map(([label, code]) => `<label><input type="checkbox" data-f-score="${code}" ${f.scores.includes(code) ? "checked" : ""}>${escapeHtml(label)}</label>`).join("")}</div>
        <p class="row"><button type="button" class="small secondary" id="score-4up${p}">4以上にする</button><button type="button" class="small secondary" id="score-clear${p}">指定なし</button></p>
      </div>
      <div class="filter-block"><h3>駆動</h3>
        <div class="row"><label>駆動<select data-f="drive"><option value="" ${f.drive === "" ? "selected" : ""}>指定なし</option><option value="1" ${f.drive === "1" ? "selected" : ""}>2WDのみ</option><option value="2" ${f.drive === "2" ? "selected" : ""}>4WDのみ</option></select></label></div>
        <div class="checks"><label><input type="checkbox" data-f="driveSplit" ${f.driveSplit ? "checked" : ""}>2WD／4WDを分けて取得する（USSの一覧に出ない「駆動」を、判別できます）</label></div>
      </div>
      <div class="filter-block"><h3>装備</h3>
        <div class="row">${[["navi", "ナビ"], ["aw", "アルミ"], ["sr", "サンルーフ"], ["leather", "革"], ["ps", "PS"], ["pw", "PW"]].map(([key, label]) => `<label>${label}${tri(key, f.equip[key])}</label>`).join("")}</div>
      </div>
      <div class="filter-block"><h3>グレード・型式</h3>
        <div class="row"><label>グレード<input data-f="gradeText" value="${escapeAttr(f.gradeText)}" placeholder="例：AMG"></label><label>一致<select data-f="gradeMatch"><option value="1" ${f.gradeMatch === "1" ? "selected" : ""}>含む</option><option value="0" ${f.gradeMatch === "0" ? "selected" : ""}>完全一致</option></select></label><label>除く<input data-f="gradeExclude" value="${escapeAttr(f.gradeExclude)}"></label></div>
        <div class="row"><label>型式<input data-f="carTypeText" value="${escapeAttr(f.carTypeText)}" placeholder="例：ZVW50"></label><label>一致<select data-f="carTypeMatch"><option value="1" ${f.carTypeMatch === "1" ? "selected" : ""}>含む</option><option value="0" ${f.carTypeMatch === "0" ? "selected" : ""}>完全一致</option></select></label><label>除く<input data-f="carTypeExclude" value="${escapeAttr(f.carTypeExclude)}"></label></div>
      </div>
      <div class="filter-block"><h3>落札額</h3>
        <div class="row"><label>落札額（万円）から<input type="number" data-f="priceFromSen" data-scale="10" value="${f.priceFromSen == null ? "" : f.priceFromSen / 10}"></label><label>まで<input type="number" data-f="priceToSen" data-scale="10" value="${f.priceToSen == null ? "" : f.priceToSen / 10}"></label></div>
      </div>
      <div class="filter-block wide"><h3>色</h3>
        <div class="checks inline">${opts.colors.map(([label, code]) => `<label><input type="checkbox" data-f-color="${code}" ${f.colors.includes(code) ? "checked" : ""}>${escapeHtml(label)}</label>`).join("")}</div>
        <div class="row"><label>色替え<select data-f="colorChange"><option value="" ${f.colorChange === "" ? "selected" : ""}>指定なし</option><option value="1" ${f.colorChange === "1" ? "selected" : ""}>含む</option><option value="0" ${f.colorChange === "0" ? "selected" : ""}>含まない</option></select></label></div>
      </div>
    </div>
    <p class="row"><button type="button" id="filter-save${p}">この条件を保存</button><button type="button" class="secondary" id="filter-clear${p}">条件をすべて消す</button>${auto ? `<button type="button" class="secondary" id="filter-copy${p}">手動の条件を、コピーする</button>` : ""}<span id="filter-msg${p}" class="muted"></span></p>`;
}

function readFilterPanel(boxId = "filter-box") {
  const box = document.getElementById(boxId);
  const f = { equip: {}, scores: [], colors: [] };
  box.querySelectorAll("[data-f]").forEach((input) => {
    const key = input.dataset.f;
    let value = input.type === "checkbox" ? input.checked : input.value.trim();
    if (input.dataset.scale && value !== "") value = Math.round(Number(value) * Number(input.dataset.scale));
    if (key.startsWith("equip.")) f.equip[key.slice(6)] = value;
    else f[key] = value;
  });
  box.querySelectorAll("[data-f-score]:checked").forEach((input) => f.scores.push(input.dataset.fScore));
  box.querySelectorAll("[data-f-color]:checked").forEach((input) => f.colors.push(input.dataset.fColor));
  return f;
}

// boxId：欄の id／settingKey：保存する設定の名前／summaryKey：要約の名前／p：ボタンの印
function bindFilterPanel(boxId = "filter-box", settingKey = "collectFilters", summaryKey = "filtersSummary", p = "") {
  const box = document.getElementById(boxId);
  if (!box) return;
  const save = async (filters) => {
    const message = document.getElementById("filter-msg" + p);
    await postJson("/api/settings", { [settingKey]: JSON.stringify(filters) });
    state = await getJson("/api/bootstrap");
    box.querySelector("summary .muted").textContent = state[summaryKey];
    message.textContent = settingKey === "autoFilters" ? "保存しました。次の自動取得から、この条件が付きます。" : "保存しました。次の取得から、この条件が付きます。";
  };
  document.getElementById("filter-save" + p).onclick = () => {
    const filters = readFilterPanel(boxId);
    // 走行は「万km」で入れる欄。入れ間違い（例：5万kmのつもりで 50000）だと、USSが検索を受け付けず、取得に失敗する。
    if (Number(filters.mileageFromK) > 1000 || Number(filters.mileageToK) > 1000) {
      alert("走行は「万km」で入れてください。\n例：5万km〜10万kmなら、「5」と「10」です（50000 や 100000 ではありません）。\n（100万kmより大きい値は、保存できません）");
      return;
    }
    return save(filters);
  };
  document.getElementById("filter-clear" + p).onclick = async () => { await save({}); renderCollect(); };
  document.getElementById("filter-copy" + p)?.addEventListener("click", async () => { await save(state.settings.collectFilters || {}); renderCollect(); });
  document.getElementById("score-4up" + p).onclick = () => box.querySelectorAll("[data-f-score]").forEach((input) => { input.checked = state.filterOptions.scores4Up.includes(input.dataset.fScore); });
  document.getElementById("score-clear" + p).onclick = () => box.querySelectorAll("[data-f-score]").forEach((input) => { input.checked = false; });
}

// ---- このPCの準備の確認 ----

const STATUS_MARK = { ok: "✓", fail: "✗", warn: "！", info: "i" };

async function loadSetup(probe) {
  const summaryEl = document.getElementById("setup-summary");
  const body = document.getElementById("setup-body");
  const box = document.getElementById("setup-box");
  if (!summaryEl || !body) return;
  if (probe) summaryEl.textContent = "USSへのログインを確認しています…";
  let result;
  try {
    result = await getJson("/api/setup/status" + (probe ? "?probe=1" : ""));
  } catch {
    summaryEl.textContent = "準備の確認ができませんでした。";
    return;
  }
  const problems = result.checks.filter((check) => check.status === "fail" || check.status === "warn");
  summaryEl.textContent = problems.length ? `このPCの準備：あと ${problems.length}件（開いて確認）` : "このPCの準備：すべてOK";
  if (result.checks.some((check) => check.status === "fail") && box && !box.dataset.touched) box.open = true;
  body.innerHTML = `
    <ul class="setup-list">${result.checks.map((check) => `<li class="setup ${check.status}">
      <span class="mark">${STATUS_MARK[check.status] || "?"}</span>
      <div><b>${escapeHtml(check.label)}</b>　<span class="muted">${escapeHtml(check.message)}</span>${check.human && (check.status === "fail" || check.status === "warn") ? ' <span class="tag-human">あなたの操作が必要</span>' : ""}
        ${(check.status === "fail" || check.status === "warn") && check.fix.length ? `<ol>${check.fix.map((step) => `<li>${escapeHtml(step)}</li>`).join("")}</ol>` : ""}
        ${check.status === "info" && check.fix.length ? `<div class="muted">${check.fix.map(escapeHtml).join("<br>")}</div>` : ""}
      </div></li>`).join("")}</ul>
    <p class="row">
      <button id="setup-recheck" type="button" class="secondary">もう一度確認</button>
      <button id="setup-probe" type="button" class="secondary">USSログインも確認</button>
      <button id="setup-copy" type="button" class="secondary">AIに渡す指示をコピー</button>
    </p>
    <p class="muted">別のPCで使うときは、「AIに渡す指示をコピー」の文章を、そのPCで動いているAIに貼ると、手順書に沿ってセットアップを進めます。</p>`;
  document.getElementById("setup-recheck").onclick = () => loadSetup(false);
  document.getElementById("setup-probe").onclick = () => loadSetup(true);
  document.getElementById("setup-copy").onclick = async (event) => {
    await navigator.clipboard.writeText(result.prompt).catch(() => {});
    event.target.textContent = "コピーしました";
  };
  box?.addEventListener("toggle", () => { box.dataset.touched = "1"; }, { once: true });
}

// ---- 車種の選択（検索して追加。選んだ車種は札で並べる） ----

function normText(value) {
  return String(value || "").normalize("NFKC").replace(/\s+/g, "").toLowerCase();
}

function allCars() {
  if (carsCache) return carsCache;
  const seen = new Set();
  carsCache = [];
  for (const country of state.catalog || []) {
    for (const maker of country.makers) {
      for (const car of maker.cars) {
        const key = `${maker.name}\t${car.name}`;
        if (seen.has(key)) continue;
        seen.add(key);
        carsCache.push({ maker: maker.name, name: car.name, key });
      }
    }
  }
  return carsCache;
}

function makerNames() {
  return [...new Set(allCars().map((car) => car.maker))];
}

function pickedKeys() {
  return state.settings.collectCars || [];
}

// ---- 一覧から選ぶ（国 → メーカー → 車名） ----

// いま選んでいるメーカーの車名のうち、絞り込みに合うもの
function shownBrowseCars() {
  if (!browseMaker) return [];
  const query = normText(browseQuery);
  return allCars().filter((car) => car.maker === browseMaker && (!query || normText(car.name).includes(query)));
}

// 車名の並びだけを描き直す（絞り込みの入力欄には、触らない）
function paintBrowseCars() {
  const box = document.getElementById("browse-cars");
  if (!box) return;
  const picked = new Set(pickedKeys());
  const shown = shownBrowseCars();
  box.innerHTML = shown.map((car) => `<button type="button" class="chip${picked.has(car.key) ? " on" : ""}" data-car-key="${escapeAttr(car.key)}">${escapeHtml(car.name)}</button>`).join("") || "<span class='muted'>該当する車名がありません。</span>";
  box.querySelectorAll("[data-car-key]").forEach((button) => button.addEventListener("click", () => {
    const key = button.dataset.carKey;
    saveCars(pickedKeys().includes(key) ? pickedKeys().filter((item) => item !== key) : [...pickedKeys(), key]);
  }));
}

function paintBrowse() {
  const body = document.getElementById("browse-body");
  if (!body) return;
  const catalog = state.catalog || [];
  if (!catalog.length) { body.innerHTML = "<p class='muted'>一覧のデータがありません。</p>"; return; }
  if (!catalog.some((country) => country.country === browseCountry)) browseCountry = catalog[0].country;
  const country = catalog.find((item) => item.country === browseCountry);
  const picked = new Set(pickedKeys());
  const countIn = (makerName) => allCars().filter((car) => car.maker === makerName && picked.has(car.key)).length;
  const maker = country.makers.find((item) => item.name === browseMaker);
  if (!maker) browseMaker = "";
  const cars = maker ? allCars().filter((car) => car.maker === maker.name) : [];
  const query = normText(browseQuery);
  const shown = cars.filter((car) => !query || normText(car.name).includes(query));
  body.innerHTML = `
    <div class="browse-step"><span class="step">国</span>
      <div class="chips">${catalog.map((item) => `<button type="button" class="chip${item.country === browseCountry ? " on" : ""}" data-country="${escapeAttr(item.country)}">${escapeHtml(item.country)}</button>`).join("")}</div>
    </div>
    <div class="browse-step"><span class="step">メーカー</span>
      <div class="chips">${country.makers.map((item) => {
        const n = countIn(item.name);
        return `<button type="button" class="chip${item.name === browseMaker ? " on" : ""}" data-maker="${escapeAttr(item.name)}">${escapeHtml(item.name)}${n ? ` <b>${n}</b>` : ""}</button>`;
      }).join("")}</div>
    </div>
    ${maker ? `<div class="browse-step"><span class="step">車名</span>
      <div class="grow">
        <div class="row">
          <strong>${escapeHtml(maker.name)}</strong>
          <input id="browse-query" placeholder="${escapeAttr(maker.name)}の中で絞る" value="${escapeAttr(browseQuery)}" autocomplete="off">
          <button type="button" id="browse-all" class="secondary small">表示中をすべて選ぶ</button>
          <button type="button" id="browse-none" class="text">表示中をすべて外す</button>
        </div>
        <div class="chips cars" id="browse-cars"></div>
      </div></div>` : "<p class='muted'>メーカーを選ぶと、車名の一覧が出ます。車名を押すと、選ぶ／外すが切り替わります。</p>"}`;
  paintBrowseCars();
  body.querySelectorAll("[data-country]").forEach((button) => button.addEventListener("click", () => { browseCountry = button.dataset.country; browseMaker = ""; browseQuery = ""; paintBrowse(); }));
  body.querySelectorAll("[data-maker]").forEach((button) => button.addEventListener("click", () => { browseMaker = button.dataset.maker; browseQuery = ""; paintBrowse(); }));
  // 入力欄は作り直さない（日本語の変換が壊れるため）。変換が確定してから、車名の並びだけを更新する。
  const queryInput = document.getElementById("browse-query");
  if (queryInput) {
    let composing = false;
    queryInput.addEventListener("compositionstart", () => { composing = true; });
    queryInput.addEventListener("compositionend", () => { composing = false; browseQuery = queryInput.value; paintBrowseCars(); });
    queryInput.addEventListener("input", () => {
      browseQuery = queryInput.value;
      if (!composing) paintBrowseCars();
    });
  }
  document.getElementById("browse-all")?.addEventListener("click", () => {
    const keys = shownBrowseCars().map((car) => car.key);
    if (keys.length > 30 && !confirm(`${keys.length}車種をまとめて選びます。取得に時間がかかります。よろしいですか？`)) return;
    saveCars([...new Set([...pickedKeys(), ...keys])]);
  });
  document.getElementById("browse-none")?.addEventListener("click", () => {
    const drop = new Set(shownBrowseCars().map((car) => car.key));
    saveCars(pickedKeys().filter((key) => !drop.has(key)));
  });
}

async function saveCars(keys) {
  state.settings.collectCars = keys;
  paintPicked();
  paintResults();
  paintBrowse();
  await postJson("/api/settings", { collectCars: keys.join("|") });
}

// ---- 自動取得の、車種ごとの条件（ルール） ----
const RULE_KIND_LABEL = { class: "区分", maker: "メーカー", word: "車名に含む言葉", car: "車種" };
const RULE_CLASS_LABEL = { import: "輸入車", domestic: "国産普通車", kei: "国産軽自動車" };
let editingRuleId = "";

function ruleFiltersText(filters) {
  const f = filters || {};
  const parts = [];
  if (f.yearFrom != null || f.yearTo != null) parts.push(`年式 ${f.yearFrom ?? ""}〜${f.yearTo ?? ""}`);
  if (f.mileageFromK != null || f.mileageToK != null) parts.push(`走行 ${f.mileageFromK != null ? f.mileageFromK / 10 : ""}〜${f.mileageToK != null ? f.mileageToK / 10 : ""}万km`);
  if (f.priceFromSen != null || f.priceToSen != null) parts.push(`落札額 ${f.priceFromSen != null ? f.priceFromSen / 10 : ""}〜${f.priceToSen != null ? f.priceToSen / 10 : ""}万円`);
  if (f.scores?.length) parts.push("評価点 4以上");
  return parts.length ? parts.join("、") : "（条件なし）";
}
function ruleTargetLabel(rule) {
  if (rule.kind === "class") return RULE_CLASS_LABEL[rule.target] || rule.target;
  if (rule.kind === "car") return rule.target.replace("\t", " ");
  return rule.target;
}
function paintRuleTarget() {
  const kind = document.getElementById("rule-kind")?.value;
  const box = document.getElementById("rule-target-box");
  if (!box) return;
  if (kind === "class") box.innerHTML = `<select id="rule-target">${Object.entries(RULE_CLASS_LABEL).map(([id, label]) => `<option value="${id}">${label}</option>`).join("")}</select>`;
  else if (kind === "car") box.innerHTML = `<select id="rule-target"><option value="">自動で取得する車種から選ぶ</option>${(state.settings.autoCars || []).map((key) => `<option value="${escapeAttr(key)}">${escapeHtml(key.replace("\t", " "))}</option>`).join("")}</select>`;
  else if (kind === "maker") box.innerHTML = `<input id="rule-target" list="rule-makers" placeholder="例：BMW"><datalist id="rule-makers">${makerNames().map((name) => `<option value="${escapeAttr(name)}"></option>`).join("")}</datalist>`;
  else box.innerHTML = `<input id="rule-target" placeholder="例：プリウス（プリウスα・PHVも、含まれます）">`;
}
function paintAutoRules() {
  const list = document.getElementById("auto-rules-list");
  if (!list) return;
  const rules = state.settings.autoRules || [];
  document.getElementById("auto-rules-count").textContent = `${rules.length}件`;
  list.innerHTML = rules.length
    ? rules.map((rule) => `<div class="row rule-row"><span class="label"><b>${RULE_KIND_LABEL[rule.kind]}</b>：${escapeHtml(ruleTargetLabel(rule))}</span><span>${escapeHtml(ruleFiltersText(rule.filters))}</span><button type="button" class="small secondary" data-rule-edit="${escapeAttr(rule.id)}">編集</button><button type="button" class="small secondary" data-rule-del="${escapeAttr(rule.id)}">削除</button></div>`).join("")
    : "<p class='muted'>まだ、ありません。下で、追加してください。</p>";
  list.querySelectorAll("[data-rule-edit]").forEach((button) => button.addEventListener("click", () => startEditRule(button.dataset.ruleEdit)));
  list.querySelectorAll("[data-rule-del]").forEach((button) => button.addEventListener("click", () => saveRules(rules.filter((rule) => rule.id !== button.dataset.ruleDel))));
}
function startEditRule(id) {
  const rule = (state.settings.autoRules || []).find((item) => item.id === id);
  if (!rule) return;
  editingRuleId = id;
  document.getElementById("rule-kind").value = rule.kind;
  paintRuleTarget();
  document.getElementById("rule-target").value = rule.target;
  for (const [key, scale] of [["yearFrom", 1], ["yearTo", 1], ["mileageFromK", 10], ["mileageToK", 10], ["priceFromSen", 10], ["priceToSen", 10]]) {
    document.getElementById("rule-" + key).value = rule.filters[key] != null ? rule.filters[key] / scale : "";
  }
  document.getElementById("rule-scores").value = rule.filters.scores?.length ? "4up" : "";
  document.getElementById("rule-save").textContent = "ルールを保存";
  document.getElementById("rule-cancel").hidden = false;
}
function resetRuleForm() {
  editingRuleId = "";
  for (const key of ["yearFrom", "yearTo", "mileageFromK", "mileageToK", "priceFromSen", "priceToSen"]) document.getElementById("rule-" + key).value = "";
  document.getElementById("rule-scores").value = "";
  document.getElementById("rule-save").textContent = "ルールを追加";
  document.getElementById("rule-cancel").hidden = true;
  paintRuleTarget();
}
async function saveRules(rules) {
  await postJson("/api/settings", { autoRules: JSON.stringify(rules) });
  state = await getJson("/api/bootstrap"); // 札に出す「いま使われる条件」も、更新する
  paintAutoRules();
  paintAutoCars();
}
function bindAutoRules() {
  if (!document.getElementById("rule-kind")) return;
  paintRuleTarget();
  paintAutoRules();
  document.getElementById("rule-kind").addEventListener("change", paintRuleTarget);
  document.getElementById("rule-cancel").addEventListener("click", resetRuleForm);
  document.getElementById("rule-save").addEventListener("click", async () => {
    const message = document.getElementById("rule-msg");
    const target = (document.getElementById("rule-target")?.value || "").trim();
    if (!target) { message.textContent = "対象を入れてください。"; return; }
    const num = (id, scale) => { const value = document.getElementById("rule-" + id).value; return value === "" ? null : Math.round(Number(value) * scale); };
    const filters = { yearFrom: num("yearFrom", 1), yearTo: num("yearTo", 1), mileageFromK: num("mileageFromK", 10), mileageToK: num("mileageToK", 10), priceFromSen: num("priceFromSen", 10), priceToSen: num("priceToSen", 10) };
    if (Number(filters.mileageFromK) > 1000 || Number(filters.mileageToK) > 1000) { message.textContent = "走行は「万km」で入れてください（例：10万kmなら、10）。"; return; }
    if (document.getElementById("rule-scores").value === "4up") filters.scores = state.filterOptions.scores4Up;
    if (Object.values(filters).every((value) => value === null)) { message.textContent = "条件を、1つ以上、入れてください。"; return; }
    const kind = document.getElementById("rule-kind").value;
    const rules = (state.settings.autoRules || []).slice();
    const rule = { id: editingRuleId || Math.random().toString(36).slice(2, 10), kind, target, filters };
    const index = rules.findIndex((item) => item.id === rule.id);
    if (index >= 0) rules[index] = rule; else rules.push(rule);
    await saveRules(rules);
    resetRuleForm();
    message.textContent = "保存しました。次の自動取得から、付きます。";
  });
}

// 自動取得する車種を、ここで探して追加する
function paintAutoResults() {
  const box = document.getElementById("auto-car-results");
  if (!box) return;
  const query = normText(document.getElementById("auto-car-search")?.value || "");
  if (!query) { box.innerHTML = ""; return; }
  const picked = new Set(state.settings.autoCars || []);
  const found = allCars().filter((car) => !picked.has(car.key) && normText(car.maker + car.name).includes(query));
  box.innerHTML = found.length
    ? found.slice(0, 40).map((car) => `<button type="button" class="chip add" data-auto-add="${escapeAttr(car.key)}">＋ ${escapeHtml(car.maker)} ${escapeHtml(car.name)}</button>`).join("") + (found.length > 40 ? `<span class="muted">ほか ${found.length - 40}件（言葉を足して絞ってください）</span>` : "")
    : "<span class='muted'>見つかりません。</span>";
  box.querySelectorAll("[data-auto-add]").forEach((button) => button.addEventListener("click", async () => {
    await toggleAutoCar(button.dataset.autoAdd);
    paintAutoResults();
  }));
}

// 自動取得する車種（手動の「取得する車種」とは、別）
function paintAutoCars() {
  const box = document.getElementById("auto-cars");
  if (!box) return;
  const keys = state.settings.autoCars || [];
  box.innerHTML = keys.length
    ? keys.map((key) => `<span class="chipwrap"><button type="button" class="chip on" data-auto-remove="${escapeAttr(key)}" title="押すと、自動取得から外します">${escapeHtml(key.replace("\t", " "))} ×</button><span class="chip-note muted">${escapeHtml((state.autoCarSummaries || {})[key] || "条件なし")}</span></span>`).join("")
    : "<span class='muted'>まだ、ありません。下の欄で探して、追加してください。</span>";
  box.querySelectorAll("[data-auto-remove]").forEach((button) => button.addEventListener("click", () => toggleAutoCar(button.dataset.autoRemove)));
}
async function toggleAutoCar(key) {
  const current = state.settings.autoCars || [];
  state.settings.autoCars = current.includes(key) ? current.filter((item) => item !== key) : [...current, key];
  paintAutoCars();
  paintPicked();
  await postJson("/api/settings", { autoCars: state.settings.autoCars.join("|") });
}

function paintPicked() {
  const box = document.getElementById("picked");
  if (!box) return;
  const keys = pickedKeys();
  if (!keys.length) {
    box.innerHTML = "<span class='muted'>まだ選んでいません。下の欄で探して追加してください。</span>";
    return;
  }
  const shown = pickedExpanded ? keys : keys.slice(0, 14);
  box.classList.toggle("expanded", pickedExpanded);
  box.innerHTML = `<div class="picked-head"><b>選んでいる車種 ${keys.length}件</b></div>`
    + shown.map((key) => {
      const inAuto = (state.settings.autoCars || []).includes(key);
      return `<span class="chipwrap"><button type="button" class="chip on" data-remove="${escapeAttr(key)}" title="押すと外します">${escapeHtml(key.replace("\t", " "))} ×</button><button type="button" class="chip auto-star${inAuto ? " on" : ""}" data-auto-toggle="${escapeAttr(key)}" title="${inAuto ? "自動取得から外します" : "自動取得にも入れます"}">${inAuto ? "★自動" : "☆自動"}</button></span>`;
    }).join("")
    + (keys.length > 14 ? `<button type="button" class="text" id="toggle-picked">${pickedExpanded ? "たたむ" : `ほか ${keys.length - shown.length}車種をすべて表示`}</button>` : "")
    + `<button type="button" class="text" id="clear-cars">すべて外す</button>`;
  document.getElementById("toggle-picked")?.addEventListener("click", () => { pickedExpanded = !pickedExpanded; paintPicked(); });
  box.querySelectorAll("[data-remove]").forEach((button) => button.addEventListener("click", () => saveCars(pickedKeys().filter((key) => key !== button.dataset.remove))));
  box.querySelectorAll("[data-auto-toggle]").forEach((button) => button.addEventListener("click", () => toggleAutoCar(button.dataset.autoToggle)));
  document.getElementById("clear-cars").onclick = () => saveCars([]);
}

function paintResults() {
  const box = document.getElementById("car-results");
  if (!box) return;
  const query = normText(pickQuery);
  if (!query) { box.innerHTML = ""; return; }
  const picked = new Set(pickedKeys());
  const found = allCars().filter((car) => !picked.has(car.key) && normText(car.maker + car.name).includes(query));
  box.innerHTML = found.slice(0, 40).map((car) => `<button type="button" class="chip add" data-add="${escapeAttr(car.key)}">＋ ${escapeHtml(car.maker)} ${escapeHtml(car.name)}</button>`).join("")
    + (found.length > 40 ? `<span class="muted">ほか ${found.length - 40}件（言葉を足して絞ってください）</span>` : "");
  if (!found.length) box.innerHTML = "<span class='muted'>見つかりません。</span>";
  box.querySelectorAll("[data-add]").forEach((button) => button.addEventListener("click", () => saveCars([...pickedKeys(), button.dataset.add])));
}

// ---- 取得の進み具合 ----

let collectTimer = null;
let collectWasRunning = false;
// 「自動で取得する」の欄の、「今すぐ実行する」の、進み具合
async function watchAutoRun() {
  clearTimeout(autoRunTimer);
  const progress = document.getElementById("auto-run-progress");
  const runButton = document.getElementById("auto-run");
  const cancelButton = document.getElementById("auto-cancel");
  if (!progress || !runButton || !cancelButton) return;
  let status;
  try { status = await getJson("/api/auto/status"); } catch { return; }
  const running = status.auto.running;
  runButton.disabled = running || Boolean(state?.viewerOnly);
  cancelButton.hidden = !running;
  if (!running) cancelButton.disabled = false;
  if (running) {
    autoRunNotice = "";
    autoRunWasRunning = true;
    const detail = status.collect.running ? status.collect.message : status.upcoming.running ? status.upcoming.message : "";
    progress.className = "muted";
    progress.textContent = `${status.auto.step || "準備"}…　${detail || status.auto.message || ""}`;
    autoRunTimer = setTimeout(watchAutoRun, 3000);
    return;
  }
  progress.className = autoRunNotice ? "warn err-msg" : status.auto.message ? (/エラー/.test(status.auto.message) ? "warn err-msg" : "done-msg") : "muted";
  progress.textContent = autoRunNotice || status.auto.message || "";
  if (autoRunWasRunning) {
    autoRunWasRunning = false;
    try { state = await getJson("/api/bootstrap"); await refreshUpcoming(); } catch { /* 取れなくても、表示は続ける */ }
    toast(/キャンセル/.test(status.auto.message || "") ? "キャンセルしました" : /エラー/.test(status.auto.message || "") ? "自動取得の流れで、エラーが出ました" : "今すぐ実行が、終わりました");
  }
}

async function watchCollect() {
  clearTimeout(collectTimer);
  const pill = document.getElementById("bridge-pill");
  const stateEl = document.getElementById("bridge-state");
  const progress = document.getElementById("collect-progress");
  const button = document.getElementById("collect-run");
  const bar = document.getElementById("collect-bar");
  const cancelBtn = document.getElementById("collect-cancel");
  if (!pill || !stateEl || !progress || !button) return;
  if (state?.viewerOnly) {
    // 見る専用のPC：USSとの接続の欄は、「アクセスできない」と、はっきり書く
    pill.className = "pill off"; pill.textContent = "アクセス不可";
    stateEl.textContent = state.noUssMessage || "このPCは、USSの情報には、アクセスできません。";
    button.disabled = true;
    return;
  }
  let job;
  try {
    job = await (await fetch("/api/collect/status")).json();
  } catch {
    pill.className = "pill off"; pill.textContent = "システムにつながりません";
    return;
  }
  const ok = job.bridge.connected;
  pill.className = `pill ${ok ? "ok" : "off"}`;
  pill.textContent = ok ? "つながっています" : "つながっていません";
  stateEl.textContent = ok
    ? "Chromeの拡張機能「ESCO Drive USS連携」と通信できています。USBキーを挿して、USSにログインしておいてください。"
    : "USBキーを挿して、USSにログインしたChromeを開いてください（拡張機能が入っているプロファイル）。";
  const skipped = job.skipped && job.skipped.length ? `　取得できなかった車種：${job.skipped.join("、")}` : "";
  const marketOnly = !job.running && job.marketRunning;
  if (bar) {
    // 小売相場の段階（ボタン以外から始まった読み取りを含む）は、残り件数で表示する
    bar.hidden = !(job.running || marketOnly);
    if (job.running) { bar.max = Math.max(job.total, 1); bar.value = job.done; }
    else if (marketOnly) { bar.removeAttribute("value"); }
  }
  if (job.running && job.phase !== "market") progress.textContent = `① USSから取得中（${job.done}/${job.total}・残り ${Math.max(job.total - job.done, 0)}件）${etaText("uss", job.total - job.done)}　${job.message}`;
  else if (job.running && job.total <= 0) progress.textContent = "② 小売相場を調べる準備をしています…（落札データの取り込みは終わりました。まだ完了ではありません）";
  else if (job.running) progress.textContent = `② 小売相場を読んでいます（${job.done}/${job.total}・残り ${Math.max(job.total - job.done, 0)}件）${etaText("market", job.total - job.done)}　${job.message}`;
  else if (marketOnly) progress.textContent = `② 小売相場を読んでいます（残り ${job.marketRemaining}件）${etaText("market-only", job.marketRemaining)}`;
  else if (collectNotice) { etaReset(); progress.textContent = collectNotice; }
  else { etaReset(); progress.textContent = `${job.message || progress.textContent}${job.marketRemaining ? `　小売相場が未取得のものが ${job.marketRemaining}件あります` : ""}${skipped}`; }
  // 手順の表示：いまどこか／終わったか
  const finished = !job.running && !marketOnly && !job.error && /^すべて完了/.test(job.message || "");
  const flow1 = document.getElementById("flow-1"), flow2 = document.getElementById("flow-2");
  if (flow1 && flow2) {
    const inMarket = (job.running && job.phase === "market") || marketOnly;
    flow1.className = finished || inMarket ? "done" : job.running ? "now" : "";
    flow2.className = finished ? "done" : inMarket ? "now" : "";
  }
  if (job.running) collectNotice = "";
  progress.className = collectNotice && !job.running ? "warn err-msg" : finished ? "done-msg" : "muted";
  if (finished) progress.textContent = "✅ " + progress.textContent;
  button.disabled = job.running || marketOnly;
  if (cancelBtn) { cancelBtn.hidden = !(job.running || marketOnly); if (!(job.running || marketOnly)) cancelBtn.disabled = false; }
  if (!job.running && !marketOnly && /ログイン/.test(job.error || "")) checkUssLogin("collect-progress");
  if (job.running || marketOnly) collectWasRunning = true;
  if (job.running || marketOnly || !ok) collectTimer = setTimeout(watchCollect, 3000);
  else if (collectWasRunning) { collectWasRunning = false; if (!job.error) toast(/^キャンセル/.test(job.message || "") ? "キャンセルしました" : "すべて完了しました"); await load(); }
}

// ====================================================================
// 落札データ
// ====================================================================

async function renderLots() {
  const token = ++paint;
  const chosenCodes = selectedModelCodes();
  const allChoices = state.modelChoices || [];
  const choices = showUnselected ? allChoices : allChoices.filter((choice) => chosenCodes.has(choice.modelCode));
  const hiddenCount = allChoices.length - choices.length;
  if (lotModel && !choices.some((choice) => choice.modelCode === lotModel)) lotModel = "";
  const scope = lotModel || (showUnselected ? "" : choices.map((choice) => choice.modelCode).join(",") || "-");
  const data = await getJson("/api/lots?limit=100&offset=" + lotOffset + "&q=" + encodeURIComponent(lotQuery) + "&models=" + encodeURIComponent(scope));
  const pins = state.today.allPins || [];
  if (token !== paint) return;
  view.innerHTML = `
    ${pins.length ? `<details class="card fold" open><summary>あとで見る車・ピン留め（${pins.length}台）</summary><ul class="plain">${pins.map((pin) => `<li>${escapeHtml(pin.ussCode)}　${escapeHtml(pin.modelCode || "")} ${escapeHtml(pin.grade || "")}　${escapeHtml(pin.auctionDate || "")}　${ussLink(pin)}</li>`).join("")}</ul></details>` : ""}
    ${unselectedNotice(hiddenCount, "型式")}
    <p class="muted notice-line">USSから取得した、過去の落札の記録そのものです。「仕入れ車種の選定」は、この記録と小売相場から、仕入れ候補の条件を探します。</p>
    <section class="pn">
      <div class="t">落札データ<span>${data.total.toLocaleString()}台中 ${data.total ? lotOffset + 1 : 0}〜${lotOffset + data.rows.length}台を表示</span></div>
      <div class="row toolbar">
        <label>車種<select id="lot-model"><option value="">すべて</option>${choices.map((choice) => `<option value="${escapeAttr(choice.modelCode)}" ${lotModel === choice.modelCode ? "selected" : ""}>${escapeHtml(choice.maker)} ${escapeHtml(choice.name)}（${escapeHtml(choice.modelCode)}）${choice.count}台</option>`).join("")}</select></label>
        <input id="q" class="grow" placeholder="グレード・検索コードで絞る" value="${escapeAttr(lotQuery)}"><button id="find" type="button">検索</button>
        <a class="linkbtn secondary" id="lot-csv" href="/api/lots/csv?q=${encodeURIComponent(lotQuery)}&models=${encodeURIComponent(scope)}">CSVで保存</a>
      </div>
      <div class="scroll"><table><thead><tr><th>開催日</th><th>会場</th><th>車名</th><th>型式</th><th>グレード</th><th>年式</th><th>走行</th><th>評価</th><th>落札</th><th></th></tr></thead>
      <tbody>${data.rows.map((lot) => `<tr>
        <td>${escapeHtml(lot.auction_date)}</td><td>${escapeHtml(lot.venue)}</td><td><b>${escapeHtml(lot.model_name || state.models?.[lot.model_code] || "")}</b></td><td>${escapeHtml(lot.model_code)}</td><td>${escapeHtml(lot.grade)}</td>
        <td>${lot.year || ""}</td><td>${km(lot.mileage_km)}</td><td>${lot.score ?? escapeHtml(lot.score_raw)}</td><td>${lot.hammer_man ?? ""}</td>
        <td class="nowrap">${ussLink({ ussCode: lot.uss_code })} <button class="secondary small pin" data-code="${escapeAttr(lot.uss_code)}">${lot.pinned ? "ピン解除" : "ピン留め"}</button></td>
      </tr>`).join("") || "<tr><td colspan='10' class='muted'>該当する落札はありません。</td></tr>"}</tbody></table></div>
      <div class="pager"><button id="lot-prev" type="button" class="secondary" ${lotOffset <= 0 ? "disabled" : ""}>‹ 前の100台</button><span class="muted">${data.total ? lotOffset + 1 : 0}〜${lotOffset + data.rows.length} / ${data.total.toLocaleString()}台</span><button id="lot-next" type="button" class="secondary" ${lotOffset + data.rows.length >= data.total ? "disabled" : ""}>次の100台 ›</button></div>
      <p class="muted">「USSで開く」はその車のUSS検索ページを開きます。車が出ないときは、開いたページでブックマークの「USS車両を開く」を押してください。</p>
    </section>`;
  bindUnselected(renderLots);
  const search = () => { lotQuery = document.getElementById("q").value; lotModel = document.getElementById("lot-model").value; lotOffset = 0; renderLots(); };
  document.getElementById("lot-prev").addEventListener("click", () => { lotOffset = Math.max(0, lotOffset - 100); renderLots(); });
  document.getElementById("lot-next").addEventListener("click", () => { lotOffset += 100; renderLots(); });
  document.getElementById("find").addEventListener("click", search);
  document.getElementById("q").addEventListener("keydown", (event) => { if (event.key === "Enter") search(); });
  document.getElementById("lot-model").addEventListener("change", search);
  view.querySelectorAll(".pin").forEach((button) => button.addEventListener("click", () => togglePin(button.dataset.code, button.textContent.includes("解除"))));
}

async function togglePin(code, remove) {
  if (remove) await fetch("/api/pins?code=" + encodeURIComponent(code), { method: "DELETE" });
  else await postJson("/api/pins", { ussCode: code });
  await load();
  show("lots");
}

// ====================================================================
// 設定
// ====================================================================

// メーカーごとの金額帯の一覧：結果のあるメーカー（チェックを入れた車種のもの）と、すでに設定のあるメーカー
function makerBandRows() {
  const chosen = selectedModelCodes();
  const counts = new Map();
  for (const cluster of state.clusters) {
    if (!showUnselected && !chosen.has(cluster.modelCode)) continue;
    if (!cluster.maker) continue;
    counts.set(cluster.maker, (counts.get(cluster.maker) || 0) + 1);
  }
  for (const maker of Object.keys(state.settings.makerBands || {})) if (!counts.has(maker)) counts.set(maker, 0);
  // 取得済みの落札データに入っている、すべてのメーカー（いま選んでいない車種のメーカーも）
  for (const choice of state.modelChoices || []) if (choice.maker && !counts.has(choice.maker)) counts.set(choice.maker, 0);
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).map(([name, count]) => {
    const own = state.settings.makerBands?.[name];
    return { name, count, own: Boolean(own), min: own?.minYen ?? null, max: own?.maxYen ?? null };
  });
}

// 利益の基準と、個別の金額帯（「仕入れ車種の選定」タブの先頭に出す）
function criteriaHtml() {
  const settings = state.settings;
  const summaryText = `差額 ${man(settings.gapThresholdYen)} 以上・仕入の ${settings.gapRatePct}% 以上${settings.costMinYen != null || settings.costMaxYen != null ? ` ／ 仕入れ値 ${settings.costMinYen != null ? man(settings.costMinYen) : "下限なし"}〜${settings.costMaxYen != null ? man(settings.costMaxYen) : "上限なし"}` : ""}${bandItems().length ? ` ／ 個別の金額指定 ${bandItems().length}件` : ""}`;
  return `<details class="card fold" id="crit-box" ${showCrit ? "open" : ""}><summary>仕入れ候補の条件：${escapeHtml(summaryText)}（変更する）</summary>
      <p class="muted">次の両方を満たすものだけを、「仕入れ車種の選定」に出します。この条件は、「入札車の選定」の上限額と◎○の判定にも使います。</p>
      <div class="row">
        <label>差額（円）以上<input id="threshold" type="number" value="${settings.gapThresholdYen}"></label>
        <label>仕入に対する割合（%）以上<input id="rate" type="number" step="0.5" min="0" value="${settings.gapRatePct}"></label>
      </div>
      <h3>仕入れ値の金額帯（税込の目安・万円）</h3>
      <div class="row">
        <label>下限<input id="cost-min" type="number" min="0" step="1" value="${settings.costMinYen == null ? "" : settings.costMinYen / 10000}" placeholder="下限なし"></label>
        <label>上限<input id="cost-max" type="number" min="0" step="1" value="${settings.costMaxYen == null ? "" : settings.costMaxYen / 10000}" placeholder="上限なし"></label>
      </div>
      <p class="muted">金額帯の外のものは、結果に出さず、小売相場も読みません（時間とサイトへの負担が減ります）。メーカーごとに変えたいときは、下の「メーカーごとの仕入れ値の金額帯」で設定します。</p>
      <p class="row"><button id="save-crit" type="button">保存</button></p>
      <div class="sub-crit">
      <div class="t">個別の仕入れ値の金額帯（メーカー・車種・グレード）<span>優先順位：グレード → 車種 → メーカー → 全体</span></div>
      <p class="muted">全体の金額帯（上の「仕入れ候補の条件」）と違う範囲にしたい、メーカー・車種・グレードだけを追加します。金額は<b>万円</b>で入れます（入れるとすぐ保存されます）。</p>
      <p class="rule"><b>せまい条件の指定が優先されます。</b>（グレード ＞ 車種 ＞ メーカー ＞ 全体）<br>例：トヨタを100〜200万円、プリウスを300〜400万円にすると、プリウスは300〜400万円、ほかのトヨタ車は100〜200万円になります。</p>
      ${bandItems().length ? `<div class="band-list">${bandItems().map((item) => `<div class="band-row" data-kind="${item.kind}" data-name="${escapeAttr(item.name)}" data-car="${escapeAttr(item.car || "")}" data-gradekey="${escapeAttr(item.gradeKey || "")}" data-gradelabel="${escapeAttr(item.gradeLabel || "")}">
        <span class="kind-tag ${item.kind}">${{ maker: "メーカー", car: "車種", grade: "グレード" }[item.kind]}</span><b class="band-name">${item.kind === "grade" ? `${escapeHtml(item.car)} › ${escapeHtml(item.gradeLabel)}` : escapeHtml(item.name)}</b>
        <label>下限<input type="number" min="0" data-which="min" value="${item.min == null ? "" : item.min / 10000}" placeholder="${settings.costMinYen == null ? "なし" : `全体 ${settings.costMinYen / 10000}`}">万円</label>
        <label>上限<input type="number" min="0" data-which="max" value="${item.max == null ? "" : item.max / 10000}" placeholder="${settings.costMaxYen == null ? "なし" : `全体 ${settings.costMaxYen / 10000}`}">万円</label>
        <button type="button" class="text" data-band-del>解除</button>
      </div>`).join("")}</div>` : `<p class="muted band-empty">金額指定中のものは、ありません（すべて、全体の金額帯を使っています）。</p>`}
      <p class="row"><button id="band-add" type="button">金額指定を追加する</button></p>
      </div>
    </details>`;
}

function bindCriteria() {
  const yenFromMan = (id) => {
    const value = document.getElementById(id).value.trim();
    return value === "" ? "" : String(Math.round(Number(value) * 10000));
  };
  document.getElementById("save-crit")?.addEventListener("click", async () => {
    // 金額帯は「万円」で入れる欄。円の数字（例 3000000）を入れていないか確かめる。
    if (["cost-min", "cost-max"].some((id) => Number(document.getElementById(id).value) > 100000)) {
      alert("仕入れ値の金額帯は、「万円」で入れてください。\n例：300万円なら、300 と入れます（3000000 ではありません）。");
      return;
    }
    await postJson("/api/settings", {
      gapThresholdYen: document.getElementById("threshold").value,
      gapRatePct: document.getElementById("rate").value || "0",
      costMinYen: yenFromMan("cost-min"),
      costMaxYen: yenFromMan("cost-max"),
    });
    await load();
  });
  document.getElementById("crit-box")?.addEventListener("toggle", (event) => { showCrit = event.target.open; });
  bindBandList();
}

// 車種ごとの「その他の経費」（全体と違う金額にした車種）
function otherCostRows() {
  const cond = state.settings.carConditions || {};
  return Object.entries(cond).filter(([, value]) => Number.isFinite(value?.otherCostYen)).map(([name, value]) => ({ name, yen: value.otherCostYen })).sort((a, b) => a.name.localeCompare(b.name, "ja"));
}
function otherCostCarOptions() {
  const set = new Set(otherCostRows().map((row) => row.name));
  return [...new Set((state.clusters || []).map((cluster) => cluster.carName).filter(Boolean))].filter((name) => !set.has(name)).sort((a, b) => a.localeCompare(b, "ja"));
}

function renderSettings() {
  const settings = state.settings;
  const weekdays = ["日", "月", "火", "水", "木", "金", "土"];
  view.innerHTML = `
    ${settings.defaultsConfirmed ? "" : `<section class="card notice-card"><b>初期値のままです。</b>拠点・落札手数料・陸送費・仕入れ候補の条件（差額）が、自社に合うか確認し、直してください。<div class="row"><button id="confirm-defaults" type="button">この設定で確認済み</button></div></section>`}
    <div class="g2c"><div>
    <h2 class="col-title">仕入れの計算</h2>
    <section class="pn">
      <div class="t">小売の見積り方</div>
      <div class="row">
        <label>カーセンサーの安い順に<select id="pick-count">${[1, 2, 3, 4, 5, 6, 8, 10].map((n) => `<option value="${n}" ${settings.retailPickCount === n ? "selected" : ""}>${n}台</option>`).join("")}</select></label>
        <label>その<select id="pick-method"><option value="mean" ${settings.retailPickMethod === "mean" ? "selected" : ""}>平均</option><option value="median" ${settings.retailPickMethod === "median" ? "selected" : ""}>中央値</option></select></label>
      </div>
      <p class="muted">同じ条件の車を、支払総額の安い順に並べて、上から${settings.retailPickCount}台の${settings.retailPickMethod === "median" ? "中央値" : "平均"}を、小売の見積りにします。グーネットは、カーセンサーで読めなかったときだけ参考にします。</p>
      <p class="row"><button id="save" type="button">保存</button></p>
    </section>
    <section class="pn">
      <div class="t">仕入れ値の計算（諸経費と拠点）</div>
      <p class="muted">仕入の総額（税込の目安）＝ 落札額×1.1 ＋（落札手数料 ＋ 陸送費 ＋ その他の経費）×1.1</p>
      <div class="row">
        <label>落札手数料（税別・円）<input id="fee" type="number" value="${settings.feeExTaxYen}"></label>
        <label>その他の経費（整備・名変など・税別・円）<input id="other-cost" type="number" min="0" value="${settings.otherCostYen}"></label>
        <label>小売の検索範囲（拠点の都道府県）<select id="base">${(state.regions || []).map((region) => `<optgroup label="${escapeAttr(region.name)}">${region.prefectures.map((name) => `<option value="${escapeAttr(name)}" ${name === settings.basePrefecture ? "selected" : ""}>${escapeHtml(name)}</option>`).join("")}</optgroup>`).join("")}</select></label>
        <button id="save-cost" type="button">保存</button>
      </div>
      <h3>会場ごとの陸送費（拠点までの税別・円）</h3>
      <div class="transport-grid">${state.venues.map((venue) => `<label>${escapeHtml(venue.name)}<input type="number" min="0" step="500" data-transport="${escapeAttr(venue.code)}" value="${settings.transportByVenue?.[venue.code] ?? ""}" placeholder="-"></label>`).join("")}</div>
      <p class="muted">会場の入力は、入れるとすぐに保存されます。「-」は未入力（計算では0円として扱います）、「0」は、0円（自社で引き取る場合など）です。東京は自社で引き取るため0円です。名古屋＆北陸、大阪、九州、群馬の初期値は、公開料金からの推定です。ほかの会場は0円のままなので、使うときは入れてください。相場は${escapeHtml(settings.salesRegionName)}（${escapeHtml((settings.salesPrefectures || []).join("、"))}）の支払総額で見ます。</p>
      <h3>区分・メーカー・車種ごとの、その他の経費（税別・円）</h3>
      <p class="muted">上の「その他の経費」と違う金額にしたいところだけ、入れます。入れると、すぐ保存されます。空にすると、ひとつ上の設定に戻ります。<br><b>せまい指定が優先されます。</b>（車種 ＞ メーカー ＞ 区分 ＞ 全体）</p>
      <p class="rule"><b>区分ごと</b>：国産軽自動車は、排気量660cc以下の国産車です。メーカーが国産でないものは、輸入車です。</p>
      <div class="row">${["import", "domestic", "kei"].map((cls) => `<label>${{ import: "輸入車", domestic: "国産普通車", kei: "国産軽自動車" }[cls]}<input type="number" min="0" step="10000" data-oc-class="${cls}" value="${settings.otherCostByClass?.[cls] ?? ""}" placeholder="全体（${settings.otherCostYen}）"></label>`).join("")}</div>
      <p class="rule"><b>メーカーごと</b></p>
      ${Object.entries(settings.otherCostByMaker || {}).map(([name, yen]) => `<div class="row"><span class="label">${escapeHtml(name)}</span><input type="number" min="0" step="10000" data-oc-maker="${escapeAttr(name)}" value="${yen}"><span class="muted">円</span><button type="button" class="small secondary" data-oc-maker-del="${escapeAttr(name)}">戻す</button></div>`).join("")}
      <div class="row"><select id="ocm-maker"><option value="">メーカーを選ぶ</option>${[...new Set((state.modelChoices || []).map((choice) => choice.maker).filter(Boolean))].filter((name) => !(name in (settings.otherCostByMaker || {}))).sort((a, b) => a.localeCompare(b, "ja")).map((name) => `<option value="${escapeAttr(name)}">${escapeHtml(name)}</option>`).join("")}</select><input id="ocm-yen" type="number" min="0" step="10000" placeholder="円（例：80000）"><button id="ocm-add" type="button" class="secondary">追加</button></div>
      <p class="rule"><b>車種ごと</b></p>
      ${otherCostRows().map((row) => `<div class="row" data-oc-row="${escapeAttr(row.name)}"><span class="label">${escapeHtml(row.name)}</span><input type="number" min="0" step="10000" data-oc="${escapeAttr(row.name)}" value="${row.yen}"><span class="muted">円</span><button type="button" class="small secondary" data-oc-del="${escapeAttr(row.name)}">全体に戻す</button></div>`).join("")}
      <div class="row"><select id="oc-car"><option value="">車種を選ぶ</option>${otherCostCarOptions().map((name) => `<option value="${escapeAttr(name)}">${escapeHtml(name)}</option>`).join("")}</select><input id="oc-yen" type="number" min="0" step="10000" placeholder="円（例：50000）"><button id="oc-add" type="button" class="secondary">追加</button></div>
    </section>
    </div><div>
    <h2 class="col-title">データ・共有・接続</h2>
    <section class="pn">
      <div class="t">データの保存</div>
      <div class="row">
        <label>落札データを残す期間<select id="keep-months">${[[1, "直近1か月"], [2, "直近2か月"], [3, "直近3か月（おすすめ）"], [4, "直近4か月"], [6, "直近6か月"], [12, "直近1年"]].map(([n, label]) => `<option value="${n}" ${settings.keepMonths === n ? "selected" : ""}>${label}</option>`).join("")}</select></label>
      </div>
      <p class="muted">指定した期間より古い落札データは、取得のあとと起動時に、自動で消します（ピン留めした車は、消しません）。いま保存中：${state.lotCount.toLocaleString()}台。残した期間が、相場（中央値）の計算にも使われます。週1回開催の会場なら、3か月が、USSの「直近12回」ぶんの目安です。</p>
    </section>
    <section class="pn">
      <div class="t">データの共有（クラウドの共有フォルダ）</div>
      <p class="muted">USBキーのPCで取得した<b>USSのデータ</b>（落札データ、出品予定、車名の対応表）と、小売相場の読み取り結果を、共有フォルダ経由で、ほかのPCと共有します。小売相場の読み取り結果も、共有します（読んだ日時が新しいほうを使います）。設定は、各自のPCのままです。共有を使わないときは、このPCだけで使います。</p>
      <p class="row"><label class="inline"><input id="shared-on" type="checkbox" ${state.shared?.enabled ? "checked" : ""}> 共有を使う</label></p>
      <div class="row"><label class="grow">共有フォルダの場所<input id="shared-dir" value="${escapeAttr(state.shared?.dir || "")}" placeholder="例：D:\\Dropbox\\ESCO共有（クラウドと同期しているフォルダ）"></label><button id="shared-pick" type="button" class="secondary">フォルダを選ぶ…</button><button id="shared-save" type="button">保存して確認</button></div>
      <p id="shared-status" class="muted"></p>
      <p class="row"><button id="shared-pull" type="button" class="secondary">最新にする</button></p>
      <h3>Macで使うとき（見る専用：USSアクセス不可）</h3>
      <p class="muted">MacにESCO Driveを入れるための指示を、コピーできます。Macで、Claude Code か Codex に貼ると、インストールまで、進みます。共有フォルダにも、「Mac用インストール指示…txt」として、置いてあります（Macで、このファイルを開いて、コピーできます）。</p>
      <p class="row"><button id="mac-prompt-copy" type="button" class="secondary" ${state.shared?.enabled && state.shared?.dir ? "" : "disabled"}>Mac用のインストール指示をコピー</button> <span id="mac-prompt-hint" class="muted">${state.shared?.enabled && state.shared?.dir ? "" : "先に、「共有を使う」にチェックを入れて、共有フォルダを設定してください。"}</span></p>
    </section>
    <details class="pn fold">
      <summary>会場の開催曜日（前々日・前日の表示に使います）</summary>
      ${state.venues.map((venue) => `<div class="row"><span class="label">${escapeHtml(venue.name)}</span><select data-venue="${escapeAttr(venue.code)}"><option value="">未設定</option>${weekdays.map((name, index) => `<option value="${index}" ${venue.weekday !== null && venue.weekday !== "" && Number(venue.weekday) === index ? "selected" : ""}>${name}曜</option>`).join("")}</select></div>`).join("")}
    </details>
    <details class="pn fold">
      <summary>メーカーと車名の修正</summary>
      <p class="muted">「未設定」に入った車や、メーカーが違う車は、ここから直します。</p>
      <div class="row"><input id="model-code" placeholder="型式"><input id="model-maker" placeholder="メーカー"><input id="model-name" placeholder="車名"><button id="save-model" type="button">登録</button></div>
    </details>
    ${state.viewerOnly ? "" : `<details class="pn fold">
      <summary>Chrome拡張機能の入れ方（USSの読み取りに必要）</summary>
      <ol class="ext-steps">
        <li>USSにログインするChromeで、アドレスバーに <code>chrome://extensions</code> を入れて開く</li>
        <li>右上の「デベロッパー モード」をオンにする</li>
        <li>「パッケージ化されていない拡張機能を読み込む」を押して、下のフォルダを選ぶ</li>
      </ol>
      <p class="ext-path"><code>${escapeHtml(state.extDir || "")}</code></p>
      <div class="row"><button id="ext-copy" type="button">フォルダの場所をコピー</button><button id="ext-open" type="button" class="secondary">フォルダを開く</button></div>
      <p class="muted">インストールしたPCでは、このフォルダは AppData の中にあり、ふだん隠れています。フォルダを選ぶ画面の上のアドレス欄に、コピーした場所を貼り付けて Enter を押すと、開けます。</p>
    </details>`}
    <details class="pn fold">
      <summary>接続の詳細（通常は変更不要）</summary>
      <div class="row"><label>USSのCISパス<input id="cis" value="${escapeAttr(settings.cisPath)}" size="28"></label><button id="save-cis" type="button" class="secondary">保存</button></div>
    </details>
    <details class="pn fold">
      <summary>AIアシスタントの接続先（右下のアイコン）　<span class="muted">${settings.assistantUrl ? "お店の中継サーバーにつながる" : "貼り付け方式"}</span></summary>
      <p class="muted">右下のアシスタントが、マニュアルを根拠に、使い方の質問に答えます。ふつうは、何も、変えなくて構いません（お店の中継サーバーが、最初から入っています）。<b>「なし」</b>と入れると、質問文をコピーして、ご自身のAI（ChatGPT・Claudeなど）に貼る方式になります。別の中継を使うときは、そのURLを入れます。AIに送るのは、マニュアルと、質問と、バージョン・接続状態だけです（落札データ・価格・契約番号などは、送りません）。</p>
      <div class="row"><label class="grow">中継サーバーのURL<input id="assistant-url" value="${escapeAttr(settings.assistantUrl || "なし")}" placeholder="例：https://esco-assistant.○○.workers.dev"></label></div>
      <div class="row"><label>合い言葉（中継に設定した場合だけ）<input id="assistant-token" type="password" value="${escapeAttr(settings.assistantToken || "")}" size="24"></label><button id="save-assistant" type="button" class="secondary">保存</button></div>
    </details>
    </div></div>
    <section class="pn manual-panel">
      <div class="t">操作マニュアル</div>
      <p class="muted">使い方、画面の説明、用語、困ったときの対処を、まとめています（Macのインストール手順も入っています）。</p>
      <p class="row"><a class="linkbtn secondary" href="/manual.html" target="_blank" rel="noopener">マニュアルを開く</a></p>
    </section>`;
  const saveAll = async () => {
    await postJson("/api/settings", {
      feeExTaxYen: document.getElementById("fee").value,
      otherCostYen: document.getElementById("other-cost").value || "0",
      retailPickCount: document.getElementById("pick-count").value,
      retailPickMethod: document.getElementById("pick-method").value,
      basePrefecture: document.getElementById("base").value,
    });
    await load();
  };
  document.getElementById("save").onclick = saveAll;
  document.getElementById("save-cost").onclick = saveAll;
  view.querySelectorAll("[data-oc]").forEach((input) => input.addEventListener("change", async () => {
    await postJson("/api/settings", { carName: input.dataset.oc, otherCostYen: input.value === "" ? "" : String(Math.max(0, Number(input.value) || 0)) });
    await load();
  }));
  view.querySelectorAll("[data-oc-del]").forEach((button) => button.addEventListener("click", async () => {
    await postJson("/api/settings", { carName: button.dataset.ocDel, otherCostYen: "" });
    await load();
  }));
  view.querySelectorAll("[data-oc-class]").forEach((input) => input.addEventListener("change", async () => {
    await postJson("/api/settings", { otherCostClass: input.dataset.ocClass, otherCostYen: input.value === "" ? "" : String(Math.max(0, Number(input.value) || 0)) });
    await load();
  }));
  view.querySelectorAll("[data-oc-maker]").forEach((input) => input.addEventListener("change", async () => {
    await postJson("/api/settings", { otherCostMaker: input.dataset.ocMaker, otherCostYen: input.value === "" ? "" : String(Math.max(0, Number(input.value) || 0)) });
    await load();
  }));
  view.querySelectorAll("[data-oc-maker-del]").forEach((button) => button.addEventListener("click", async () => {
    await postJson("/api/settings", { otherCostMaker: button.dataset.ocMakerDel, otherCostYen: "" });
    await load();
  }));
  document.getElementById("ocm-add")?.addEventListener("click", async () => {
    const name = document.getElementById("ocm-maker").value;
    const yen = document.getElementById("ocm-yen").value;
    if (!name || yen === "") { toast("メーカーと金額を入れてください", true); return; }
    await postJson("/api/settings", { otherCostMaker: name, otherCostYen: String(Math.max(0, Number(yen) || 0)) });
    await load();
  });
  document.getElementById("oc-add")?.addEventListener("click", async () => {
    const name = document.getElementById("oc-car").value;
    const yen = document.getElementById("oc-yen").value;
    if (!name || yen === "") { toast("車種と金額を入れてください", true); return; }
    await postJson("/api/settings", { carName: name, otherCostYen: String(Math.max(0, Number(yen) || 0)) });
    await load();
  });
  view.querySelectorAll("[data-transport]").forEach((input) => input.addEventListener("change", async () => {
    await postJson("/api/venues", { code: input.dataset.transport, transportYen: input.value === "" ? "" : input.value });
    state.settings.transportByVenue[input.dataset.transport] = input.value === "" ? null : Number(input.value);
  }));
  paintSharedStatus();
  document.getElementById("shared-save")?.addEventListener("click", async () => {
    const enabled = document.getElementById("shared-on").checked;
    const dir = document.getElementById("shared-dir").value.trim();
    const response = await fetch("/api/shared/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled, dir }) });
    const result = await response.json();
    if (result.error) { toast("保存できませんでした：" + result.error, true); return; }
    toast(enabled ? "共有を設定しました" : "共有をやめました");
    if (result.result?.pulled?.state === "merged") { state = await getJson("/api/bootstrap"); }
    paintSharedStatus();
  });
  document.getElementById("shared-pull")?.addEventListener("click", () => pullSharedNow(true));
  document.getElementById("mac-prompt-copy")?.addEventListener("click", async (event) => {
    const data = await getJson("/api/mac-prompt");
    if (data.error) { toast(data.error, true); return; }
    try { await navigator.clipboard.writeText(data.text); event.target.textContent = "コピーしました"; toast("Mac用のインストール指示を、コピーしました"); }
    catch { toast("コピーできませんでした。共有フォルダの「Mac用インストール指示…txt」を、Macで開いてください", true); }
  });
  document.getElementById("shared-pick")?.addEventListener("click", () => openFolderPicker(document.getElementById("shared-dir").value.trim(), (picked) => { document.getElementById("shared-dir").value = picked; toast("フォルダを選びました。「保存して確認」を押してください"); }));
  document.getElementById("keep-months")?.addEventListener("change", async (event) => {
    await postJson("/api/settings", { keepMonths: event.target.value });
    const result = await getJson("/api/bootstrap");
    state = result;
  });
  const confirmButton = document.getElementById("confirm-defaults");
  if (confirmButton) confirmButton.onclick = async () => { await postJson("/api/settings", { defaultsConfirmed: "1" }); await load(); refreshSetupBanner(); };
  document.getElementById("save-assistant").onclick = async () => {
    await postJson("/api/settings", { assistantUrl: document.getElementById("assistant-url").value.trim(), assistantToken: document.getElementById("assistant-token").value.trim() });
    toast("アシスタントの接続先を、保存しました");
    await load();
  };
  document.getElementById("save-cis").onclick = async () => {
    await postJson("/api/settings", { cisPath: document.getElementById("cis").value });
    await load();
  };
  view.querySelectorAll("[data-venue]").forEach((select) => select.addEventListener("change", async () => {
    await postJson("/api/venues", { code: select.dataset.venue, weekday: select.value });
  }));
  document.getElementById("save-model").onclick = async () => {
    await postJson("/api/models", {
      modelCode: document.getElementById("model-code").value,
      maker: document.getElementById("model-maker").value,
      name: document.getElementById("model-name").value,
    });
    await load();
  };
}

// ====================================================================
// 共通
// ====================================================================

function searchSummary(settings) {
  const match = ["型式"];
  if (settings.matchGrade) match.push("グレード");
  if (settings.matchColor) match.push("色");
  if (settings.matchEquipment) match.push(settings.matchSunroofLeather ? "ナビ／アルミ／サンルーフ／革" : "ナビ／アルミ");
  if (settings.matchDrive) match.push("駆動");
  const yearLimit = settings.yearFrom == null && settings.yearTo == null ? "" : `対象年式は${settings.yearFrom ?? "下限なし"}〜${settings.yearTo ?? "上限なし"}年。`;
  const mileageLimit = settings.mileageFromKm == null && settings.mileageToKm == null ? "" : `対象走行は${settings.mileageFromKm == null ? "下限なし" : settings.mileageFromKm / 10000 + "万km"}〜${settings.mileageToKm == null ? "上限なし" : settings.mileageToKm / 10000 + "万km"}。`;
  return `揃えるのは${match.join("、")}。年式は前後${settings.yearWindow}年、走行は${settings.bandKm / 10000}万kmごとにまとめ、前後${settings.mileageWindowKm / 10000}万kmまで広げます。${yearLimit}${mileageLimit}評価点${settings.minScore}未満と、${settings.minSamples}台未満は出しません。`;
}

function siteLink(name, site) {
  const used = site.status !== "missing";
  return `<a class="linkbtn secondary" href="${escapeAttr(site.searchUrl)}" target="_blank" rel="noopener">${used ? `${name}（計算に使った検索）` : `${name}で探す`}</a>`;
}

function siteStatus(site) {
  if (site.status === "missing") return "未取得";
  if (site.status === "ok") return `中央 ${man(site.medianYen)}、最安 ${man(site.lowYen)}、${site.sampleCount}台、${site.fetchedAt.slice(0, 10)}`;
  if (site.status === "stale") return `取得から日が経っています（${site.fetchedAt.slice(0, 10)}）`;
  return site.message || site.status;
}

function ussVehicleUrl(code) {
  const cisPath = state?.settings?.cisPath || "/cis/";
  const [venue, count, lot] = code.split("-");
  // USSは、検索の条件をアドレスに付けて開くと「405」を返す。出品番号検索のページ（普通に開ける）を開き、
  // 条件は「#」の後ろに付ける（USSには送られない）。拡張機能が、これを見て、その1台を表示する。
  return `https://ssl.cis6200.jp${cisPath}jp/market/bidno/bidnoSch.aspx#ud=${venue}-${count}-${lot}`;
}

function ussLink(lot) {
  if (!lot.openable && !/^[A-Z]{2}-\d+-\d+$/.test(lot.ussCode || "")) return "";
  return `<a href="${escapeAttr(ussVehicleUrl(lot.ussCode))}" target="_blank" rel="noopener" data-uss="${escapeAttr(lot.ussCode)}">USSで開く</a>`;
}

// 中央値の計算に使った落札の、全件の一覧（「くわしく」の中・表の行の下・信頼度のポップアップの窓、の3か所で、同じものを使う）
const compsCache = new Map();
async function loadComps(key) {
  let data = compsCache.get(key);
  if (!data) {
    data = await getJson("/api/cluster-lots?key=" + encodeURIComponent(key));
    compsCache.set(key, data);
  }
  return data;
}
function paintComps(box, data, mode = "price") {
  const sorters = {
    date: (a, b) => String(b.auctionDate).localeCompare(String(a.auctionDate)),
    price: (a, b) => (a.hammerMan ?? 1e9) - (b.hammerMan ?? 1e9),
    km: (a, b) => (a.mileageKm ?? 1e9) - (b.mileageKm ?? 1e9),
  };
  const rows = data.lots.slice().sort(sorters[mode]);
  box.innerHTML = `
    <p class="row"><b>中央値 ${data.medianMan}万円</b><span class="muted">（税別・${data.count}台。1行ずつ、USSで開けます）</span>
      <label>並び<select data-comps-sort><option value="date" ${mode === "date" ? "selected" : ""}>開催日の新しい順</option><option value="price" ${mode === "price" ? "selected" : ""}>落札額の安い順</option><option value="km" ${mode === "km" ? "selected" : ""}>走行の少ない順</option></select></label>
      <button type="button" class="small secondary" data-comps-csv>CSVで保存</button></p>
    <div class="scroll comps-scroll"><table><thead><tr><th>開催日</th><th>会場</th><th>グレード</th><th>年式</th><th>色</th><th>装備</th><th>駆動</th><th>走行</th><th>評価</th><th>落札</th><th></th></tr></thead>
    <tbody>${rows.map((lot) => `<tr><td>${escapeHtml(lot.auctionDate)}</td><td>${escapeHtml(lot.venue || "")}</td><td>${escapeHtml(lot.grade)}</td><td>${lot.year || ""}</td><td>${escapeHtml(lot.color)}</td><td>${escapeHtml(lot.equipment)}</td><td>${escapeHtml(lot.drive)}</td><td>${km(lot.mileageKm)}</td><td>${lot.score ?? ""}</td><td>${lot.hammerMan ?? ""}万</td><td>${ussLink(lot)}</td></tr>`).join("")}</tbody></table></div>`;
  box.querySelector("[data-comps-sort]").addEventListener("change", (event) => paintComps(box, data, event.target.value));
  box.querySelector("[data-comps-csv]").addEventListener("click", () => downloadCsv("中央値の計算に使った落札", ["開催日", "会場", "グレード", "年式", "色", "装備", "駆動", "走行(km)", "評価", "落札(万円)", "USS検索コード"], rows.map((lot) => [lot.auctionDate, lot.venue || "", lot.grade, lot.year, lot.color, lot.equipment, lot.drive, lot.mileageKm, lot.score ?? "", lot.hammerMan ?? "", lot.ussCode])));
}
async function openComps(key) {
  const box = view.querySelector(`[data-comps-box="${CSS.escape(key)}"]`);
  if (!box) return;
  const row = box.closest(".comps-row"); // 表の中では、行の下に、開く
  if (!box.hidden) { box.hidden = true; if (row) row.hidden = true; return; }
  box.hidden = false;
  if (row) row.hidden = false;
  box.innerHTML = "<span class='muted'>落札の一覧を読んでいます…</span>";
  try { paintComps(box, await loadComps(key)); } catch { box.innerHTML = "<span class='warn'>読み込めませんでした。</span>"; }
}

// 信頼度のポップアップから、一覧を、画面の中央の窓で開く（出品予定の車でも、仕入れ車種の選定でも、同じ）
function compsModal() {
  let modal = document.getElementById("comps-modal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "comps-modal";
    modal.hidden = true;
    modal.innerHTML = `<div class="modal-box" role="dialog" aria-modal="true"><header><b id="comps-modal-title"></b><button type="button" class="small secondary" data-modal-close>閉じる</button></header><div id="comps-modal-body"></div></div>`;
    modal.addEventListener("click", (event) => { if (event.target === modal || event.target.closest("[data-modal-close]")) modal.hidden = true; });
    document.addEventListener("keydown", (event) => { if (event.key === "Escape") modal.hidden = true; });
    document.body.appendChild(modal);
  }
  return modal;
}
async function openCompsModal(key, title) {
  const modal = compsModal();
  const body = modal.querySelector("#comps-modal-body");
  modal.querySelector("#comps-modal-title").textContent = title || "中央値の計算に使った落札";
  modal.hidden = false;
  body.innerHTML = "<span class='muted'>落札の一覧を読んでいます…</span>";
  try { paintComps(body, await loadComps(key)); } catch { body.innerHTML = "<span class='warn'>読み込めませんでした。</span>"; }
}
document.addEventListener("click", (event) => {
  const button = event.target.closest("[data-comps-modal]");
  if (!button) return;
  const cluster = (state?.clusters || []).find((item) => item.key === button.dataset.compsModal);
  hidePop?.();
  openCompsModal(button.dataset.compsModal, cluster ? `中央値の計算に使った落札：${cluster.label.replace(/　/g, " ")}` : "");
});
view.addEventListener("click", (event) => {
  const button = event.target.closest("[data-comps]");
  if (button) openComps(button.dataset.comps);
});

view.addEventListener("click", (event) => {
  const link = event.target.closest("a[data-uss]");
  if (!link) return;
  navigator.clipboard.writeText(link.dataset.uss).catch(() => {});
});

function stamp(iso) {
  if (!iso) return "まだありません";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return `${date.getMonth() + 1}/${date.getDate()} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function manInput(value) {
  return value == null ? "" : String(value / 10000);
}

function manToYen(id) {
  const value = document.getElementById(id).value.trim();
  return value === "" ? "" : String(Math.round(Number(value) * 10000));
}

function manToKm(id) {
  const value = document.getElementById(id).value.trim();
  if (value === "") return "";
  return String(Math.round(Number(value) * 10000));
}

function man(yen) {
  if (yen === null || yen === undefined || Number.isNaN(yen)) return "—";
  return (yen / 10000).toFixed(1) + "万円";
}
function km(value) {
  if (!Number.isFinite(value)) return "";
  return (value / 10000).toFixed(1) + "万km";
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function escapeAttr(value) {
  return escapeHtml(value);
}
async function getJson(url) {
  const response = await fetch(url);
  return response.json();
}
const SAVE_URLS = ["/api/settings", "/api/venues", "/api/models", "/api/grade-override", "/api/pins"];
async function postJson(url, body) {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const result = await response.json();
  if (SAVE_URLS.some((prefix) => url.startsWith(prefix))) {
    if (result && result.error) toast("保存できませんでした：" + result.error, true);
    else toast("保存しました");
  }
  return result;
}

// 画面の下に、短く出る知らせ（保存できたかどうか）
let toastTimer = null;
// ---- 右下のアシスタント（マニュアルを根拠に、使い方の質問に答える） ----
let assistantMessages = [];
let assistantBusy = false;
const TAB_NAMES = { home: "ダッシュボード", profit: "仕入れ車種の選定", upcoming: "入札車の選定", collect: "取得", lots: "落札データ", settings: "設定" };

// 顔だけ（チャット欄の見出し用）と、手と線つきの、右下のボタン用
const ASSISTANT_FACE = `<svg viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="aiOrangeS" x1="0.15" y1="0.1" x2="0.85" y2="0.95"><stop offset="0" stop-color="#ff8a1f"/><stop offset="1" stop-color="#f2481e"/></linearGradient></defs><circle cx="32" cy="32" r="30" fill="url(#aiOrangeS)"/><circle cx="22" cy="28" r="3.6" fill="#fff"/><circle cx="42" cy="26" r="3.6" fill="#fff"/><path d="M20 38 Q31 47 42 37" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round"/></svg>`;
const ASSISTANT_ART = `<svg viewBox="0 0 78 92" aria-hidden="true"><defs><linearGradient id="aiOrange" x1="0.15" y1="0.1" x2="0.85" y2="0.95"><stop offset="0" stop-color="#ff8a1f"/><stop offset="1" stop-color="#f2481e"/></linearGradient></defs><circle cx="40" cy="55" r="33" fill="url(#aiOrange)"/><circle cx="29" cy="50" r="4.2" fill="#fff"/><circle cx="50" cy="48" r="4.2" fill="#fff"/><path d="M27 61 Q39 70 51 60" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/><path d="M44 12 L45 24 M58 12 L53 22 M70 20 L62 26" stroke="#ff7a0a" stroke-width="4.5" stroke-linecap="round"/></svg>`;

function initAssistant() {
  if (document.getElementById("assistant-fab")) return;
  try { assistantMessages = JSON.parse(localStorage.getItem("assistantMessages") || "[]").slice(-20); } catch { assistantMessages = []; }
  const fab = document.createElement("button");
  fab.id = "assistant-fab";
  fab.type = "button";
  fab.title = "使い方を、AIに聞く";
  fab.innerHTML = `<span class="ai-face art">${ASSISTANT_ART}</span><span class="ai-text"><b>ここから相談</b><small>AIアシスタント</small></span>`;
  const panel = document.createElement("div");
  panel.id = "assistant-panel";
  panel.hidden = true;
  panel.innerHTML = `
    <div class="ai-resize" id="assistant-resize" title="ドラッグして、大きさを変える" aria-label="ドラッグして、大きさを変える"></div>
    <header><span class="ai-face sm">${ASSISTANT_FACE}</span><b>AIアシスタント</b><span class="ai-mode muted" id="assistant-mode"></span><button type="button" class="small secondary" id="assistant-wide">広げる</button><button type="button" class="small secondary" id="assistant-clear">会話を消す</button><button type="button" class="small secondary" id="assistant-close">閉じる</button></header>
    <div id="assistant-log"></div>
    <p class="muted ai-note">マニュアルに書いてあることを、AIが、案内します。AIの答えは、間違うことがあります。質問と一緒に、いま開いているタブと、画面に出ているエラーの文も、AIに伝えます。落札データや価格は、伝えません。設定を変える操作は、確認の画面で、あなたが押したときだけ、実行します。</p>
    <form id="assistant-form"><textarea id="assistant-input" rows="2" placeholder="例：小売相場を読み直すには？"></textarea><button type="submit" id="assistant-send">送る</button></form>`;
  document.body.append(fab, panel);
  fab.onclick = () => { panel.hidden = !panel.hidden; if (!panel.hidden) { paintAssistant(); document.getElementById("assistant-input").focus(); } };
  document.getElementById("assistant-close").onclick = () => { panel.hidden = true; };
  document.getElementById("assistant-clear").onclick = () => { assistantMessages = []; saveAssistantMessages(); paintAssistant(); };
  document.getElementById("assistant-form").addEventListener("submit", (event) => { event.preventDefault(); sendAssistant(); });
  document.getElementById("assistant-input").addEventListener("keydown", (event) => { if (event.key === "Enter" && !event.shiftKey && !event.isComposing) { event.preventDefault(); sendAssistant(); } });
  setupAssistantResize(panel);
  paintAssistant();
}

// チャット欄の大きさ：左上の角を、ドラッグして変える（右下に、固定したまま、左と上へ広がる）。大きさは、覚えておく
function setupAssistantResize(panel) {
  const limit = () => ({ maxW: Math.max(320, window.innerWidth - 24), maxH: Math.max(320, window.innerHeight - 90) });
  const apply = (w, h) => {
    const { maxW, maxH } = limit();
    panel.style.width = Math.min(maxW, Math.max(320, Math.round(w))) + "px";
    panel.style.height = Math.min(maxH, Math.max(320, Math.round(h))) + "px";
  };
  const save = () => { try { localStorage.setItem("assistantSize", JSON.stringify({ w: panel.offsetWidth, h: panel.offsetHeight })); } catch { /* そのまま */ } };
  try { const size = JSON.parse(localStorage.getItem("assistantSize") || "null"); if (size?.w && size?.h) apply(size.w, size.h); } catch { /* そのまま */ }
  const handle = document.getElementById("assistant-resize");
  handle.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    const start = { x: event.clientX, y: event.clientY, w: panel.offsetWidth, h: panel.offsetHeight };
    handle.setPointerCapture(event.pointerId);
    const move = (e) => apply(start.w + (start.x - e.clientX), start.h + (start.y - e.clientY));
    const up = () => { handle.removeEventListener("pointermove", move); handle.removeEventListener("pointerup", up); save(); };
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", up);
  });
  document.getElementById("assistant-wide").addEventListener("click", (event) => {
    const { maxW, maxH } = limit();
    const wide = panel.offsetWidth < Math.min(maxW, 760) - 40;
    if (wide) apply(Math.min(maxW, 760), Math.min(maxH, 720)); else apply(400, 560);
    event.target.textContent = wide ? "戻す" : "広げる";
    save();
  });
  window.addEventListener("resize", () => apply(panel.offsetWidth, panel.offsetHeight));
  const wideButton = document.getElementById("assistant-wide");
  if (panel.offsetWidth > 480 || parseInt(panel.style.width || "0", 10) > 480) wideButton.textContent = "戻す";
}

function saveAssistantMessages() {
  // 操作案（確認待ち）は、保存しない（画面を開き直すと、消える）
  try { localStorage.setItem("assistantMessages", JSON.stringify(assistantMessages.slice(-20).map(({ proposal, proposalErrors, ...rest }) => rest))); } catch { /* 保存できなくても、使える */ }
}

// いま画面に出ている、エラー文など（任意で、AIに送る。落札データ・価格は、含まれない）
function visibleScreenText() {
  return [...document.querySelectorAll(".err-msg, .usb-err, .stale-bar, .notice-line.warn")]
    .filter((el) => el.offsetParent !== null && !el.closest("#assistant-panel"))
    .map((el) => el.textContent.replace(/\s+/g, " ").trim().slice(0, 200))
    .filter(Boolean).slice(0, 3).join(" / ");
}

function paintAssistant() {
  const log = document.getElementById("assistant-log");
  if (!log) return;
  const relay = Boolean(state?.settings?.assistantUrl);
  document.getElementById("assistant-mode").textContent = relay ? "" : "（貼り付け方式）";
  const hello = relay
    ? "こんにちは！ 使い方で困ったことがあれば、気軽に聞いてくださいね。マニュアルを見て、お答えします。"
    : "こんにちは！ 使い方で困ったことがあれば、聞いてくださいね。質問文を、コピーします。ご自身のAI（ChatGPT・Claudeなど）に貼ると、答えが出ます。";
  log.innerHTML = `<div class="ai-msg bot">${escapeHtml(hello)}</div>` + assistantMessages.map((item, index) => {
    if (item.paste) return `<div class="ai-msg bot"><b>質問文を、コピーしました。</b><br>ご自身のAIのサイトを開いて、貼り付けて、送ってください。<div class="ai-links"><a href="https://chatgpt.com/" target="_blank" rel="noopener">ChatGPT</a><a href="https://claude.ai/" target="_blank" rel="noopener">Claude</a><a href="https://gemini.google.com/" target="_blank" rel="noopener">Gemini</a></div><button type="button" class="small secondary" data-ai-recopy="${index}">もう一度、コピーする</button></div>`;
    const card = proposalCardHtml(item, index);
    return `<div class="ai-msg ${item.role === "user" ? "me" : "bot"}${item.error ? " err" : ""}">${escapeHtml(item.text).replace(/\n/g, "<br>")}${card}</div>`;
  }).join("") + (assistantBusy ? '<div class="ai-msg bot muted">考えています…</div>' : "");
  log.querySelectorAll("[data-ai-apply]").forEach((button) => button.addEventListener("click", () => applyAssistantProposal(Number(button.dataset.aiApply))));
  log.querySelectorAll("[data-ai-skip]").forEach((button) => button.addEventListener("click", () => { const item = assistantMessages[Number(button.dataset.aiSkip)]; if (item) { item.proposalState = "skipped"; paintAssistant(); } }));
  log.querySelectorAll("[data-ai-recopy]").forEach((button) => button.addEventListener("click", async () => {
    const prompt = assistantMessages[Number(button.dataset.aiRecopy)]?.prompt;
    if (prompt) { try { await navigator.clipboard.writeText(prompt); toast("コピーしました"); } catch { toast("コピーできませんでした", true); } }
  }));
  log.scrollTop = log.scrollHeight;
}

// 操作案の確認カード（実行内容は、システムが書いた文。AIの文章では、ありません）
function proposalCardHtml(item, index) {
  const errors = (item.proposalErrors || []).filter(Boolean);
  const errorHtml = errors.length ? `<div class="ai-prop-err">実行しないもの：<ul>${errors.map((text) => `<li>${escapeHtml(text)}</li>`).join("")}</ul></div>` : "";
  if (!item.proposal) return errorHtml;
  const list = `<ul>${item.proposal.items.map((text) => `<li>${escapeHtml(text)}</li>`).join("")}</ul>`;
  if (item.proposalState === "done") return `<div class="ai-prop done"><b>実行しました。</b>${list}</div>${errorHtml}`;
  if (item.proposalState === "skipped") return `<div class="ai-prop muted">この操作案は、実行しませんでした。</div>${errorHtml}`;
  if (item.proposalState === "failed") return `<div class="ai-prop err"><b>実行できませんでした。</b>${escapeHtml(item.proposalMessage || "")}</div>${errorHtml}`;
  return `<div class="ai-prop"><b>次の操作を、実行しますか？</b>${list}<div class="ai-prop-btn"><button type="button" class="small" data-ai-apply="${index}">実行する</button><button type="button" class="small secondary" data-ai-skip="${index}">やめる</button></div></div>${errorHtml}`;
}

async function applyAssistantProposal(index) {
  const item = assistantMessages[index];
  if (!item?.proposal || item.proposalState) return;
  item.proposalState = "running";
  try {
    const response = await fetch("/api/assistant/apply", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.proposal.id }) });
    const result = await response.json();
    if (result.error) { item.proposalState = "failed"; item.proposalMessage = result.error; }
    else {
      item.proposalState = "done";
      state = await getJson("/api/bootstrap");
      toast("実行しました");
      if (tab === "collect") renderCollect();
    }
  } catch {
    item.proposalState = "failed"; item.proposalMessage = "システムに、つながりませんでした。";
  }
  paintAssistant();
}

async function sendAssistant() {
  const input = document.getElementById("assistant-input");
  const text = input.value.trim();
  if (!text || assistantBusy) return;
  input.value = "";
  assistantMessages.push({ role: "user", text });
  assistantBusy = true;
  paintAssistant();
  const history = assistantMessages.filter((item) => !item.paste && !item.error).map((item) => ({ role: item.role, text: item.text }));
  try {
    const response = await fetch("/api/assistant/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: history, tab: TAB_NAMES[tab] || "", includeScreen: true, screen: visibleScreenText() }) });
    const result = await response.json();
    if (result.error) assistantMessages.push({ role: "assistant", text: result.error, error: true });
    else if (result.mode === "paste") {
      assistantMessages.push({ role: "assistant", text: "", paste: true, prompt: result.prompt });
      try { await navigator.clipboard.writeText(result.prompt); } catch { toast("コピーできませんでした。「もう一度、コピーする」を押してください", true); }
    } else assistantMessages.push({ role: "assistant", text: result.answer, proposal: result.proposal || null, proposalErrors: result.proposalErrors || [] });
  } catch {
    assistantMessages.push({ role: "assistant", text: "システムに、つながりませんでした。", error: true });
  }
  assistantBusy = false;
  saveAssistantMessages();
  paintAssistant();
}

function toast(message, isError = false) {
  let el = document.getElementById("toast");
  if (!el) { el = document.createElement("div"); el.id = "toast"; document.body.appendChild(el); }
  el.textContent = (isError ? "！ " : "✓ ") + message;
  el.className = isError ? "show error" : "show";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = ""; }, isError ? 5000 : 2200);
}

// ---- 初回の診断バナー：足りないものがあるとき、どのタブでも最上段に出す ----
async function refreshSetupBanner() {
  const el = document.getElementById("setup-banner");
  if (!el) return;
  let result;
  try { result = await getJson("/api/setup/status"); } catch { return; }
  // 起動して2分以内は、拡張機能の再接続を待つ（いちどでもつながったことがあるPCだけ。初めての準備では、すぐ案内する）
  const waitingReconnect = result.extEverConnected && result.uptimeSec < 120;
  const fails = result.checks.filter((check) => check.status === "fail" && !(waitingReconnect && check.id === "ext"));
  if (!fails.length) { el.hidden = true; return; }
  el.hidden = false;
  el.innerHTML = '<b>このPCは、まだ準備が整っていません（' + fails.length + '件）：</b>' + fails.map((check) => escapeHtml(check.label)).join('、') +
    '<span class="banner-actions"><button type="button" id="banner-copy">AIに渡す指示をコピー</button><button type="button" id="banner-recheck" class="secondary">もう一度確認</button></span>' +
    '<div class="muted">コピーした文章を、Codex か Claude Code に貼って実行してもらい、終わったら「もう一度確認」を押してください。</div>';
  document.getElementById("banner-copy").onclick = async (event) => {
    await navigator.clipboard.writeText(result.prompt).catch(() => {});
    event.target.textContent = "コピーしました";
  };
  document.getElementById("banner-recheck").onclick = refreshSetupBanner;
}
refreshSetupBanner();
setInterval(refreshSetupBanner, 60000);

// ---- 画面が開いている合図（閉じると、自動取得がオフのとき、システムが自動で終了する） ----
setInterval(() => { fetch("/api/ping").catch(() => {}); }, 30000);
async function quitSystem() {
  let auto = false;
  try { auto = (await getJson("/api/ping")).autoCollect; } catch {}
  const message = auto
    ? "システムを終了します。自動取得がオンなので、終了すると、自動取得は動かなくなります。終了しますか？"
    : "システムを終了します。終了しますか？（使うときは、デスクトップのアイコンから起動します）";
  if (!window.confirm(message)) return;
  await fetch("/api/quit", { method: "POST", headers: { "X-UD-Ext": "1" } }).catch(() => {});
  document.body.innerHTML = '<main style="padding:40px;font-size:18px">システムを終了しました。このタブは閉じて構いません。</main>';
  try { window.webkit?.messageHandlers?.esco?.postMessage("quit"); } catch { /* Macの専用ウィンドウのアプリだけ。アプリも、いっしょに終わる */ }
}
document.getElementById("quit-button")?.addEventListener("click", quitSystem);

// ====================================================================
// 画面の骨組み（左メニューの件数・上の帯）とダッシュボード
// ====================================================================

async function refreshUpcoming() {
  try { upcomingData = await getJson("/api/upcoming"); } catch { /* 取れなくても、他の表示は続ける */ }
}

// 選んだ車種の、仕入れ候補の条件に合うもの
function profitSummary() {
  const chosen = selectedModelCodes();
  const all = (state?.clusters || []).filter((cluster) => chosen.has(cluster.modelCode) && cluster.inBand);
  const notable = byConfidenceThenGap(all.filter((cluster) => cluster.notable));
  const waiting = all.filter((cluster) => ["missing", "stale"].includes(cluster.carsensor.status) || ["missing", "stale"].includes(cluster.goonet.status));
  return { all, notable, waiting };
}

// 出品予定の、候補（◎○）
function upcomingPicks() {
  const items = upcomingData?.items || [];
  const chosen = selectedModelCodes();
  return items.filter((item) => chosen.has(item.modelCode) && (item.verdict === "ok" || item.verdict === "cheap"))
    .sort((a, b) => (a.verdict === b.verdict ? b.marginMan - a.marginMan : a.verdict === "ok" ? -1 : 1));
}

function viewerNotice() {
  return state?.viewerOnly ? `<section class="pn notice-card"><b>見る専用：USSアクセス不可</b><br><span class="muted">このPCは、USSの情報には、アクセスできません。USBキーのPCで取得した結果を、「設定」の「データの共有」から、取り込んで見られます。取得の操作は、できません。</span></section>` : "";
}

function updateChrome() {
  if (!state) return;
  const banner = document.getElementById("viewer-banner");
  if (banner) {
    banner.hidden = !state.viewerOnly;
    if (state.viewerOnly) banner.innerHTML = "<b>見る専用：USSアクセス不可</b>　このPCは、USSの情報には、アクセスできません。データは、共有フォルダから取り込んで見ます。";
  }
  const profit = profitSummary().notable.length;
  const picks = upcomingPicks().length;
  const setCount = (id, count) => { const el = document.getElementById(id); if (el) { el.textContent = count; el.hidden = !count; } };
  setCount("cnt-profit", profit);
  setCount("cnt-upcoming", picks);
  renderTopHero(profit, picks);
}

function renderTopHero(profit, picks) {
  const el = document.getElementById("top-hero");
  if (!el) return;
  const now = new Date();
  const youbi = "日月火水木金土"[now.getDay()];
  const headline = picks && profit ? `仕入れ候補の条件に合うものは <b>${profit}件</b>。入札車の候補は <b>${picks}台</b> あります。` : profit ? `仕入れ候補の条件に合うものが <b>${profit}件</b> あります。` : picks ? `出品予定のうち <b>${picks}台</b> が、入札車の候補です。` : "仕入れ候補の条件に合うものは、ありません。<br><small>データが古い場合は、取得タブで最新を取得してください。</small>";
  const auctions = state.today?.auctions || [];
  const plan = auctions.length
    ? auctions.map((auction) => `<div><i></i>USS${escapeHtml(auction.name)} ${escapeHtml(auction.date)}（${auction.days === 1 ? "前日" : "前々日"}）</div>`).join("")
    : `<div><i></i>近日の、取得対象の開催はありません</div>`;
  el.innerHTML = `
    <div><div class="d">${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 ${youbi}曜日</div>
    <div class="t">お疲れさまです。<br>${headline}</div></div>
    <div class="grow"></div>
    <div class="pl"><b>今日の予定</b>${plan}</div>`;
}

// Chrome拡張機能が、このシステムに同梱の版より古いとき、更新のしかたを、案内する（拡張機能は、自動では、新しくならない）
function paintExtUpdateBanner(status) {
  const box = document.getElementById("ext-update-banner");
  if (!box) return;
  if (!status.outdated) { box.hidden = true; return; }
  const open = box.dataset.open === "1";
  box.hidden = false;
  box.innerHTML = `<div class="ext-update"><div><b>Chromeの拡張機能が、古い版です。</b>（いま：${escapeHtml(status.version || "0.5.3以前")}　最新：${escapeHtml(status.bundled)}）　「USSで開く」などの新しい機能は、更新すると、使えます。</div>
    <div class="ext-url">拡張機能の画面のアドレス：<code>chrome://extensions</code> <button type="button" class="small secondary" id="ext-copy-url">コピー</button> <span class="muted">（Chromeのアドレスバーに貼り付けて、Enterを押します）</span></div>
    <div><button type="button" class="small" id="ext-howto">${open ? "手順を閉じる" : "更新のしかた"}</button></div>${open ? `<ol><li>上のアドレスを、Chromeで開きます。</li><li>「ESCO Drive USS連携」の、<b>更新ボタン（丸い矢印）</b>を、1回、押します。</li><li>版が <b>${escapeHtml(status.bundled)}</b> になれば、完了です。この案内は、消えます。</li></ol>` : ""}</div>`;
  document.getElementById("ext-howto").onclick = () => { box.dataset.open = open ? "0" : "1"; paintExtUpdateBanner(status); };
  document.getElementById("ext-copy-url").addEventListener("click", async () => { try { await navigator.clipboard.writeText("chrome://extensions"); toast("コピーしました。Chromeのアドレスバーに貼り付けてください"); } catch { toast("コピーできませんでした", true); } });
}

async function refreshExtStatus() {
  const el = document.getElementById("ext-status");
  if (!el) return;
  try {
    const status = await getJson("/api/ext/status");
    el.className = `ctl ${status.connected ? (status.outdated ? "" : "on") : "off"}`;
    el.querySelector("span").textContent = status.connected ? (status.outdated ? "拡張機能：更新が必要" : "拡張機能：接続中") : "拡張機能：未接続";
    paintExtUpdateBanner(status);
  } catch { /* 次回 */ }
}
async function refreshUssStatus(force = false) {
  const el = document.getElementById("uss-status");
  if (!el) return;
  try {
    const status = await getJson("/api/uss/state" + (force ? "?force=1" : ""));
    if (status.viewerOnly) { document.getElementById("ext-status").style.display = "none"; el.className = "ctl off"; el.querySelector("span").textContent = "見る専用：USSアクセス不可"; el.title = status.reason || ""; return; }
    if (status.ok === true) { el.className = "ctl on"; el.querySelector("span").textContent = "USS：ログイン中（USB接続）"; el.title = "USSにログインできています" + (status.via === "direct" ? "（タブなしで確認）" : status.via === "tab" ? "（USSのタブ経由で確認）" : ""); }
    else if (status.ok === false) { el.className = "ctl off"; el.querySelector("span").textContent = "USS：未ログイン（USBを確認）"; el.title = (status.reason || "") + "。USBキーを挿して、USSにログインしたChromeを開いてください。"; }
    else if (status.noTab) { el.className = "ctl"; el.querySelector("span").textContent = "USS：タブなし（未確認）"; el.title = "ChromeにUSSのタブが開いていません。USBキーを挿して、USSにログインすると、確認できます（確認のために、タブを勝手に開くことはしません）。"; }
    else { el.className = "ctl"; el.querySelector("span").textContent = "USS：確認できません"; el.title = status.reason || ""; }
  } catch { /* 次回 */ }
}
refreshExtStatus();
refreshUssStatus();
setInterval(refreshExtStatus, 15000);
setInterval(() => refreshUssStatus(), 30000);
document.getElementById("uss-status")?.addEventListener("click", () => { const span = document.querySelector("#uss-status span"); if (span) span.textContent = "USS：確認中…"; refreshUssStatus(true); });

function confBadge(level) {
  const label = { high: "高", mid: "中", low: "低" }[level];
  return label ? `<span class="badge ${level === "high" ? "ok" : level}">${label}</span>` : `<span class="badge">?</span>`;
}

async function renderHome() {
  const token = ++paint;
  await refreshUpcoming();
  if (token !== paint) return;
  updateChrome();
  const settings = state.settings;
  const { notable, waiting } = profitSummary();
  const picks = upcomingPicks();
  const best = [...notable].sort((a, b) => b.gapYen - a.gapYen)[0]; // 「最大の差額」は、信頼度に関係なく、いちばん大きいもの
  const fetched = upcomingData?.items?.[0]?.fetchedAt;
  const status = (ok, name, text) => `<div class="prow"><span class="badge ${ok ? "ok" : ""}">${ok ? "済" : "！"}</span><div><div class="nm">${name}</div><div class="ds">${text}</div></div></div>`;
  let sharedRow = "";
  try {
    const sh = await getJson("/api/shared/status");
    if (sh.enabled) sharedRow = status(sh.state === "uptodate" || sh.state === "empty", "データの共有", sharedLine(sh));
  } catch { /* なし */ }

  view.innerHTML = `
    <div class="h-line">注目</div>
    <div class="kpi">
      <button type="button" class="k n" data-go="profit"><div class="l">仕入れ車種の選定</div><div class="v">${notable.length}<small>件</small></div><div class="s">差額 ${man(settings.gapThresholdYen)} 以上</div></button>
      <button type="button" class="k r" data-go="upcoming"><div class="l">入札車の選定</div><div class="v">${picks.length}<small>台</small></div><div class="s">${upcomingData?.items?.length ? `出品 ${upcomingData.items.length}台のうち` : "まだ取得していません"}</div></button>
      <button type="button" class="k g" data-go="lots"><div class="l">落札データ</div><div class="v">${state.lotCount.toLocaleString()}<small>台</small></div><div class="s">${state.latestAuctionDate ? `最新の開催 ${escapeHtml(state.latestAuctionDate)}` : ""}</div></button>
      <button type="button" class="k y" data-go="profit"><div class="l">いちばん大きい差額（粗利の目安）</div><div class="v">${best ? "+" + (best.gapYen / 10000).toFixed(1) : "—"}<small>${best ? "万円" : ""}</small></div><div class="s">${best ? escapeHtml(best.label.split("　")[0]) : "該当なし"}</div></button>
    </div>
    <div class="g2">
      <div>
        <div class="pn"><div class="t">仕入れ車種の選定<span>条件：差額 ${man(settings.gapThresholdYen)} 以上・仕入の ${settings.gapRatePct}% 以上</span></div>
          ${notable.length ? notable.slice(0, 4).map((cluster) => {
            const parts = cluster.label.split("　");
            const structured = parts.length === 7;
            const desc = structured ? [...parts.slice(1, 5).filter((part) => !/不問|不明/.test(part)), `${parts[5]}・${parts[6]}`].join("・") : "";
            return `<div class="prow">${confBadge(cluster.confidence)}<div><div class="nm">${escapeHtml(structured ? parts[0] : cluster.label)}</div><div class="ds">${escapeHtml(desc)}</div></div><div class="gain">+${man(cluster.gapYen)}<small>仕入 ${man(cluster.costYen)} / 小売 ${cluster.retailEstimateYen === null ? "—" : man(cluster.retailEstimateYen)}</small></div></div>`;
          }).join("") : `<p class="muted">いま、仕入れ候補の条件に合うものはありません。</p>`}
          <button type="button" class="more-btn" data-go="profit">くわしく見る ›</button></div>
        <div class="pn"><div class="t">入札車の選定<span>上限落札額で買った場合</span></div>
          ${picks.length ? `<div class="scroll"><table><thead><tr><th>予想時刻</th><th>No.</th><th>車</th><th>年式・走行</th><th>上限落札額</th><th>想定利益</th></tr></thead><tbody>
            ${picks.slice(0, 6).map((item) => `<tr><td class="nowrap">${escapeHtml(item.auctionTime || "")}</td><td class="nowrap">${escapeHtml(item.lotNo)}</td><td><b>${escapeHtml(item.modelName)}</b> ${escapeHtml(item.grade)}</td><td class="nowrap">${item.year}年・${km(item.mileageKm)}</td><td class="num">${item.hammerMaxMan}万円</td><td class="num gainc">${item.profitAtMax ? (item.profitAtMax.profitYen >= 0 ? "+" : "") + man(item.profitAtMax.profitYen) : "—"}</td></tr>`).join("")}</tbody></table></div>` : `<p class="muted">${upcomingData?.items?.length ? "候補になる出品車は、ありませんでした。" : "「入札車の選定」タブで、出品予定を取得してください。"}</p>`}
          <button type="button" class="more-btn" data-go="upcoming">くわしく見る ›</button></div>
      </div>
      <div>
        <div class="pn"><div class="t">取得の状況</div>
          ${status(Boolean(state.lastImportedAt), "落札データ", state.lastImportedAt ? `最終取得 ${escapeHtml(stamp(state.lastImportedAt))}` : "まだ取得していません")}
          ${status(!waiting.length, "小売相場（カーセンサー・グーネット）", waiting.length ? `読み取り待ち ${waiting.length}件` : "対象は、すべて読み取り済み")}
          ${status(Boolean(fetched), "出品予定", fetched ? `最終取得 ${escapeHtml(stamp(fetched))}` : "まだ取得していません")}
          ${sharedRow}
          ${status(Boolean(settings.autoCollect), "自動取得", settings.autoCollect ? `オン（開催の${settings.collectDaysBefore}日前に、自動で取得します）` : "オフ（設定で、自動取得にできます）")}
          <button type="button" class="more-btn" data-go="collect">取得へ ›</button></div>
      </div>
    </div>`;
  view.querySelectorAll("[data-go]").forEach((button) => button.addEventListener("click", () => show(button.dataset.go)));
}

// 表をCSVにして保存する（Excelで開ける。日本語が文字化けしないよう、先頭に目印を付ける）
function downloadCsv(name, head, rows) {
  const cell = (value) => { const text = value === null || value === undefined ? "" : String(value); return /[",\n\r]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text; };
  const body = [head, ...rows].map((row) => row.map(cell).join(",")).join("\r\n") + "\r\n";
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob(["\uFEFF" + body], { type: "text/csv;charset=utf-8" }));
  link.download = name + "_" + new Date().toISOString().slice(0, 10) + ".csv";
  document.body.appendChild(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(link.href), 5000);
}

// ====================================================================
// データの共有（クラウドの共有フォルダ）
// ====================================================================

function sharedStamp(iso) {
  return iso ? stamp(iso) : "";
}

function sharedLine(sh) {
  if (!sh.enabled) return "共有は使っていません（このPCだけで使っています）";
  if (sh.state === "unreachable") return "共有フォルダにつながりません";
  if (sh.state === "empty") return "共有フォルダには、まだ、データがありません";
  if (sh.state === "too-new") return "共有データが新しい形式です。アプリを更新してください";
  const when = sh.writtenAt ? `${sharedStamp(sh.writtenAt)}に、${sh.writer || "別のPC"}が書き出し` : "";
  if (sh.state === "newer") return `共有に、新しいデータがあります（更新${sh.sharedGeneration}回目。${when}）`;
  if (sh.state === "syncing") return "共有データを同期中です";
  return `最新です（更新${sh.sharedGeneration}回目。${when}）`;
}

async function paintSharedStatus() {
  const el = document.getElementById("shared-status");
  if (!el) return;
  try {
    const sh = await getJson("/api/shared/status");
    const ready = Boolean(sh.enabled && sh.dir);
    const copyButton = document.getElementById("mac-prompt-copy");
    if (copyButton) copyButton.disabled = !ready;
    const hint = document.getElementById("mac-prompt-hint");
    if (hint) hint.textContent = ready ? "" : "先に、「共有を使う」にチェックを入れて、共有フォルダを設定してください。";
    el.textContent = sharedLine(sh) + (sh.lastError ? `／書き出しの失敗：${sh.lastError}` : "");
  } catch { /* 次回 */ }
}

// 共有の最新を取り込む。interactive：ボタンから押されたとき（結果を、はっきり知らせる）
let syncPopupShown = false;
async function pullSharedNow(interactive) {
  let result;
  try {
    const response = await fetch("/api/shared/pull", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ wait: false }) });
    result = await response.json();
  } catch { return; }
  if (result.state === "merged") {
    toast(`共有の最新を取り込みました（${result.lotsAdded ?? 0}台が増えました）`);
    state = await getJson("/api/bootstrap");
    await refreshUpcoming();
    show(tab);
  } else if (result.state === "syncing") {
    if (interactive || !syncPopupShown) showSyncPopup(result);
  } else if (interactive) {
    toast(result.message || "確認しました");
    paintSharedStatus();
  }
  if (result.state !== "syncing") syncPopupShown = false;
}

function showSyncPopup(result) {
  syncPopupShown = true;
  document.getElementById("sync-popup")?.remove();
  const box = document.createElement("div");
  box.id = "sync-popup";
  const when = result.writtenAt ? `（書き出し：${sharedStamp(result.writtenAt)}、PC名：${escapeHtml(result.writer || "")}）` : "";
  box.innerHTML = `<div class="sync-card"><h3>共有データを同期中です</h3>
    <p>クラウドの同期が、まだ終わっていません${when}。<br>しばらく待ってから、「もう一度確認」を押してください。</p>
    <p class="muted">${escapeHtml(result.message || "")}</p>
    <div class="row"><button id="sync-retry" type="button">もう一度確認</button><button id="sync-keep" type="button" class="secondary">いまのデータのまま使う</button></div></div>`;
  document.body.appendChild(box);
  document.getElementById("sync-keep").onclick = () => box.remove();
  document.getElementById("sync-retry").onclick = async () => { box.remove(); await pullSharedNow(true); };
}

// 起動したときと、2分ごとに、共有の最新を確認する（共有を使っていなければ、何もしない）
async function sharedAutoCheck() {
  try {
    const sh = await getJson("/api/shared/status");
    if (sh.enabled && (sh.state === "newer" || sh.state === "syncing")) await pullSharedNow(false);
  } catch { /* 次回 */ }
}
setTimeout(sharedAutoCheck, 2500);
setInterval(sharedAutoCheck, 120000);

// ====================================================================
// フォルダを、クリックで選ぶ画面（共有フォルダの指定に使う）
// ====================================================================

async function fsList(p) {
  const response = await fetch("/api/fs/list?path=" + encodeURIComponent(p || ""), { headers: { "X-UD-Ext": "1" } });
  return response.json();
}

function openFolderPicker(startPath, onPick) {
  document.getElementById("folder-picker")?.remove();
  const box = document.createElement("div");
  box.id = "folder-picker";
  box.innerHTML = `<div class="fp-card">
    <h3>共有するフォルダを選ぶ</h3>
    <p class="muted">クラウド（Dropboxなど）と同期しているフォルダを選びます。目的のフォルダまで、クリックで進み、「このフォルダを選ぶ」を押します。</p>
    <div class="fp-path" id="fp-path"></div>
    <div class="fp-list" id="fp-list"></div>
    <div class="row fp-new"><input id="fp-newname" placeholder="新しいフォルダの名前（例：ESCO共有）"><button id="fp-mkdir" type="button" class="secondary">ここに新しいフォルダを作る</button></div>
    <div class="row"><button id="fp-choose" type="button">このフォルダを選ぶ</button><button id="fp-cancel" type="button" class="secondary">やめる</button></div>
  </div>`;
  document.body.appendChild(box);
  let current = "";

  const render = async (p) => {
    const list = document.getElementById("fp-list");
    const data = await fsList(p);
    if (data.error) { list.innerHTML = `<p class="muted">${escapeHtml(data.error)}</p>`; return; }
    current = data.path;
    document.getElementById("fp-path").textContent = current || "よくある場所";
    document.getElementById("fp-choose").disabled = !current;
    document.getElementById("fp-mkdir").disabled = !current;
    const rows = [];
    if (current) rows.push(`<button type="button" class="fp-row up" data-go="${escapeAttr(data.parent || "")}">⬆ 一つ上へ</button>`);
    for (const place of data.places || []) rows.push(`<button type="button" class="fp-row place" data-go="${escapeAttr(place.path)}">★ ${escapeHtml(place.label)}<small>${escapeHtml(place.path)}</small></button>`);
    for (const dir of data.dirs || []) rows.push(`<button type="button" class="fp-row" data-go="${escapeAttr(dir.path)}">📁 ${escapeHtml(dir.name)}</button>`);
    if (!rows.length) rows.push('<p class="muted">フォルダがありません。</p>');
    list.innerHTML = rows.join("");
    list.querySelectorAll("[data-go]").forEach((button) => button.addEventListener("click", () => render(button.dataset.go)));
    list.scrollTop = 0;
  };

  document.getElementById("fp-cancel").onclick = () => box.remove();
  document.getElementById("fp-choose").onclick = () => { if (current) { onPick(current); box.remove(); } };
  document.getElementById("fp-mkdir").onclick = async () => {
    const name = document.getElementById("fp-newname").value.trim();
    if (!name) { toast("新しいフォルダの名前を入れてください", true); return; }
    const response = await fetch("/api/fs/mkdir", { method: "POST", headers: { "Content-Type": "application/json", "X-UD-Ext": "1" }, body: JSON.stringify({ parent: current, name }) });
    const result = await response.json();
    if (result.error) { toast(result.error, true); return; }
    document.getElementById("fp-newname").value = "";
    await render(result.path); // 作ったフォルダの中へ入る
  };
  render(startPath && startPath.length ? startPath : "").catch(() => render(""));
}

// ====================================================================
// 個別の仕入れ値の金額帯（メーカー単位・車種単位・グレード単位）
//   画面：メーカーを選ぶ → （その場で金額を入れて保存すれば、メーカー単位）→ 車種を選ぶ → （車種単位）→ グレードを選ぶ → （グレード単位）
// ====================================================================

// 金額指定中のもの（メーカー・車種・グレード）
function bandItems() {
  const items = [];
  for (const [name, band] of Object.entries(state.settings.makerBands || {})) {
    if (band && (band.minYen != null || band.maxYen != null)) items.push({ kind: "maker", name, min: band.minYen ?? null, max: band.maxYen ?? null });
  }
  for (const [name, cond] of Object.entries(state.settings.carConditions || {})) {
    if (cond && (cond.costMinYen != null || cond.costMaxYen != null)) items.push({ kind: "car", name, min: cond.costMinYen ?? null, max: cond.costMaxYen ?? null });
  }
  for (const [key, band] of Object.entries(state.settings.gradeBands || {})) {
    if (band && (band.minYen != null || band.maxYen != null)) items.push({ kind: "grade", name: key, car: band.car || key.split("|")[0], gradeKey: key.split("|").slice(1).join("|"), gradeLabel: band.label || key.split("|").slice(1).join("|"), min: band.minYen ?? null, max: band.maxYen ?? null });
  }
  return items;
}

// 金額帯を保存する（万円で受けて、円で送る）。両方空なら、指定の解除。
//   target：{ kind: "maker"|"car"|"grade", name, car?, gradeKey?, gradeLabel? }
async function saveBand(target, minMan, maxMan) {
  if (Number(minMan) > 100000 || Number(maxMan) > 100000) {
    alert("仕入れ値の金額帯は、「万円」で入れてください。\n例：300万円なら、300 と入れます（3000000 ではありません）。");
    return false;
  }
  const toYen = (value) => (String(value).trim() === "" ? "" : String(Math.round(Number(value) * 10000)));
  const payload = target.kind === "maker" ? { makerName: target.name }
    : target.kind === "car" ? { carName: target.name }
      : { gradeBandCar: target.car, gradeBandKey: target.gradeKey, gradeBandLabel: target.gradeLabel };
  const result = await postJson("/api/settings", { ...payload, costMinYen: toYen(minMan), costMaxYen: toYen(maxMan) });
  if (result && result.error) return false;
  state = await getJson("/api/bootstrap");
  return true;
}

function bindBandList() {
  const targetOf = (row) => ({ kind: row.dataset.kind, name: row.dataset.name, car: row.dataset.car, gradeKey: row.dataset.gradekey, gradeLabel: row.dataset.gradelabel });
  view.querySelectorAll(".band-row input").forEach((input) => input.addEventListener("change", async () => {
    const row = input.closest(".band-row");
    await saveBand(targetOf(row), row.querySelector('[data-which="min"]').value, row.querySelector('[data-which="max"]').value);
  }));
  view.querySelectorAll("[data-band-del]").forEach((button) => button.addEventListener("click", async () => {
    const row = button.closest(".band-row");
    if (await saveBand(targetOf(row), "", "")) { toast("金額指定を解除しました"); show(tab); }
  }));
  document.getElementById("band-add")?.addEventListener("click", openBandPicker);
}

// 追加の画面：メーカー → 車種 → グレード、と順に選び、その時点の段で、金額を入れて保存する
function openBandPicker() {
  document.getElementById("band-picker")?.remove();
  const box = document.createElement("div");
  box.id = "band-picker";
  box.innerHTML = `<div class="bp-card">
    <h3>金額指定を追加する</h3>
    <div class="bp-crumb" id="bp-crumb"></div>
    <div id="bp-edit" class="bp-choice"></div>
    <input id="bp-q" class="bp-search" autocomplete="off">
    <div class="bp-list" id="bp-list"></div>
    <div class="row"><button id="bp-cancel" type="button" class="secondary">閉じる</button></div>
  </div>`;
  document.body.appendChild(box);
  const sel = { maker: "", car: "", carKey: "", grade: null }; // car：表示名、carKey：サーバー側で、そろえた名前
  let grades = [];
  const input = document.getElementById("bp-q");

  const existing = () => {
    if (sel.grade) return state.settings.gradeBands?.[`${sel.carKey}|${sel.grade.key}`];
    if (sel.car) { const c = state.settings.carConditions?.[sel.carKey]; return c ? { minYen: c.costMinYen ?? null, maxYen: c.costMaxYen ?? null } : null; }
    if (sel.maker) return state.settings.makerBands?.[sel.maker];
    return null;
  };
  const levelName = () => (sel.grade ? "グレード" : sel.car ? "車種" : "メーカー");
  const targetName = () => (sel.grade ? `${sel.car} › ${sel.grade.label}` : sel.car || sel.maker);

  const carsOfMaker = () => {
    const rows = new Map();
    for (const choice of state.modelChoices || []) if (choice.maker === sel.maker && choice.name) rows.set(choice.name, { name: choice.name, sub: "データあり" });
    for (const car of allCars()) if (car.maker === sel.maker && !rows.has(car.name)) rows.set(car.name, { name: car.name, sub: "" });
    return [...rows.values()];
  };
  const makerList = () => {
    const rows = new Map();
    for (const choice of state.modelChoices || []) if (choice.maker) rows.set(choice.maker, { name: choice.maker, sub: "データあり" });
    for (const maker of makerNames()) if (!rows.has(maker)) rows.set(maker, { name: maker, sub: "" });
    return [...rows.values()];
  };

  const paintCrumb = () => {
    const parts = [`<button type="button" class="crumb" data-up="0">メーカー</button>`];
    if (sel.maker) parts.push(`<button type="button" class="crumb${sel.car ? "" : " now"}" data-up="1">${escapeHtml(sel.maker)}</button>`);
    if (sel.car) parts.push(`<button type="button" class="crumb${sel.grade ? "" : " now"}" data-up="2">${escapeHtml(sel.car)}</button>`);
    if (sel.grade) parts.push(`<span class="crumb now">${escapeHtml(sel.grade.label)}</span>`);
    document.getElementById("bp-crumb").innerHTML = parts.join(" › ");
    document.querySelectorAll("#bp-crumb [data-up]").forEach((button) => button.addEventListener("click", () => {
      const level = Number(button.dataset.up);
      if (level < 2) { sel.car = ""; sel.carKey = ""; sel.grade = null; grades = []; }
      if (level < 1) sel.maker = "";
      if (level === 2) sel.grade = null;
      refresh();
    }));
  };

  // その段の金額を、入れて保存する欄（メーカー・車種・グレードのどこを選んでいても出る）
  const paintEdit = () => {
    const area = document.getElementById("bp-edit");
    if (!sel.maker) { area.hidden = true; return; }
    area.hidden = false;
    const cur = existing() || {};
    area.innerHTML = `<b>この${levelName()}の金額帯：${escapeHtml(targetName())}</b>
      <div class="row"><label>下限<input id="bp-min" type="number" min="0" placeholder="なし" value="${cur.minYen == null ? "" : cur.minYen / 10000}">万円</label><label>上限<input id="bp-max" type="number" min="0" placeholder="なし" value="${cur.maxYen == null ? "" : cur.maxYen / 10000}">万円</label><button id="bp-save" type="button">この${levelName()}に保存</button></div>
      <p class="muted">${sel.grade ? "" : `さらに、下の一覧から、${sel.car ? "グレード" : sel.maker ? "車種" : ""}を選ぶと、${sel.car ? "グレード" : "車種"}単位で、指定できます。`}</p>`;
    document.getElementById("bp-save").onclick = async () => {
      const min = document.getElementById("bp-min").value;
      const max = document.getElementById("bp-max").value;
      if (min === "" && max === "") { toast("下限か上限の、どちらかを入れてください", true); return; }
      const target = sel.grade ? { kind: "grade", car: sel.carKey, gradeKey: sel.grade.key, gradeLabel: sel.grade.label }
        : sel.car ? { kind: "car", name: sel.carKey } : { kind: "maker", name: sel.maker };
      if (await saveBand(target, min, max)) { box.remove(); toast(`${levelName()}の金額指定を保存しました`); show(tab); }
    };
  };

  const paintList = () => {
    const q = normText(input.value);
    const list = document.getElementById("bp-list");
    let rows = [];
    if (!sel.maker) { input.placeholder = "メーカー名で探す（例：メルセデス、トヨタ）"; rows = makerList().filter((r) => !q || normText(r.name).includes(q)).map((r) => ({ label: r.name, sub: r.sub, pick: () => { sel.maker = r.name; refresh(); } })); }
    else if (!sel.car) { input.placeholder = `${sel.maker}の車種で探す`; rows = carsOfMaker().filter((r) => !q || normText(r.name).includes(q)).map((r) => ({ label: r.name, sub: r.sub, pick: () => pickCar(r.name) })); }
    else if (!sel.grade) { input.placeholder = `${sel.car}のグレードで探す`; rows = grades.filter((g) => !q || normText(g.label).includes(q)).map((g) => ({ label: g.label, sub: `${g.count}台`, pick: () => { sel.grade = g; refresh(); } })); }
    else { input.hidden = true; list.innerHTML = '<p class="muted">グレードまで選びました。上の欄に、金額を入れて、保存してください。</p>'; return; }
    input.hidden = false;
    list.innerHTML = rows.length
      ? rows.map((r, i) => `<button type="button" class="bp-row" data-i="${i}">${escapeHtml(r.label)}<small>${escapeHtml(r.sub || "")}</small></button>`).join("")
      : `<p class="muted">${sel.car && !grades.length ? "この車種の、取得済みデータが、まだありません（グレードの一覧は、データから作ります）。" : "該当するものが、ありません。"}</p>`;
    list.querySelectorAll("[data-i]").forEach((button) => button.addEventListener("click", () => rows[Number(button.dataset.i)].pick()));
  };

  const pickCar = async (name) => {
    const data = await getJson("/api/grades?car=" + encodeURIComponent(name));
    sel.car = name; sel.carKey = data.carKey || name; grades = data.grades || []; sel.grade = null;
    refresh();
  };
  const refresh = () => { input.value = ""; paintCrumb(); paintEdit(); paintList(); };

  // 入力欄は作り直さない（日本語の変換が壊れないように、変換が終わってから、一覧を更新する）
  let composing = false;
  input.addEventListener("compositionstart", () => { composing = true; });
  input.addEventListener("compositionend", () => { composing = false; paintList(); });
  input.addEventListener("input", () => { if (!composing) paintList(); });
  document.getElementById("bp-cancel").onclick = () => box.remove();
  refresh();
  input.focus();
}

// 出品予定の取得対象（会場と車種の数）の説明文
function upTargetText() {
  const s = state.settings;
  const names = (s.targetVenues || []).map((code) => (state.venues.find((v) => v.code === code) || {}).name || code);
  const cars = (s.collectCars || []).length;
  return `会場：${names.length ? names.join("・") : "未選択"} ／ 車種：${cars ? cars + "車種" : "未選択"}`;
}

// USSにつながっていない／ログインできていないときの案内（赤い枠で、押した場所のすぐ下に出す）
//   bridge：Chromeの拡張機能につながっていない、login：つながっているが、USSにログインできていない
function usbErrHtml(kind) {
  return kind === "bridge"
    ? '<div class="usb-err"><b>Chromeの拡張機能につながっていません</b><br>USBキーを挿して、USSにログインしたChromeを開いてから、もう一度押してください。</div>'
    : '<div class="usb-err"><b>USSにログインできていません</b><br>USBキーは挿したまま、ChromeでUSSにログインしてから、もう一度押してください。<small>（USBキーが挿さっていない場合は、挿してください）</small></div>';
}
function showUsbError(afterId, notify = true, kind = "login") {
  document.querySelectorAll(".usb-err").forEach((el) => el.remove());
  const anchor = document.getElementById(afterId);
  if (!anchor) return;
  anchor.insertAdjacentHTML("afterend", usbErrHtml(kind));
  if (notify) toast(kind === "bridge" ? "Chromeの拡張機能につながっていません" : "USSにログインできていません", true);
}
// 前回の失敗が残っているだけの場合は出さない。いま実際にログインできていないときだけ、案内を出す。
async function checkUssLogin(afterId) {
  try {
    const status = await getJson("/api/uss/state");
    if (status && status.ok === false) showUsbError(afterId, false, "login");
    else document.querySelectorAll(".usb-err").forEach((el) => el.remove());
  } catch { /* 確認できないときは出さない */ }
}

// 残り時間の目安：動き始めてからの、1件あたりの平均時間 × 残り件数（段階が変わるごとに、数え直す）
let etaState = null;
function etaReset() { etaState = null; }
function etaText(key, remaining) {
  const now = Date.now();
  if (!etaState || etaState.key !== key || remaining > etaState.rem) etaState = { key, t: now, rem: remaining };
  const done = etaState.rem - remaining;
  const elapsed = (now - etaState.t) / 1000;
  if (remaining <= 0 || done < 2 || elapsed < 10) return "　残り時間：計算中…";
  const sec = (elapsed / done) * remaining;
  const minutes = Math.ceil(sec / 60);
  return minutes <= 1 ? "　残り時間の目安：1分未満" : `　残り時間の目安：約${minutes}分`;
}

// 出品予定の、開催日・出品の総数・取得した台数。開催まで何日か、いつ時点の数字かが分かるようにする。
function upcomingStatusHtml(items) {
  if (!items.length) return "";
  const groups = new Map();
  for (const item of items) {
    const key = item.venueCode + "|" + item.auctionDate;
    if (!groups.has(key)) groups.set(key, { venue: item.venue, date: item.auctionDate, total: item.venueTotal, fetchedAt: item.venueTotalAt || item.fetchedAt, carsAt: item.fetchedAt, count: 0 });
    groups.get(key).count += 1;
  }
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const rows = [...groups.values()].map((g) => {
    const days = Math.round((new Date(g.date + "T00:00:00") - today) / 86400000);
    const when = days > 0 ? `開催まで あと${days}日` : days === 0 ? "本日開催" : "";
    return `<div class="up-stat"><b>${escapeHtml(g.venue)}</b> ${escapeHtml(g.date.slice(5).replace("-", "/"))}開催<span class="when">${when}</span>
      <span>出品の総数 ${g.total ? `<b>${g.total.toLocaleString()}台</b>（${escapeHtml(stamp(g.fetchedAt))} 時点）` : `<b>—</b>（次に取得すると表示されます）`}</span>
      <span>うち、前回取得した車種 <b>${g.count.toLocaleString()}台</b>（${escapeHtml(stamp(g.carsAt))} 取得）</span></div>`;
  }).join("");
  return `<div class="up-stats">${rows}${upcomingCarsNotice()}<p class="muted">出品の総数は、システムを開いたとき（USSにつながっているとき）に、最新にします。開催日までの日数と見比べて、まだ出品が少ない時期かどうかの目安にしてください。</p></div>`;
}

// 出品予定を取得したときの車種が、いまの取得の設定の車種と違うときの案内
// （出品予定を取得したときに、車種を覚えておく。覚えていない古いデータでは、案内を出さない。）
function upcomingCarsNotice() {
  const keysOf = (list) => (list || []).map((key) => key.split("	")).filter((parts) => parts.length >= 2).map(([maker, name]) => ({ maker: maker.trim(), name: name.trim(), id: normText(maker + "|" + name) }));
  const fetched = keysOf(state.settings.upcomingCars);
  const wanted = keysOf(state.settings.collectCars);
  if (!fetched.length || !wanted.length) return "";
  const fetchedIds = new Set(fetched.map((car) => car.id));
  const wantedIds = new Set(wanted.map((car) => car.id));
  if (fetchedIds.size === wantedIds.size && [...fetchedIds].every((id) => wantedIds.has(id))) return "";
  const label = (list) => list.map((car) => car.maker + " " + car.name).join("、");
  return `<p class="warn notice-line">いまの「取得する車種」（${escapeHtml(label(wanted))}）は、前回、出品予定を取得したときの車種（${escapeHtml(label(fetched))}）と、違います。表示されている出品予定は、前回の車種のものです。いまの車種で見るには、下の「出品予定を取得して、入札車を選ぶ」を押してください。</p>`;
}

// 並び：信頼度の高い順（高 → 中 → 低）。同じ信頼度の中では、差額の大きい順。
function byConfidenceThenGap(list) {
  const rank = { high: 0, mid: 1, low: 2 };
  return [...list].sort((a, b) => (rank[a.confidence] ?? 3) - (rank[b.confidence] ?? 3) || b.gapYen - a.gapYen);
}

// 拡張機能のフォルダ：場所のコピーと、フォルダを開く（設定の「Chrome拡張機能の入れ方」）
document.addEventListener("click", async (event) => {
  if (event.target?.id === "ext-copy") {
    try { await navigator.clipboard.writeText(state.extDir || ""); toast("フォルダの場所をコピーしました"); } catch { toast("コピーできませんでした。上の場所を、選んでコピーしてください", true); }
  }
  if (event.target?.id === "ext-open") {
    const result = await postJson("/api/open-ext-folder", {});
    if (result && result.error) toast(result.error, true); else toast("フォルダを開きました");
  }
});

// 右下のアシスタントは、すべての定義のあと（ファイルの最後）で、置く
initAssistant();
