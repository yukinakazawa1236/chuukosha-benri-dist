import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { db, getSettings, modelChoices, modelNameMap, rememberModel, saveSettings } from "./lib/db.mjs";
import { regionChoices } from "./lib/match.mjs";
import { lotsFromCis, lotsFromWorkbook } from "./lib/import-excel.mjs";
import { getCoverage, listLots, pruneOldLots, replaceUpcoming, saveLots, setCoverage, updateVenueTotal, upcomingVenueCodes } from "./lib/lots.mjs";
import { applySharedPreset, publishShared, pullShared, saveSharedConfig, sharedStatus, syncShared } from "./lib/shared.mjs";
import { NO_USS_MESSAGE, isMac, viewerOnly } from "./lib/platform.mjs";
import { listDirs, makeDir } from "./lib/fs-browse.mjs";
import { MAC_PROMPT_FILENAME, macInstallPrompt } from "./lib/mac-prompt.mjs";
import { buildClusters, evaluateUpcoming, gradesOfCar } from "./lib/clusters.mjs";
import { carFiltersSummary } from "./lib/auto-rules.mjs";
import { askRelay, pastePrompt, statusText } from "./lib/assistant.mjs";
import { applyProposal, extractProposal, holdProposal, normalizeActions } from "./lib/assistant-actions.mjs";
import { marketCancel, marketJob, readAllMarkets, readNextMarkets } from "./lib/market.mjs";
import { maybeNotify, todayView } from "./lib/today.mjs";
import { checkLatest, isNewer, readVersionFile } from "./lib/updater.mjs";
import { autoReadState, autoReadTick, autoState, autoTick, lastAutoText, pickText, runAutoChain } from "./lib/auto.mjs";
import { bridgeStatus, noteExtVersion, pollJob, receiveResult, ussFetch } from "./lib/ext-bridge.mjs";
import { collectJob, refreshVenueTotals, runCollect, runUpcoming, upcomingJob } from "./lib/uss-collect.mjs";
import { listCsGrades, setGradeOverride } from "./lib/cs-grades.mjs";
import { COLOR_OPTIONS, SCORE_4_UP, SCORE_OPTIONS, filtersSummary } from "./lib/collect-filters.mjs";
import { ROOT, agentPromptFor, liveChecks, staticChecks, summarize } from "./lib/setup-check.mjs";

const root = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(root, "public");
const carCatalog = JSON.parse(fs.readFileSync(path.join(root, "lib", "carsensor-catalog.json"), "utf8"));
const port = Number(process.env.UD_PORT) || 3847;
let lastActive = Date.now();
const startedAt = Date.now();
// 拡張機能が、いちどでもつながったことがあるか（起動直後の再接続待ちと、初めての準備を、見分けるため）
let extEverConnected = Boolean(db.prepare("SELECT value FROM settings WHERE key = 'ext_ever_connected'").get());
function noteExtConnected() {
  if (extEverConnected || !bridgeStatus().connected) return;
  extEverConnected = true;
  db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('ext_ever_connected', '1')").run();
}
const IDLE_EXIT_MS = Number(process.env.UD_IDLE_MS) || 5 * 60 * 1000;

// いま動いている版（起動した時点のもの）。更新で、ファイルだけ新しくなっても、動いているのは古い版のままなので、起動時に覚えておく。
const runningVersion = readVersionFile().version;
let latestCache = { at: 0, latest: null };
const marketForce = { done: new Set() };
let lastTotalsAt = 0;
let lastExtReport = null; // 拡張機能からの、「USSで開く」の結果の報告（原因の確認用）
const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, `http://127.0.0.1:${port}`);
    // 画面からの通信があれば「使われている」とみなす（拡張機能の常時通信は数えない）
    if (!url.pathname.startsWith("/api/ext/") && url.pathname !== "/api/uss/fetch") lastActive = Date.now();
    if (url.pathname === "/api/fs/list" || url.pathname === "/api/fs/mkdir") {
      if (request.headers["x-ud-ext"] !== "1") return json(response, { error: "forbidden" }, 403);
      try {
        if (url.pathname === "/api/fs/list") return json(response, listDirs(url.searchParams.get("path") || ""));
        const body = await readJson(request);
        return json(response, { path: makeDir(body.parent, body.name) });
      } catch (error) {
        return json(response, { error: error.message || String(error) }, 400);
      }
    }
    if (request.method === "GET" && url.pathname === "/api/mac-prompt") {
      const sh = sharedStatus();
      if (!sh.enabled || !sh.dir) return json(response, { error: "先に、「共有を使う」にチェックを入れて、共有フォルダを設定してください（Macは、共有フォルダから、データを取り込んで使います）。" }, 409);
      return json(response, { text: macInstallPrompt(path.basename(sh.dir)), filename: MAC_PROMPT_FILENAME });
    }
    if (request.method === "GET" && url.pathname === "/api/grades") return json(response, gradesOfCar(url.searchParams.get("car") || ""));
    if (request.method === "GET" && url.pathname === "/api/shared/status") return json(response, sharedStatus());
    if (request.method === "POST" && url.pathname === "/api/shared/config") {
      const body = await readJson(request);
      try {
        saveSharedConfig({ enabled: body.enabled === true || body.enabled === "1", dir: body.dir });
        const result = body.enabled === true || body.enabled === "1" ? await syncShared() : null;
        return json(response, { ok: true, result, status: sharedStatus() });
      } catch (error) {
        return json(response, { error: error.message || String(error) }, 400);
      }
    }
    if (request.method === "POST" && url.pathname === "/api/shared/pull") {
      const body = await readJson(request);
      const result = await pullShared({ waitSec: body.wait ? 60 : 0, force: Boolean(body.force) });
      return json(response, { ...result, status: sharedStatus() });
    }
    if (request.method === "GET" && url.pathname === "/api/uss/state") return json(response, await ussState(url.searchParams.get("force") === "1"));
    if (url.pathname === "/api/ping") return json(response, { ok: true, autoCollect: getSettings().autoCollect });
    if (request.method === "POST" && url.pathname === "/api/quit") {
      if (request.headers["x-ud-ext"] !== "1") return json(response, { error: "forbidden" }, 403);
      json(response, { ok: true });
      console.log("終了の操作を受けました。");
      setTimeout(() => process.exit(0), 300);
      return;
    }
    if (request.method === "GET" && url.pathname === "/api/ext/status") {
      noteExtConnected();
      // 同梱の拡張機能（このシステムの chrome-extension フォルダ）の版と比べて、古いとき（版を伝えない古い拡張機能も含む）は、outdated
      const bridge = bridgeStatus();
      let bundled = "";
      try { bundled = JSON.parse(fs.readFileSync(path.join(root, "chrome-extension", "manifest.json"), "utf8")).version; } catch { /* 読めないときは、比べない */ }
      const outdated = Boolean(bundled) && bridge.connected && (!bridge.version || isNewer(bundled, bridge.version));
      return json(response, { ...bridge, bundled, outdated });
    }
    // 拡張機能のフォルダを、エクスプローラー（MacはFinder）で開く
    if (request.method === "POST" && url.pathname === "/api/open-ext-folder") {
      const dir = path.join(root, "chrome-extension");
      if (!fs.existsSync(dir)) return json(response, { error: `フォルダが見つかりません：${dir}` }, 404);
      spawn(process.platform === "win32" ? "explorer.exe" : "open", [dir], { detached: true, stdio: "ignore" }).unref();
      return json(response, { ok: true, dir });
    }
    if (request.method === "GET" && url.pathname === "/api/setup/status") {
      noteExtConnected();
      let probe;
      if (url.searchParams.get("probe") === "1") {
        const settings = getSettings();
        try {
          if (!bridgeStatus().connected) throw new Error("拡張機能につながっていません。");
          const reply = await ussFetch({ path: `${settings.cisPath}jp/market/model/option/brandOption.aspx?Uss=TK`, method: "GET", timeoutMs: 30_000 });
          probe = /BrandCodeOption/.test(reply.text) ? { ok: true } : { ok: false, error: "USSにログインできていない可能性があります（相場検索のページを読めませんでした）。" };
        } catch (error) {
          probe = { ok: false, error: error.message };
        }
      }
      const checks = [...(await staticChecks()), ...liveChecks({ settings: getSettings(), bridge: bridgeStatus(), probe })];
      return json(response, { checks, summary: summarize(checks), root: ROOT, prompt: agentPromptFor(checks), uptimeSec: Math.round((Date.now() - startedAt) / 1000), extEverConnected });
    }
    if (url.pathname.startsWith("/api/ext/")) noteExtConnected();
    if (url.pathname.startsWith("/api/ext/") || url.pathname === "/api/uss/fetch") {
      // 拡張機能（と開発用の確認）だけが使える入口。Webページからの呼び出しは、この印がないため通らない。
      if (request.headers["x-ud-ext"] !== "1") return json(response, { error: "forbidden" }, 403);
      if (request.method === "GET" && url.pathname === "/api/ext/poll") {
        noteExtVersion(request.headers["x-ud-ext-version"]);
        const job = await pollJob(Math.min(Number(url.searchParams.get("wait")) || 20, 25) * 1000);
        return json(response, { job });
      }
      if (request.method === "POST" && url.pathname === "/api/ext/report") { lastExtReport = { at: new Date().toISOString(), ...(await readJson(request)) }; console.log("[拡張機能の報告]", JSON.stringify(lastExtReport)); return json(response, { ok: true }); }
      if (request.method === "GET" && url.pathname === "/api/ext/report") return json(response, lastExtReport);
      if (request.method === "POST" && url.pathname === "/api/ext/result") return json(response, { ok: receiveResult(await readJson(request)) });
      if (request.method === "POST" && url.pathname === "/api/uss/fetch") {
        const body = await readJson(request);
        const result = await ussFetch({ path: body.path, method: body.method || "GET", form: body.form });
        return json(response, result);
      }
    }
    if (request.method === "GET" && url.pathname === "/api/bootstrap") return json(response, bootstrap());
    if (request.method === "GET" && url.pathname === "/api/lots/csv") {
      const { rows } = listLots({ query: url.searchParams.get("q") || "", offset: 0, limit: 1000000, modelCodes: (url.searchParams.get("models") || "").split(",") });
      const head = ["開催日", "会場", "出品番号", "検索コード", "年式", "車名", "型式", "グレード", "駆動", "排気量", "走行(km)", "色", "装備", "評価", "スタート(万円)", "落札(万円)", "結果"];
      const cell = (value) => { const text = value === null || value === undefined ? "" : String(value); return /[",\n\r]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text; };
      const lines = [head.join(",")].concat(rows.map((lot) => [lot.auction_date, lot.venue, lot.lot_no, lot.uss_code, lot.year, lot.model_name, lot.model_code, lot.grade, lot.drive, lot.displacement, lot.mileage_km, lot.color, lot.equipment, lot.score ?? lot.score_raw, lot.start_man, lot.hammer_man, lot.result].map(cell).join(",")));
      const stamp = new Date().toISOString().slice(0, 10);
      response.writeHead(200, { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": "attachment; filename*=UTF-8''" + encodeURIComponent("落札データ_" + stamp + ".csv"), "Cache-Control": "no-store" });
      response.end("\uFEFF" + lines.join("\r\n") + "\r\n");
      return;
    }
    if (request.method === "GET" && url.pathname === "/api/lots") {
      return json(response, listLots({
        query: url.searchParams.get("q") || "",
        offset: Number(url.searchParams.get("offset") || 0),
        limit: Number(url.searchParams.get("limit") || 80),
        modelCodes: (url.searchParams.get("models") || "").split(","),
      }));
    }
    // 画面の動作確認用（環境変数 UD_SIM_COLLECT=1 のときだけ）：USSには触れず、データも保存せず、取得の進み具合の表示だけを再現する
    const simCollect = process.env.UD_SIM_COLLECT === "1";
    if (request.method === "GET" && url.pathname === "/api/collect/status") return json(response, { ...collectJob, bridge: simCollect ? { connected: true } : bridgeStatus(), marketRunning: marketJob.running, marketRemaining: marketPendingCount() });
    if (request.method === "POST" && url.pathname === "/api/collect/cancel") {
      if (marketJob.running) marketCancel.stop = true; // 取得とは別に動いている、小売相場の読み取りも止める
      if (collectJob.running) { collectJob.cancel = true; marketCancel.stop = true; collectJob.message = "キャンセルしています…（いまのページが終わるまで、少しお待ちください）"; }
      return json(response, { ok: true, running: collectJob.running });
    }
    if (request.method === "POST" && url.pathname === "/api/upcoming/cancel") {
      if (upcomingJob.running) { upcomingJob.cancel = true; upcomingJob.message = "キャンセルしています…（いまのページが終わるまで、少しお待ちください）"; }
      return json(response, { ok: true, running: upcomingJob.running });
    }
    if (request.method === "POST" && url.pathname === "/api/collect/run") {
      const body = await readJson(request);
      if (simCollect) return json(response, simulateCollect());
      const settings = getSettings();
      const venueCodes = (String(body.venues || "") ? String(body.venues).split(",") : settings.targetVenues).map((code) => code.trim()).filter(Boolean);
      const keys = String(body.cars || "") ? String(body.cars).split("|") : settings.collectCars;
      const cars = keys.map((key) => key.split("\t")).filter((parts) => parts.length >= 2).map(([maker, name]) => ({ maker: maker.trim(), name: name.trim() }));
      if (viewerOnly) return json(response, { error: NO_USS_MESSAGE }, 409);
      if (!bridgeStatus().connected) return json(response, { error: "Chromeの拡張機能につながっていません。USSにログインしたChromeを開いてください。" }, 409);
      if (!venueCodes.length) return json(response, { error: "取得する会場が選ばれていません。" }, 400);
      if (!cars.length) return json(response, { error: "取得する車種が選ばれていません。" }, 400);
      await pullShared({ waitSec: 20 }).catch(() => {}); // 共有の最新を取り込んでから取得する（同期中なら、少し待つ。だめでも、取得は続ける）
      return json(response, await runCollect({
        settings, venueCodes, cars, term: [1, 4, 8, 12].includes(Number(body.term)) ? Number(body.term) : 1, saveLots, coverage: { get: getCoverage, set: setCoverage }, force: Boolean(body.force),
        // 落札を取り終えたら、続けて小売相場（カーセンサー・グーネット）まで読む
        afterCollect: async (progress) => { pruneOldLots(getSettings().keepMonths); await publishShared().catch(() => {}); return readAllMarkets(progress); },
      }));
    }
    // 出品予定（下見検索）：見るだけで取得して、相場と照合し、上限落札額を出す
    if (request.method === "GET" && url.pathname === "/api/upcoming") {
      const items = evaluateUpcoming();
      const venueNames = [...new Set(items.map((item) => item.venue))].join("・");
      const date = items[0]?.auctionDate ? items[0].auctionDate.slice(5).replace("-", "/") : "";
      return json(response, {
        job: upcomingJob, auto: autoState, lastAuto: lastAutoText(), bridge: bridgeStatus(), items,
        text: items.length ? pickText(items, venueNames, date) : "",
        venues: db.prepare("SELECT code, name FROM venues").all(),
      });
    }
    // 右下のアシスタント：マニュアルを根拠に、使い方の質問に答える（中継サーバー経由。設定が無ければ、貼り付け方式）
    if (request.method === "GET" && url.pathname === "/api/assistant/status") return json(response, { relay: Boolean(getSettings().assistantUrl) });
    if (request.method === "POST" && url.pathname === "/api/assistant/ask") {
      const body = await readJson(request);
      const messages = (Array.isArray(body.messages) ? body.messages : []).slice(-10).map((item) => ({ role: item.role === "assistant" ? "assistant" : "user", text: String(item.text || "").slice(0, 2000) }));
      if (!messages.length || !messages[messages.length - 1].text.trim()) return json(response, { error: "質問が、空です。" }, 400);
      const assistantSettings = getSettings();
      // 画面に出ている文（エラー文など）は、任意。契約のパスは、伏せる
      const screen = body.includeScreen ? String(body.screen || "").replace(/\/cis\/[^/\s]+\//g, "/cis/***/").slice(0, 600) : "";
      const status = statusText({ version: runningVersion, extensionConnected: bridgeStatus().connected, tab: String(body.tab || "").slice(0, 40), autoCollect: assistantSettings.autoCollect, viewerOnly, settings: assistantSettings, screen });
      if (body.paste || !assistantSettings.assistantUrl) return json(response, { mode: "paste", prompt: pastePrompt({ messages, status }) });
      try {
        const reply = extractProposal(await askRelay({ url: assistantSettings.assistantUrl, token: assistantSettings.assistantToken, messages, status }));
        if (reply.raw === null) return json(response, { mode: "relay", answer: reply.text });
        // AIが、操作案を付けたとき：システムが、読み取って、確かめて、確認の文を作る（AIの文章は、そのまま、実行しない）
        const checked = reply.broken ? { actions: [], errors: ["操作案を、読み取れませんでした。"] } : normalizeActions(reply.raw, assistantSettings);
        const proposal = checked.actions.length ? { id: holdProposal(checked.actions), items: checked.actions.map((action) => action.description) } : null;
        return json(response, { mode: "relay", answer: reply.text, proposal, proposalErrors: checked.errors });
      } catch (error) {
        return json(response, { error: error.message || "アシスタントが、答えられませんでした。" }, 502);
      }
    }
    if (request.method === "POST" && url.pathname === "/api/assistant/apply") {
      // ユーザーが、確認の画面で「実行する」を押したときだけ（確かめ済みの内容を、実行する）
      const body = await readJson(request);
      try { return json(response, { ok: true, results: applyProposal(String(body.id || "")) }); } catch (error) { return json(response, { error: error.message || "実行できませんでした。" }, 400); }
    }
    // 自動取得と同じ流れを、いま実行する（動作確認・「今すぐ」用）。落札の取得を飛ばす指定もできる。
    if (request.method === "POST" && url.pathname === "/api/auto/run") {
      const body = await readJson(request);
      if (viewerOnly) return json(response, { error: NO_USS_MESSAGE }, 409);
      if (!bridgeStatus().connected) return json(response, { error: "Chromeの拡張機能につながっていません。USSにログインしたChromeを開いてください。" }, 409);
      if (autoState.running) return json(response, { started: false, ...autoState });
      const chainSettings = getSettings();
      const hasCars = chainSettings.autoCars.some((key) => key.split("\t").length >= 2);
      if (!chainSettings.autoVenues.length) return json(response, { error: "自動で取得する会場が選ばれていません。この欄の「自動で取得する会場」で、会場を選んでください。" }, 400);
      if (!hasCars) return json(response, { error: "自動で取得する車種が選ばれていません。この欄の「自動で取得する車種」で、車種を探して、追加してください。" }, 400);
      runAutoChain({ skipCollect: Boolean(body.skipCollect), note: "手動：", term: [1, 4, 8, 12].includes(Number(body.term)) ? Number(body.term) : null });
      return json(response, { started: true, ...autoState });
    }
    if (request.method === "GET" && url.pathname === "/api/auto/status") {
      return json(response, { auto: autoState, collect: { running: collectJob.running, phase: collectJob.phase, message: collectJob.message, done: collectJob.done, total: collectJob.total }, upcoming: { running: upcomingJob.running, message: upcomingJob.message, done: upcomingJob.done, total: upcomingJob.total } });
    }
    if (request.method === "POST" && url.pathname === "/api/auto/cancel") {
      if (autoState.running) {
        autoState.cancel = true;
        collectJob.cancel = collectJob.running;
        upcomingJob.cancel = upcomingJob.running;
        marketCancel.stop = true;
        autoState.message = "キャンセルしています…（いまのページが終わるまで、少しお待ちください）";
      }
      return json(response, { ok: true, running: autoState.running });
    }
    if (request.method === "POST" && url.pathname === "/api/upcoming/totals") {
      // システムを開いたときに、出品の総数だけを最新にする（10分以内にやっていれば、しない）。つながっていないときは、何もしない。
      const idle = !viewerOnly && bridgeStatus().connected && !collectJob.running && !upcomingJob.running && Date.now() - lastTotalsAt > 10 * 60 * 1000;
      if (!idle) return json(response, { updated: 0, skipped: true });
      lastTotalsAt = Date.now();
      try {
        return json(response, { updated: await refreshVenueTotals({ settings: getSettings(), venueCodes: upcomingVenueCodes(), update: updateVenueTotal }) });
      } catch {
        return json(response, { updated: 0 });
      }
    }
    if (request.method === "POST" && url.pathname === "/api/upcoming/run") {
      const body = await readJson(request);
      const settings = getSettings();
      const venueCodes = (String(body.venues || "") ? String(body.venues).split(",") : settings.targetVenues).map((code) => code.trim()).filter(Boolean);
      const cars = (String(body.cars || "") ? String(body.cars).split("|") : settings.collectCars).map((key) => key.split("\t")).filter((parts) => parts.length >= 2).map(([maker, name]) => ({ maker: maker.trim(), name: name.trim() }));
      if (viewerOnly) return json(response, { error: NO_USS_MESSAGE }, 409);
      if (!bridgeStatus().connected) return json(response, { error: "Chromeの拡張機能につながっていません。USSにログインしたChromeを開いてください。" }, 409);
      if (!venueCodes.length) return json(response, { error: "取得する会場が選ばれていません。" }, 400);
      if (!cars.length) return json(response, { error: "取得する車種が選ばれていません。" }, 400);
      if (upcomingJob.running) return json(response, { started: false, ...upcomingJob });
      await pullShared({ waitSec: 20 }).catch(() => {});
      // 出品予定を取得したときの、車種を覚える（いまの取得の設定と、違っていないかを、画面で知らせるため）
      db.prepare("INSERT INTO settings (key, value) VALUES ('upcoming_cars', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(cars.map((car) => `${car.maker}	${car.name}`).join("|"));
      runUpcoming({ settings, venueCodes, cars, replaceUpcoming }).then(() => publishShared()).catch(() => {}); // 裏で進める（待たない）。終わったら、共有に書き出す
      return json(response, { started: true, ...upcomingJob });
    }
    if (request.method === "GET" && url.pathname === "/api/version") {
      // 動いている版と、配布先の最新版（30分、使い回す）。確認できないとき（オフラインなど）は、latest は null。
      if (Date.now() - latestCache.at > 30 * 60 * 1000) {
        latestCache = { at: Date.now(), latest: await checkLatest(5000).then((found) => found.latest).catch(() => null) };
      }
      const onDisk = readVersionFile().version;
      return json(response, { running: runningVersion, onDisk, latest: latestCache.latest });
    }
    if (request.method === "GET" && url.pathname === "/api/cluster-lots") {
      // 中央値の計算に使った落札の、全件の一覧
      const cluster = buildClusters().find((item) => item.key === (url.searchParams.get("key") || ""));
      return json(response, cluster ? { lots: cluster.allComps, medianMan: cluster.hammerMedianMan, count: cluster.compCount } : { lots: [], medianMan: null, count: 0 });
    }
    if (request.method === "GET" && url.pathname === "/api/cs-grades") {
      return json(response, { grades: listCsGrades(url.searchParams.get("carc") || "", Number(url.searchParams.get("year")) || 0) });
    }
    if (request.method === "POST" && url.pathname === "/api/grade-override") {
      // 人が確認したグレードの対応づけを保存する。code=null で「自動に戻す」、code="" で「対応なし」。
      const body = await readJson(request);
      const ok = setGradeOverride({ carc: String(body.carc || ""), grade: String(body.ussGrade || ""), code: body.code === null ? null : String(body.code ?? ""), name: String(body.name || "") });
      return json(response, { ok });
    }
    if (request.method === "GET" && url.pathname === "/api/market/status") return json(response, marketJob);
    if (request.method === "POST" && url.pathname === "/api/market/run") {
      const body = await readJson(request);
      const modelCodes = String(body.modelCodes || "").split(",").map((code) => code.trim()).filter(Boolean);
      // force：古さに関係なく読み直す（start で、今回の読み直しの「読んだ印」をリセット。以降の呼び出しは、続きから）
      if (body.start) marketForce.done = new Set();
      return json(response, await readNextMarkets(Number(body.limit) || 4, modelCodes, null, body.force ? { force: true, done: marketForce.done } : {}));
    }
    if (request.method === "POST" && url.pathname === "/api/import/excel") {
      const filename = decodeURIComponent(request.headers["x-filename"] || "");
      const buffer = await readRaw(request, 20_000_000);
      const parsed = lotsFromWorkbook(buffer, filename);
      const result = saveLots(parsed.lots);
      return json(response, { ...result, message: parsed.message });
    }
    if (request.method === "POST" && url.pathname === "/api/import/cis") {
      const parsed = lotsFromCis(await readJson(request));
      const result = saveLots(parsed.lots);
      return json(response, { ...result, message: parsed.message });
    }
    if (request.method === "POST" && url.pathname === "/api/settings") return json(response, saveSettings(await readJson(request)));
    if (request.method === "POST" && url.pathname === "/api/venues") {
      const body = await readJson(request);
      if (body.weekday !== undefined) {
        const weekday = body.weekday === "" || body.weekday === null ? null : Number(body.weekday);
        db.prepare("UPDATE venues SET weekday = ? WHERE code = ?").run(weekday, body.code);
      }
      if (body.transportYen !== undefined) {
        // 空欄は「未入力」（NULL）。計算では、0円として扱う。0と入れたときは、0円（自社で引き取るなど）。
        const yen = body.transportYen === "" || body.transportYen === null ? null : Math.max(0, Math.round(Number(body.transportYen) || 0));
        db.prepare("UPDATE venues SET transport_yen = ? WHERE code = ?").run(yen, body.code);
      }
      return json(response, { ok: true });
    }
    if (request.method === "POST" && url.pathname === "/api/models") {
      const body = await readJson(request);
      rememberModel(String(body.modelCode || "").toUpperCase(), String(body.name || "").trim(), String(body.maker || "").trim());
      return json(response, { ok: true });
    }
    if (request.method === "POST" && url.pathname === "/api/pins") {
      const body = await readJson(request);
      db.prepare("INSERT INTO pins (uss_code, note, created_at) VALUES (?, ?, ?) ON CONFLICT(uss_code) DO UPDATE SET note = excluded.note").run(body.ussCode, body.note || "", new Date().toISOString());
      return json(response, { ok: true });
    }
    if (request.method === "DELETE" && url.pathname === "/api/pins") {
      db.prepare("DELETE FROM pins WHERE uss_code = ?").run(url.searchParams.get("code"));
      return json(response, { ok: true });
    }
    if (request.method === "GET" && url.pathname === "/open/uss") return html(response, ussOpenPage(url.searchParams.get("code") || ""));
    if (request.method === "GET" && url.pathname === "/receive") return html(response, fs.readFileSync(path.join(publicDir, "receive.html"), "utf8"));
    if (request.method === "GET") return serveStatic(url.pathname, response);
    json(response, { error: "not found" }, 404);
  } catch (error) {
    json(response, { error: error.message || "failed" }, 500);
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`ESCO Drive http://127.0.0.1:${port}/`);
  try { const preset = applySharedPreset(); if (preset.applied) console.log(`共有フォルダを、初期設定から設定しました：${preset.dir}`); else if (preset.error) console.log(`共有フォルダの初期設定を、読み込めませんでした：${preset.error}`); } catch (error) { console.log("初期設定の読み込みに失敗：" + error.message); }
  syncShared().catch(() => {});
  try { const removed = pruneOldLots(getSettings().keepMonths); if (removed) console.log(`古い落札データ ${removed}台を整理しました。`); } catch (error) { console.log("整理に失敗：" + error.message); }
  maybeNotify();
  autoTick();
  autoReadTick().catch(() => {});
  setInterval(() => {
    syncShared().catch(() => {});
    maybeNotify();
    autoTick();
    autoReadTick().catch(() => {});
  }, 15 * 60 * 1000);
  // 自動取得がオフで、画面が閉じられて一定時間たち、作業中でもなければ、自動で終了する
  setInterval(() => {
    const busy = collectJob.running || upcomingJob.running || marketJob.running || autoState.running || autoReadState.running;
    if (getSettings().autoCollect || getSettings().autoRead || busy) return;
    if (Date.now() - lastActive > IDLE_EXIT_MS) {
      console.log("画面が閉じられて、自動取得もオフのため、終了します。");
      process.exit(0);
    }
  }, 30 * 1000);
});

// USSにログインできているか（USBキーが挿さって、ログイン済みか）。相場検索の画面を1回だけ読んで確かめ、結果を数分使い回す。
let ussCheck = { at: 0, ok: null, reason: "" };
let ussChecking = null;
async function ussState(force = false) {
  if (viewerOnly) return { ok: null, viewerOnly: true, reason: NO_USS_MESSAGE, at: Date.now() };
  if (!bridgeStatus().connected) return { ok: null, reason: "拡張機能がつながっていません", at: Date.now() };
  if (!force && Date.now() - ussCheck.at < 3 * 60 * 1000) return ussCheck;
  if (ussChecking) return ussChecking;
  ussChecking = (async () => {
    try {
      const reply = await ussFetch({ path: `${getSettings().cisPath}jp/market/model/option/brandOption.aspx?Uss=TK`, method: "GET", timeoutMs: 25_000, passive: true });
      ussCheck = /BrandCodeOption/.test(reply.text) ? { at: Date.now(), ok: true, reason: "", via: reply.via || "" } : { at: Date.now(), ok: false, reason: "USSにログインできていません", via: reply.via || "" };
    } catch (error) {
      ussCheck = /NO_USS_TAB/.test(error.message || "")
        ? { at: Date.now(), ok: null, noTab: true, reason: "ChromeにUSSのタブが開いていません" }
        : { at: Date.now(), ok: false, reason: error.message || "USSの確認ができません" };
    } finally { ussChecking = null; }
    return ussCheck;
  })();
  return ussChecking;
}

// 小売相場がまだ読めていない（または古い）グループの数
function marketPendingCount() {
  return buildClusters().filter((cluster) => cluster.inBand && (["missing", "stale"].includes(cluster.carsensor.status) || ["missing", "stale"].includes(cluster.goonet.status))).length;
}

function bootstrap() {
  const clusters = buildClusters();
  const settings = getSettings();
  return {
    settings,
    regions: regionChoices(),
    venues: db.prepare("SELECT * FROM venues ORDER BY name").all(),
    models: modelNameMap(),
    modelChoices: modelChoices(),
    catalog: carCatalog,
    lotCount: db.prepare("SELECT COUNT(*) AS count FROM lots").get().count,
    shared: sharedStatus(),
    viewerOnly,
    noUssMessage: NO_USS_MESSAGE,
    platform: isMac ? "mac" : process.platform === "win32" ? "win" : "other",
    extDir: path.join(root, "chrome-extension"), // 拡張機能のフォルダ（このPCで、実際に動いている場所）
    filtersSummary: filtersSummary(settings.collectFilters),
    autoFiltersSummary: filtersSummary(settings.autoFilters),
    // 自動で取得する車種ごとの、いま使われる条件（ルールを反映したもの）
    autoCarSummaries: Object.fromEntries(settings.autoCars.map((key) => key.split("	")).filter((parts) => parts.length >= 2).map(([maker, name]) => [`${maker.trim()}	${name.trim()}`, carFiltersSummary(settings, { maker: maker.trim(), name: name.trim() })])),
    filterOptions: { scores: SCORE_OPTIONS, colors: COLOR_OPTIONS, scores4Up: SCORE_4_UP },
    lastImportedAt: db.prepare("SELECT MAX(imported_at) AS at FROM lots").get().at || "",
    latestAuctionDate: db.prepare("SELECT MAX(auction_date) AS day FROM lots").get().day || "",
    clusters,
    today: todayView(),
    attentionCount: clusters.filter((cluster) => cluster.notable).length,
    missingCount: clusters.filter((cluster) => cluster.gapYen === null).length,
  };
}

function ussOpenPage(code) {
  const match = String(code).toUpperCase().match(/^([A-Z]{2})-(\d+)-(\d+)$/);
  if (!match) return "<p>USS検索コードの形ではありません。</p>";
  const settings = getSettings();
  const href = `https://ssl.cis6200.jp${settings.cisPath}jp/market/bidno/bidnoSch.aspx#ud=${match[1]}-${match[2]}-${match[3]}`;
  return `<!doctype html><meta charset="utf-8"><title>USSを開く</title>
<p>ログイン中のUSSを開きます。その車が、自動で出ます。</p>
<p><a href="${escapeHtml(href)}">USSを開く</a></p>
<script>location.replace(${JSON.stringify(href)})</script>`;
}

function serveStatic(pathname, response) {
  const requested = (pathname === "/" ? "index.html" : pathname).replace(/^[/\\]+/, "");
  const filePath = path.resolve(publicDir, requested);
  const rootWithSep = publicDir.endsWith(path.sep) ? publicDir : publicDir + path.sep;
  if (!filePath.startsWith(rootWithSep) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    return json(response, { error: "not found" }, 404);
  }
  const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".png": "image/png", ".webmanifest": "application/manifest+json" };
  response.writeHead(200, { "Content-Type": types[path.extname(filePath)] || "application/octet-stream", "Cache-Control": "no-store" });
  fs.createReadStream(filePath).pipe(response);
}

function json(response, data, status = 200) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  response.end(JSON.stringify(data));
}

function html(response, body) {
  response.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
  response.end(body);
}

function readRaw(request, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    request.on("data", (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error("ファイルが大きすぎます。"));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on("end", () => resolve(Buffer.concat(chunks)));
    request.on("error", reject);
  });
}

async function readJson(request) {
  const raw = await readRaw(request, 8_000_000);
  if (!raw.length) return {};
  return JSON.parse(raw.toString("utf8"));
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}


// 取得の進み具合の、表示確認用の疑似データ（UD_SIM_COLLECT=1 のときだけ使う）。USSにも、データベースにも、触れない。
function simulateCollect() {
  if (collectJob.running) return { started: false, ...collectJob };
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  Object.assign(collectJob, { running: true, cancel: false, phase: "uss", message: "準備しています", done: 0, total: 0, saved: 0, reused: 0, error: "", skipped: [] });
  (async () => {
    const cars = ["トヨタ プリウス", "トヨタ アクア", "ホンダ フィット", "日産 ノート", "メルセデス・ベンツ Cクラス", "BMW 3シリーズ"];
    collectJob.total = cars.length;
    for (const name of cars) {
      if (collectJob.cancel) break;
      for (let page = 1; page <= 2; page += 1) { collectJob.message = `TK ${name} ${page}/2ページ`; await wait(1300); }
      collectJob.saved += 20; collectJob.done += 1;
    }
    if (collectJob.cancel) { collectJob.message = `キャンセルしました。ここまでに、落札 ${collectJob.saved}台を保存しています。（疑似データ）`; collectJob.running = false; collectJob.cancel = false; return; }
    collectJob.message = `① 落札データの取り込みが終わりました（${collectJob.saved}台）。続けて② 小売相場を調べます（まだ終わっていません）`;
    collectJob.phase = "market"; collectJob.done = 0; collectJob.total = 0;
    await wait(4000);
    const total = 10;
    collectJob.total = total; collectJob.message = `小売相場を読む準備をしています（全${total}件）`;
    for (let i = 1; i <= total && !collectJob.cancel; i += 1) { await wait(4000); collectJob.done = i; collectJob.message = `プリウス（疑似データ ${i}）`; }
    collectJob.message = collectJob.cancel ? `キャンセルしました。ここまでに、落札 ${collectJob.saved}台を保存しています。（疑似データ）` : `すべて完了しました。落札 ${collectJob.saved}台を保存。小売相場も読みました。（表示確認用の疑似データです）`;
    collectJob.running = false; collectJob.cancel = false;
  })();
  return { started: true, ...collectJob };
}
