// ESCO Drive（Mac用のアプリ本体）
//   役目：裏のシステム（Node.js）を起動して、その画面を、専用のウィンドウ（WebView）で出す。
//   Chromeは使わない。Dockにも、アプリの一覧にも、ESCO Drive が1つだけ出る。
//   ビルド：mac/build-app.sh（Macで実行）
import Cocoa
import WebKit

let homeURL = URL(string: "http://127.0.0.1:3847/")!
let pingURL = URL(string: "http://127.0.0.1:3847/api/ping")!

final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate, WKUIDelegate, WKNavigationDelegate, WKDownloadDelegate {
    var window: NSWindow!
    var webView: WKWebView!
    var downloadTargets: [ObjectIdentifier: URL] = [:]

    // MARK: 起動
    func applicationDidFinishLaunching(_ notification: Notification) {
        setupMenu()
        setupWindow()
        showMessage("起動しています…")
        NSApp.activate(ignoringOtherApps: true)
        DispatchQueue.global().async { self.startServerAndLoad() }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag { window.makeKeyAndOrderFront(nil) }
        return true
    }

    func windowWillClose(_ notification: Notification) { NSApp.terminate(nil) }

    // MARK: ウィンドウ
    func setupWindow() {
        let config = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: config)
        webView.uiDelegate = self
        webView.navigationDelegate = self
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1400, height: 900),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "ESCO Drive"
        window.contentView = webView
        window.minSize = NSSize(width: 720, height: 480)
        window.center()
        _ = window.setFrameAutosaveName("ESCODriveMain")
        window.delegate = self
        window.makeKeyAndOrderFront(nil)
    }

    func showMessage(_ text: String) {
        let html = "<html><body style=\"font-family:-apple-system,sans-serif;color:#555;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#f4f6f8\"><div style=\"text-align:center;line-height:1.8\">\(text)</div></body></html>"
        webView.loadHTMLString(html, baseURL: nil)
    }

    // MARK: 裏のシステムの起動
    func ping() -> Bool {
        var ok = false
        let semaphore = DispatchSemaphore(value: 0)
        var request = URLRequest(url: pingURL)
        request.timeoutInterval = 1.5
        URLSession.shared.dataTask(with: request) { _, response, _ in
            if let http = response as? HTTPURLResponse, http.statusCode == 200 { ok = true }
            semaphore.signal()
        }.resume()
        _ = semaphore.wait(timeout: .now() + 2.5)
        return ok
    }

    func findAppDir() -> String? {
        let fm = FileManager.default
        var candidates: [String] = []
        if let configured = Bundle.main.object(forInfoDictionaryKey: "ESCOAppDir") as? String { candidates.append(configured) }
        let home = NSHomeDirectory()
        candidates.append(home + "/Applications/ESCODrive")
        candidates.append(home + "/ESCODrive")
        return candidates.first { fm.isExecutableFile(atPath: $0 + "/runtime/node") }
    }

    func startServerAndLoad() {
        if !ping() {
            guard let dir = findAppDir() else {
                DispatchQueue.main.async { self.showMessage("ESCO Drive の本体が見つかりません。<br>インストールをやり直してください。") }
                return
            }
            let process = Process()
            process.executableURL = URL(fileURLWithPath: dir + "/runtime/node")
            process.arguments = ["lib/launcher.mjs", "--no-open"]
            process.currentDirectoryURL = URL(fileURLWithPath: dir)
            process.standardOutput = FileHandle.nullDevice
            process.standardError = FileHandle.nullDevice
            do { try process.run() } catch {
                DispatchQueue.main.async { self.showMessage("起動できませんでした。<br>\(error.localizedDescription)") }
                return
            }
            var up = false
            for _ in 0..<240 { // 最大2分（更新があるときは、取得に時間がかかる）
                Thread.sleep(forTimeInterval: 0.5)
                if ping() { up = true; break }
            }
            if !up {
                DispatchQueue.main.async { self.showMessage("システムが、起動しませんでした。<br>記録：~/Library/Application Support/udgarage-auction/server.log") }
                return
            }
        }
        DispatchQueue.main.async { self.webView.load(URLRequest(url: homeURL)) }
    }

    // MARK: 画面の動き（アラート・別窓・ダウンロード）
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = NSAlert()
        alert.messageText = message
        alert.addButton(withTitle: "OK")
        alert.runModal()
        completionHandler()
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert()
        alert.messageText = message
        alert.addButton(withTitle: "OK")
        alert.addButton(withTitle: "キャンセル")
        completionHandler(alert.runModal() == .alertFirstButtonReturn)
    }

    // 新しい窓（target=_blank など）は、ふだんのブラウザで開く
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { NSWorkspace.shared.open(url) }
        return nil
    }

    func webViewDidClose(_ webView: WKWebView) { NSApp.terminate(nil) }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.shouldPerformDownload { decisionHandler(.download); return }
        if let url = navigationAction.request.url, let scheme = url.scheme, scheme.hasPrefix("http"), url.host != "127.0.0.1" {
            NSWorkspace.shared.open(url) // 外のサイトは、ふだんのブラウザで開く
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let http = navigationResponse.response as? HTTPURLResponse,
           let disposition = http.value(forHTTPHeaderField: "Content-Disposition"),
           disposition.lowercased().contains("attachment") {
            decisionHandler(.download)
        } else if !navigationResponse.canShowMIMEType {
            decisionHandler(.download)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { download.delegate = self }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }

    // ダウンロードは、「ダウンロード」フォルダに保存して、Finderで見せる
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dir = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
        let name = suggestedFilename.isEmpty ? "download" : suggestedFilename
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var target = dir.appendingPathComponent(name)
        var index = 1
        while FileManager.default.fileExists(atPath: target.path) {
            target = dir.appendingPathComponent(ext.isEmpty ? "\(base) (\(index))" : "\(base) (\(index)).\(ext)")
            index += 1
        }
        downloadTargets[ObjectIdentifier(download)] = target
        completionHandler(target)
    }

    func downloadDidFinish(_ download: WKDownload) {
        if let target = downloadTargets.removeValue(forKey: ObjectIdentifier(download)) {
            NSWorkspace.shared.activateFileViewerSelecting([target])
        }
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        downloadTargets.removeValue(forKey: ObjectIdentifier(download))
        let alert = NSAlert()
        alert.messageText = "ダウンロードできませんでした"
        alert.informativeText = error.localizedDescription
        alert.runModal()
    }

    // MARK: メニュー（コピー・貼り付け・再読み込み・拡大縮小）
    @objc func reloadPage() { webView.reload() }
    @objc func zoomIn() { webView.pageZoom = min(3.0, webView.pageZoom + 0.1) }
    @objc func zoomOut() { webView.pageZoom = max(0.5, webView.pageZoom - 0.1) }
    @objc func zoomReset() { webView.pageZoom = 1.0 }

    func setupMenu() {
        let mainMenu = NSMenu()

        let appItem = NSMenuItem()
        mainMenu.addItem(appItem)
        let appMenu = NSMenu()
        appItem.submenu = appMenu
        appMenu.addItem(withTitle: "ESCO Drive について", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "ESCO Drive を隠す", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "ESCO Drive を終了", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")

        let editItem = NSMenuItem()
        mainMenu.addItem(editItem)
        let editMenu = NSMenu(title: "編集")
        editItem.submenu = editMenu
        editMenu.addItem(withTitle: "取り消す", action: Selector(("undo:")), keyEquivalent: "z")
        let redo = editMenu.addItem(withTitle: "やり直す", action: Selector(("redo:")), keyEquivalent: "z")
        redo.keyEquivalentModifierMask = [.command, .shift]
        editMenu.addItem(.separator())
        editMenu.addItem(withTitle: "切り取り", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "コピー", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "貼り付け", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "すべてを選択", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")

        let viewItem = NSMenuItem()
        mainMenu.addItem(viewItem)
        let viewMenu = NSMenu(title: "表示")
        viewItem.submenu = viewMenu
        viewMenu.addItem(withTitle: "再読み込み", action: #selector(reloadPage), keyEquivalent: "r")
        viewMenu.addItem(withTitle: "拡大", action: #selector(zoomIn), keyEquivalent: "+")
        viewMenu.addItem(withTitle: "縮小", action: #selector(zoomOut), keyEquivalent: "-")
        viewMenu.addItem(withTitle: "実際のサイズ", action: #selector(zoomReset), keyEquivalent: "0")

        let windowItem = NSMenuItem()
        mainMenu.addItem(windowItem)
        let windowMenu = NSMenu(title: "ウインドウ")
        windowItem.submenu = windowMenu
        windowMenu.addItem(withTitle: "しまう", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        windowMenu.addItem(withTitle: "拡大／縮小", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")

        NSApp.mainMenu = mainMenu
        NSApp.windowsMenu = windowMenu
    }
}

let application = NSApplication.shared
let appDelegate = AppDelegate()
application.delegate = appDelegate
application.setActivationPolicy(.regular)
application.run()
