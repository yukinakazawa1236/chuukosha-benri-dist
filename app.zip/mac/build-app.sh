#!/bin/bash
# ESCO Drive.app（Mac用のアプリ本体）を、Macで作る。Swift（Xcodeか、コマンドラインツール）が必要。
#   使い方：bash build-app.sh [出力フォルダ]     出力：ESCO-Drive-mac.zip（と、ESCO Drive.app）
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
OUT="${1:-${TMPDIR:-/tmp}/esco-drive-build}" # 作った物は、プロジェクトの外に置く（Dropboxに同期されて、Spotlightに二重に出るのを防ぐ）
APP="$OUT/ESCO Drive.app"
VERSION="1.0" # アプリの殻の版（システムの版とは別。殻は、めったに変えない。システムは、起動のたびに、自動で更新される）
command -v swiftc >/dev/null 2>&1 || { echo "[エラー] swiftc が見つかりません（Xcode か、コマンドラインツールが必要です）" >&2; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/obj" "$APP/Contents/MacOS" "$APP/Contents/Resources"
echo "== コンパイル（Apple Silicon と Intel の両方）"
swiftc -O -target arm64-apple-macos12.0 "$HERE/ESCODrive/main.swift" -o "$OUT/obj/arm64"
swiftc -O -target x86_64-apple-macos12.0 "$HERE/ESCODrive/main.swift" -o "$OUT/obj/x86_64" || { echo "（Intel用は、作れませんでした。Apple Silicon 用だけにします）"; cp "$OUT/obj/arm64" "$OUT/obj/x86_64"; }
lipo -create "$OUT/obj/arm64" "$OUT/obj/x86_64" -output "$APP/Contents/MacOS/ESCODrive" 2>/dev/null || cp "$OUT/obj/arm64" "$APP/Contents/MacOS/ESCODrive"
chmod +x "$APP/Contents/MacOS/ESCODrive"
cp "$ROOT/public/icon.icns" "$APP/Contents/Resources/icon.icns"

cat > "$APP/Contents/Info.plist" <<EOP
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleExecutable</key><string>ESCODrive</string>
  <key>CFBundleIdentifier</key><string>jp.esco.drive</string>
  <key>CFBundleName</key><string>ESCO Drive</string>
  <key>CFBundleDisplayName</key><string>ESCO Drive</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>${VERSION:-1.0}</string>
  <key>CFBundleVersion</key><string>${VERSION:-1.0}</string>
  <key>CFBundleIconFile</key><string>icon</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>LSApplicationCategoryType</key><string>public.app-category.productivity</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/><key>NSAllowsArbitraryLoadsInWebContent</key><true/></dict>
</dict></plist>
EOP

codesign --force --deep -s - "$APP" >/dev/null 2>&1 || echo "（簡易の署名は、省きました）"
( cd "$OUT" && rm -f ESCO-Drive-mac.zip && ditto -c -k --keepParent "ESCO Drive.app" ESCO-Drive-mac.zip )
rm -rf "$OUT/obj"
echo "できました：$APP"
echo "配布用：$OUT/ESCO-Drive-mac.zip"
file "$APP/Contents/MacOS/ESCODrive" | head -1
